/**
 *  @file eliminaDatiPacchetti.h
 *
 * Questo header file contiene tutte le funzioni relative all'eliminazione di un pacchetto viaggio.
 *
 * @version 0.1
 * @authors Angelo Putignano, Roberto Modarelli
 */

/**
 * Questa funzione serve a contare i pacchetti viaggio presenti in memoria.
 *
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria.
 *
 * @return il numero dei pacchetti viaggio presenti in memoria.
 */
int contaPacchetti(DATI_PACCHETTO_VIAGGIO p[]);

/**
 * Questa funzione serve a indicare se puo' essere eliminato o meno un pacchetto viaggio.
 *
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria.
 *
 * @return 1 se si pue' ancora eliminare un pacchetto viaggio
 * @return 0 se non si possono piu' eliminare pacchetti viaggio
 */
int controlloRimozionePacchetti(DATI_PACCHETTO_VIAGGIO p[]);

/**
 * Questa funzione elimina un pacchetto viaggio dalla memoria.
 * @param[in] posPacchetto La posizione nel relativo vettore del pacchetto viaggio da eliminare.
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria.
 *
 * @return 1 se il primo e l'ultimo campo del pacchetto viaggio da eliminare si trovano a valori di default, 0 altrimenti
 */
int eliminaPacchettiViaggio(int posPacchetto, DATI_PACCHETTO_VIAGGIO p[]);

/**
 * Questa funzione permette di riordinare l'array dei pacchetti viaggio in seguito alla rimozione
 * di uno di essi.
 *
 * @param[in] posPacchetto La posizione del pacchetto viaggio che e' stato eliminato
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria.
 *
 * @return la funzione restituisce la nuova posizione del pacchetto eliminato nel relativo array
 */
int riordinaPacchetti(int posPacchetto, DATI_PACCHETTO_VIAGGIO p[]);

/**
 * Questa funzione raggruppa tutte le istruzioni necessarie ad effettuare la rimozione di un pacchetto viaggio.
 * @param[in] indiceMassimo  Posizione dell'ultimo pacchetto viaggio caricato in memoria nel relativo array.
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria.
 * @param[in] d[] Array che contiene tutte le possibili destinazioni dei viaggi.
 * @param[in] c[] Array che contiene le compagnie aeree presenti in memoria.
 * @param[in] h[] Array che contiene gli hotel presenti in memoria.
 * @param[in] t[] Array che contiene i tour operator presenti in memoria.
 */
void effettuaRimozionePacchetto(int indiceMassimo, DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[]);
