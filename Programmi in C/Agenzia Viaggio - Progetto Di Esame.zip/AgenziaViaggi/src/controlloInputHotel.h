/**
* @file controlloInputHotel.h
*
* Questo header file contiene i prototipi delle funzioni che permettono di inserire e controllare
* l'input relativo ai dati di nuovi hotel.
*
* @version 0.1
* @authors Angelo Putignano, Roberto Modarelli
*/

/**
 * Questa funzione permette di inserire il numero di stelle di un hotel.
 *
 * @param[in] minStelle Numero minimo di stelle che puo' avere un hotel.
 * @param[in] maxStelle Numero massimo di stelle che puo' avere un hotel.
 *
 * @return le stelle inserite
 */
int inserireStelle(int minStelle, int maxStelle);

/**
 * Questa funzione permette di inserire il prezzo di un hotel
 *
 * @param[in] stelle Indica il numero di stelle dell'hotel in questione e serve per capire entro quale range deve essere inserito il prezzo.
 *
 * @return prezzo dell'hotel inserito
 */
int inserirePrezzoHotel(int stelle);

/**
 * Questa funzione permette di inserire il numero di stanze totali di un hotel
 *
 * @param[in] minStanze Numero minimo di stanze che puo' avere un hotel.
 * @param[in] maxStanze Numero massimo di stanze che puo' avere un hotel.
 *
 * @return numero di stanze totali dell'hotel inserito
 */
int inserireStanzeTotali(int minStanze, int maxStanze);

/**
 * Questa funzione permette di inserire il numero di stanze libere di un hotel
 *
 * @param[in] stanzeTotali Serve a controllare che l'input inserito non sia maggiore del numero di stanze totali dell'hotel.
 *
 * @return numero di stanze libere dell'hotel inserito
 */
int inserireStanzeLibere(int stanzeTotali);

/**
 * Questa funzione permette di inserire la percentuale di sconto applicata da un hotel.
 *
 * @param[in] maxSconto Percentuale massima di sconto minori che puo' applicare un hotel.
 *
 * @return la percentuale di sconto applicata dall'hotel
 */
int inserireScontoHotel(int maxSconto);

/**
 *  Questa funzione permette di inserire l'id della citta' in cui e' situato un hotel.
 *
 *  @param[in] d[] Array che contiene tutte le possibili destinazioni dei viaggi
 *
 *  @return l'id della citta' scelta
 */
int inserireIdCittaHotel(DATI_DESTINAZIONE d[]);
