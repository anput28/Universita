/**
* @file modificaDatiPacchetto.h
*
* Questo header file contiene i prototipi delle funzioni per la modifica dei pacchetti viaggio.
*
* @version 0.1
* @authors Angelo Putignano, Roberto Modarelli
*/

/**
 * Questa funzione calcola il costo totale del pacchetto viaggio.
 *
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria.
 * @param[in] prezzoHotel Prezzo per notte dell'hotel incluso nel pacchetto viaggio.
 * @param[in] prezzoOrarioCompagnia Tariffa oraria della compagnia aerea
 *
 * @return ritorna il costo totale del pacchetto viaggio.
 */
int calcoloCostoPacchetto(DATI_PACCHETTO_VIAGGIO p, int prezzoHotel, float prezzoOrarioCompagnia);

/**
 * Questa funzione serve ad aggiornare il costo totale di un pacchetto viaggio inseguito
 * alla modifica del prezzo di un hotel.
 *
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria.
 * @param[in] c[] Array che contiene le compagnie aeree presenti in memoria.
 * @param[in] h[] Array che contiene gli hotel presenti in memoria.
 * @param[in] indiceHotel l'id dell'hotel di cui e' stato modificato il prezzo.
 *
 * @return la funzione ritorna 1 se viene aggiornato il costo totale di almeno un pacchetto viaggio, 0 altrimenti.
 */
int aggiornaCostoDaHotel(DATI_PACCHETTO_VIAGGIO p[],DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], int indiceHotel);

/**
 * Questa funzione serve ad aggiornare il costo totale di un pacchetto viaggio inseguito
 * alla modifica del prezzo di una compagnia aerea.
 *
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria.
 * @param[in] c[] Array che contiene le compagnie aeree presenti in memoria.
 * @param[in] h[] Array che contiene gli hotel presenti in memoria.
 * @param[in] indiceCompagniaAerea l'id della compagnia aerea di cui e' stato modificato il prezzo.
 *
 * @return la funzione ritorna 1 se viene aggiornato il costo totale di almeno un pacchetto viaggio, 0 altrimenti.
 */
int aggiornaCostoDaCompagnia (DATI_PACCHETTO_VIAGGIO p[],DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], int indiceCompagniaAerea);

/**
 * Questa funzione controlla se esiste gia' un pacchetto viaggio con i dati nuovi inseriti/modificati.
 * @param[in] p[] Array che contiene i dati di tutti i pacchetti viaggio gia' presenti in memoria.
 * @param[in] pacchettoViaggioInserito Contiene i dati del pacchetto viaggio inserito dall'utente.
 *
 * @return 1 se il pacchetto viaggio non e' gia' presente in memoria
 * @return 0 se il pacchetto viaggio e' gia' presente in memoria
 */
int controlloPresenzaPacchettoViaggio(DATI_PACCHETTO_VIAGGIO p[], DATI_PACCHETTO_VIAGGIO pacchettoViaggioInserito);

/**
 * Questa funzione permette di modificare i dati di unn pacchetto viaggio.
 *
 * @param[in] scelta E' la scelta del dato del pacchetto viaggio che si vuole modificare.
 * @param[in] p[] Il pacchetto viaggio scelto per essere modificato
 * @param[in] d[] Array che contiene tutte le possibili destinazioni dei viaggi
 * @param[in] v[] Array che contiene tutti gli orari dei voli
 * @param[in] c[] Array che contiene tutti i dati delle compagnie aeree
 * @param[in] h[] Array che contiene tutti i dati degli hotel
 * @param[in] t[] Array che contiene tutti i dati dei tour operator
 */
DATI_PACCHETTO_VIAGGIO modificaPacchettoViaggio(int scelta, DATI_PACCHETTO_VIAGGIO p, DATI_DESTINAZIONE d[], DATI_ORARIO_VOLO v[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[]);

/**
 * Funzione che raggruppa tutte le istruzioni necessarie a effettuare una modifica di un pacchetto viaggio
 *
 * @param[in] p[] Il pacchetto viaggio scelto per essere modificato
 * @param[in] d[] Array che contiene tutte le possibili destinazioni dei viaggi
 * @param[in] c[] Array che contiene tutti i dati delle compagnie aeree
 * @param[in] h[] Array che contiene tutti i dati degli hotel
 * @param[in] t[] Array che contiene tutti i dati dei tour operator
 * @param[in] v[] Array che contiene tutti gli orari dei voli
 *
 */
void effettuaModificaPacchetto(int indiceMassimo, DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[], DATI_ORARIO_VOLO v[]);

