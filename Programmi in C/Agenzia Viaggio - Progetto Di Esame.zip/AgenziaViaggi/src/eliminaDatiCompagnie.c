#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "costanti.h"
#include "struttureDati.h"
#include "controlloInput.h"
#include "modificaDati.h"
#include "stampaDati.h"
#include "eliminaDatiPacchetti.h"
#include "eliminaDatiCompagnie.h"


/**
 * Questa funzione serve a indicare se puo' essere eliminata o meno una compagnia aerea.
 * Tramite un for la funzione scorre tutto l'array in cui sono contenute le compagnie aeree
 * e se l'idCompagnia non e' 0 (cioe' la compagnia aerea ha valori significativi e non di default)
 * incrementa un contatore.
 * Se il contatore e' maggiore di 1 allora puo' essere eliminata una compagnia aerea altrimenti non
 * si possono piu' eliminare compagnie aeree.
 *
 * @post La funzione ritorna 1 se e' ancora possibile eliminare una compagnia aerea, 0 altrimenti
 */
int controlloRimozioneCompagnie(DATI_COMPAGNIA_AEREA c[]){
	int contaCompagnie = 0;
	for(int i = 0; i < MAX_NUM_COMPAGNIE; i++){
		if(c[i].idCompagnia != 0){
			contaCompagnie += 1;
		}
	}

	if(contaCompagnie > 1){
		return 1;
	}else{
		return 0;
	}
}

/**
 * Questa funzione elimina una compagnia aerea dalla memoria.
 * I dati della compagnia aerea scelta per essere eliminata (che si trova in posizione 'indiceCompagnia' nell'apposito
 * array delle compagnie aeree) vengono impostati a valori di default.
 * Viene chiamata la funzione per aggiornare i pacchetti viaggio, in modo da eliminare quelli
 * che hanno la compangia aerea eliminato inclusa.
 * Poi dopo aver eliminato la compagnia aerea, se questa non e' l'ultima contenuta nel relativo array,
 * viene riordinato il suddetto array che contiene le compagnie aeree.
 * Se il primo e l'ultimo campo di una compangia aerea hanno il valore di default allora si assume
 * che anche i restanti campi abbiamo apportato con successo la modifica.
 *
 * @post ritorna 1 se il primo e l'ultimo campo di una compagnia aerea hanno il valore di default, 0 altrimenti.
 */
int eliminaCompagnia(int indiceCompagnia, DATI_COMPAGNIA_AEREA c[], DATI_PACCHETTO_VIAGGIO p[], int indiceMassimo){
	c[indiceCompagnia].idCompagnia = 0;
	strcpy(c[indiceCompagnia].nomeCompagnia, " ");
	strcpy(c[indiceCompagnia].nazioneCompagnia, " ");
	c[indiceCompagnia].prezzoOrarioCompagnia = 0.0;

	aggiornaPacchettiDaCompagnia(indiceCompagnia+1, p);

	/*riordino le compagnie aeree nell'array solo se non � stato cancellato l'ultima compagnia aerea
	 * presente in memoria */
	if(indiceCompagnia < indiceMassimo){
		indiceCompagnia = riordinaCompagnieAeree(indiceCompagnia, c);
	}

	if(c[indiceCompagnia].idCompagnia == 0 && c[indiceCompagnia].prezzoOrarioCompagnia == 0.0){

		return 1;
	}else{

		return 0;
	}

}

/**
 * Questa funzione permette di riordinare le compagnie aeree presenti nel relativo array in seguito
 * all'eliminazione di una di esse.
 * La funzione riceve l'indice della compagnia aerea che e' stata eliminata. A partire da questo indice,
 * scorre tutte le compagnie aeree presenti nel relativo array e finche' non viene incontrato un idCompagnia
 * pari a 0 (segno che le compagnia aeree sono finite) scambia i dati della compagnia aerea che e' stata cancellata
 * (i dati sono stati settati a valori di default) con quelli della comapagnia aerea in posizione successiva,
 * aggiornando man mano gli indici delle compagnie aeree che cambiano posizione.
 *
 * @pre I dati della compagnia aerea in posizione 'indice' devono essere stati settati a valori di default
 * @post La funzione ritorna la nuova posizione della compagnia aerea eliminata nel relativo array
 */
int riordinaCompagnieAeree(int indice, DATI_COMPAGNIA_AEREA c[]){
	DATI_COMPAGNIA_AEREA appoggio;
	int nuovaPosizione = indice;
	/*il for scorre le compagnie fino a MAX_NUM_COMPAGNIE-1 perch� se 'indice' e' uguale a
	 * MAX_NUM_COMPAGNIE questa funzione non viene neanche chiamata
	 */
	for(int i = indice; i < MAX_NUM_COMPAGNIE-1; i++){

		if(c[i+1].idCompagnia != 0){

			appoggio = c[i];
			c[i] = c[i+1];
			/*in posizione i adesso si trova una compagnia che prima era in posizione i+1, quindi
			 * il id deve essere decrementato.*/
			c[i].idCompagnia -= 1;
			c[i+1] = appoggio;
			nuovaPosizione = i+1;
		}else{

			c[i].idCompagnia = 0;
		}
	}

	return nuovaPosizione;
}

/**
 * Questa funzione aggiorna i pacchetti viaggio inseguito all'eliminazione di una compagnia aerea.
 * In questa funzione un for scorre tutti i pacchetti viaggio, se l'indice della compagnia aerea eliminata/modificata
 * e' presente in un pacchetto viaggio allora viene chiamata le funziona per eliminare il pacchetto viaggio.
 *
 */
void aggiornaPacchettiDaCompagnia(int indiceCompagnia, DATI_PACCHETTO_VIAGGIO p[]){
	int contaEliminazioni = 0;
	for(int i = 0; i < MAX_NUM_PACCHETTI; i++){

		if(p[i].idPartenzaPacchetto != 0){
			if(p[i].idCompagniaAereaPacchetto == indiceCompagnia){

				eliminaPacchettoDaCompagnia(i, p, indiceCompagnia);
				contaEliminazioni += 1;
			}
		}
	}

	if(contaEliminazioni > 0){
		puts("\nLa compagnia aerea eliminata era contenuta in un pacchetto viaggio, che quindi e' stato eliminato.\n");
	}
}

/**
 * Questa funzione elimina un pacchetto viaggio in seguito alla rimozione di una compagnia aerea.
 * I dati del pacchetto viaggio che si trova in posizione 'posPacchetto' nell'array dei
 * pacchetti viaggio vengono impostati a valori di default.
 * Dopo aver eliminato il pacchetto viaggio, se questo non e' l'ultimo contenuto nel relativo array,
 * viene chiamata la funzione per riordinare il suddetto array che contiene i pacchetti viaggio.
 * Se il primo e l'ultimo campo di un pacchetto viaggio hanno il valore di default allora si assume
 * che anche i restanti campi abbiamo apportato con successo la modifica.
 *
 * @pre La compagnia aerea con id 'indiceCompagnia' nel relativo array deve essere stata eliminata
 * @post ritorna 1 se il primo e l'ultimo campo di un pacchetto viaggio hanno il valore di default, 0 altrimenti.
 */
int eliminaPacchettoDaCompagnia(int posPacchetto, DATI_PACCHETTO_VIAGGIO p[], int indiceCompagnia){
	p[posPacchetto].idPartenzaPacchetto = 0;
	p[posPacchetto].idArrivoPacchetto = 0;
	p[posPacchetto].oreViaggioPacchetto = 0;
	p[posPacchetto].minutiViaggioPacchetto = 0;
	p[posPacchetto].idCompagniaAereaPacchetto = 0;
	p[posPacchetto].categoriaVoloPacchetto = 0;
	p[posPacchetto].giorniPacchetto = 0;
	p[posPacchetto].idHotelPacchetto = 0;
	p[posPacchetto].idTourOperatorPacchetto = 0;
	p[posPacchetto].scontoPacchetto = 0;
	p[posPacchetto].costoTotalePacchetto = 0;

	if(posPacchetto < MAX_NUM_PACCHETTI-1){
		riordinaPacchetti(posPacchetto, p);
	}

	if(p[posPacchetto].idPartenzaPacchetto == 0 && p[posPacchetto].costoTotalePacchetto == 0){

		return 0;
	}else{

		return 1;
	}
}


/**
 * Questa funzione raggruppa tutte le istruzioni necessarie ad effettuare la rimozione di una compagnia aerea.
 */
void effettuaRimozioneCompagnia(int indiceMassimo, DATI_COMPAGNIA_AEREA c[], DATI_PACCHETTO_VIAGGIO p[]){
	int sceltaIdRimozione;

	if(controlloRimozioneCompagnie(c) == 1){
		printf("\nATTENZIONE!!! Eliminando una compagnia aerea che e' contenuta in un pacchetto viaggio,\n"
				"		verra' eliminato anche il pacchetto viaggio.\n\n");
		//aspetta tre secondi per dare il tempo di leggere il messaggio
		sleep(3);

		indiceMassimo = stampaCompagnieAeree(c);
		puts("\nInserire l'id della compagnia aerea che si intende eliminare scegliendo tra i seguenti:\n");
		sceltaIdRimozione = inserisciScelta(NUM_MIN_SOTTOMENU,indiceMassimo, 3);

		if(confermaModifica("eliminare") == 1){
			/*passo sceltaRimozione-1 perch� gli indici delle compagnie aeree partono da 1,
			 * ma sono memorizzati nell'array a partire da 0*/
			if((eliminaCompagnia(sceltaIdRimozione-1, c, p, indiceMassimo)) == 1){

				//Questo for serve ad aggiornare l'id delle compagnie aeree presenti nei pacchetti viaggio
				for(int i=0; i < MAX_NUM_PACCHETTI; i++){
					/*l'eliminazione della compagnia aerea ha provocato l'aggiornamento degli id solo delle compagnie aeree che avevano
					 * un id maggiore di quello eliminato, quindi solo questi id vengono aggiornati
					 */
					if(p[i].idCompagniaAereaPacchetto > sceltaIdRimozione){
						p[i].idCompagniaAereaPacchetto -= 1;
					}
				}
				puts("\nPERFETTO!!! Eliminazione compagnia aerea avvenuta con successo.");
			}else{
				puts("\nERRORE!!! Eliminazione compagnia aerea non riuscita.");
			}
		}

	}else{
		puts("\nIn memoria e' presente solo una compagnia aerea.");
		puts("Essa non puo' essere eliminato perche' altrimenti il sistema non funzionerebbe.\n");
	}

	printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");
}
