#include <stdio.h>
#include <unistd.h>

#include "costanti.h"
#include "struttureDati.h"
#include "controlloInput.h"
#include "controlloInputPacchetto.h"
#include "aggiungiDati.h"
#include "stampaDati.h"
#include "stampaMenu.h"
#include "modificaDati.h"
#include "modificaDatiPacchetto.h"
#include "eliminaDatiPacchetti.h"

/**
 *  Questa funzione calcola il costo totale del pacchetto viaggio.
 *  Il costo totale e' dato tra tre valori: il prezzo dell'hotel, il costo del viaggio e costo del tour operator.
 *  Il prezzo dell'hotel viene calcolato moltiplicando la tariffa notte prevista dall'hotel per i giorni di durata
 *  del pacchetto.
 *  Il costo del viaggio viene calcolato moltiplicando le ore di viaggio per la tariffa oraria della compagnia aerea,
 *  inoltre se la categoria di volo e' 'business' il tutto viene moltiplicato per due.
 *  Il costo del tour operator e' una costante.
 *  A questi tre valori viene sottratto lo sconto previsto nel pacchetto viaggio.
 *
 *  @post ritorna il costo totale del pacchetto viaggio.
 */
int calcoloCostoPacchetto(DATI_PACCHETTO_VIAGGIO p, int prezzoHotel, float prezzoOrarioCompagnia){
	int costoVolo,costoHotel, sconto, costoTotale;
	/*Nel calcolo del costo le ore e i minuti vengono considerati come un unico valore, per farlo i minuti
	 * vengono trasformati in decimali (0.valore) dividendoli per 100 e quindi vengono sommati al valore delle
	 * ore, per considerarli come un unico valore � necessario un cast a float ad entrambi.
	 */
	costoVolo = ((((float)p.oreViaggioPacchetto + ((float)p.minutiViaggioPacchetto/100)) * prezzoOrarioCompagnia) * p.categoriaVoloPacchetto);
	costoHotel = prezzoHotel * p.giorniPacchetto;
	costoTotale = costoHotel + costoVolo + COSTO_TOUR_OPERATOR;
	//calcolo della percentuale di sconto
	sconto = (costoTotale * p.scontoPacchetto)/100;

	return costoTotale - sconto;
}

/**
 * Questa funzione serve ad aggiornare il costo totale di un pacchetto viaggio inseguito
 * alla modifica del prezzo di un hotel.
 * La funzione riceve in input l'id dell'hotel di cui e' stato modificato il prezzo.
 * Un for scorre tutti i pacchetti viaggio presenti in memoria, quando trova un pacchetto viaggio
 * che ha come idHotelPacchetto l'id dell'hotel ricevuto come parametro viene chiamata la funzione
 * calcoloCostoPacchetto per calcolare il nuovo costo del pacchetto viaggio.
 *
 * @post la funzione ritorna 1 se viene aggiornato il costo totale di almeno un pacchetto viaggio, 0 altrimenti
 */
int aggiornaCostoDaHotel (DATI_PACCHETTO_VIAGGIO p[],DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], int indiceHotel){
	int controllo = 0;
	for(int i = 0; i < MAX_NUM_PACCHETTI; i++){
		if(p[i].idPartenzaPacchetto != 0){
			if(p[i].idHotelPacchetto == h[indiceHotel].idHotel){
				p[i].costoTotalePacchetto = calcoloCostoPacchetto(p[i], h[indiceHotel].prezzoHotel , c[p[i].idCompagniaAereaPacchetto-1].prezzoOrarioCompagnia );

				controllo = 1;
			}
		}
	}

	if(controllo == 1){
		return 1;
	}else{
		return 0;
	}
}

/**
 * Questa funzione serve ad aggiornare il costo totale di un pacchetto viaggio inseguito
 * alla modifica del prezzo di una compagnia aerea.
 * La funzione riceve in input l'id della compagnia aerea di cui e' stato modificato il prezzo.
 * Un for scorre tutti i pacchetti viaggio presenti in memoria, quando trova un pacchetto viaggio
 * che ha come idCompagniaAereaPacchetto l'id della compagnia aerea ricevuta come parametro viene
 * chiamata la funzione calcoloCostoPacchetto per calcolare il nuovo costo del pacchetto viaggio.
 *
 * @post la funzione ritorna 1 se viene aggiornato il costo totale di almeno un pacchetto viaggio, 0 altrimenti
 */
int aggiornaCostoDaCompagnia (DATI_PACCHETTO_VIAGGIO p[],DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], int indiceCompagniaAerea){
	int controllo = 0;
	for(int i = 0; i < MAX_NUM_PACCHETTI; i++){
		if(p[i].idPartenzaPacchetto != 0){

			if(p[i].idCompagniaAereaPacchetto == c[indiceCompagniaAerea].idCompagnia){

				p[i].costoTotalePacchetto = calcoloCostoPacchetto(p[i], h[p[i].idHotelPacchetto-1].prezzoHotel , c[indiceCompagniaAerea].prezzoOrarioCompagnia);
				controllo = 1;
			}
		}
	}

	if(controllo == 1){
		return 1;
	}else{
		return 0;
	}
}

/**
* Questa funzione controlla se esiste gia' un pacchetto viaggio con i dati nuovi inseriti/modificati.
* Tramite un for che itera un numero di volte pari al numero massimo di pacchetti memorizzabili nel programma, controlla se
* i campi: idPartenzaPacchetto, idArrivoPacchetto, idCompagniaAereaPacchetto, categoriaVoloPacchetto, idHotelPacchetto,
* giorniPacchetto, idTourOperatorPacchetto, scontoPacchetto, sono uguali ai nuovi inseriti da tastiera.
* Se tutti corrispondono il flag sentinella viene settato a 0.
*
* Alla fine del controllo se il flag e' a 0, viene stampato l'errore che il pacchetto viaggio e' gia' presente in memoria.
*
* @post la funzione ritorna 0 se il pacchetto viaggio e' gia' presente in memoria oppure 1 se non e' presente
*/
int controlloPresenzaPacchettoViaggio(DATI_PACCHETTO_VIAGGIO p[], DATI_PACCHETTO_VIAGGIO pacchettoViaggioInserito){
	int flag = 1;

	for(int i = 0; i < MAX_NUM_PACCHETTI; i++){
		if(p[i].idPartenzaPacchetto == pacchettoViaggioInserito.idPartenzaPacchetto && p[i].idArrivoPacchetto == pacchettoViaggioInserito.idArrivoPacchetto)
		if(p[i].idCompagniaAereaPacchetto == pacchettoViaggioInserito.idCompagniaAereaPacchetto && p[i].categoriaVoloPacchetto == pacchettoViaggioInserito.categoriaVoloPacchetto)
		if(p[i].idHotelPacchetto == pacchettoViaggioInserito.idHotelPacchetto)
		if(p[i].giorniPacchetto == pacchettoViaggioInserito.giorniPacchetto)
		if(p[i].idTourOperatorPacchetto == pacchettoViaggioInserito.idTourOperatorPacchetto)
		if(p[i].scontoPacchetto == pacchettoViaggioInserito.scontoPacchetto)
			flag = 0;
	}

	return flag;
}

/**
 * Questa funzione permette di modificare i dati di un pacchetto viaggio.
 * La funzione prende in input tutti i dati del pacchetto viaggio che si vuole modificare, e anche
 * la scelta del dato che si vuole modificare. I diversi casi vengono gestiti tramite una switch,
 * in cui in base alla scelta del dato da modificare richiama le apposite funzioni per effettuare
 * la modifica.
 * Si puo' scegliere anche di modificare tutti i dati del pacchetto viaggio (caso 9 della switch), in questo caso
 * viene chiamata la funzione aggiungiPacchettoViaggio che permette di modificare tutti i dati del pacchetto viaggio scelto.
 *
 * @post La funzione ritorna un elemento di tipo DATI_PACCHETTO_VIAGGIO con le modifiche effettuate e gli eventuali dati non modificati.
 */
DATI_PACCHETTO_VIAGGIO modificaPacchettoViaggio(int scelta, DATI_PACCHETTO_VIAGGIO p, DATI_DESTINAZIONE d[], DATI_ORARIO_VOLO v[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[]){

	DATI_PACCHETTO_VIAGGIO pacchettoDaModificare = p;

	switch(scelta){
	 	case 1:

	 		printf("\nModificare la partenza [attuale: %s]\n", d[p.idPartenzaPacchetto-1].cittaDestinazione);
	 		pacchettoDaModificare.idPartenzaPacchetto = inserisciIdCitta(d, "Partenza");

	 		//controllo che la citt� di partenza inserita non sia uguale a quella di arrivo
	 		while(pacchettoDaModificare.idPartenzaPacchetto == pacchettoDaModificare.idArrivoPacchetto){
				puts("\nATTENZIONE!!! Inserire citta' di partenza diversa dall'arrivo\n");
				pacchettoDaModificare.idPartenzaPacchetto = inserisciIdCitta(d, "Partenza");
			}

	 		//aggiorna le ore di volo del pacchetto in base alla citt� modificata
	 		for(int i=0; i<NUM_VOLI; i++){
				if(v[i].partenzaVolo == pacchettoDaModificare.idPartenzaPacchetto && v[i].arrivoVolo == pacchettoDaModificare.idArrivoPacchetto){
					pacchettoDaModificare.oreViaggioPacchetto = v[i].oreVolo;
					pacchettoDaModificare.minutiViaggioPacchetto = v[i].minutiVolo;
				}
			}

	 		break;

	 	case 2:
	 		printf("\nModificare l'arrivo [attuale: %s]\n", d[p.idArrivoPacchetto-1].cittaDestinazione);
	 		pacchettoDaModificare.idArrivoPacchetto = inserisciIdCitta(d, "Arrivo");

	 		printf("%d - %d\n",p.idPartenzaPacchetto, p.idArrivoPacchetto);
	 		//controllo che la citt� di arrivo inserita non sia uguale a quella di partenza
	 		while(p.idPartenzaPacchetto == pacchettoDaModificare.idArrivoPacchetto){
				puts("\nATTENZIONE!!! Inserire citta' di arrivo diversa dalla partenza\n");
				pacchettoDaModificare.idArrivoPacchetto = inserisciIdCitta(d, "Arrivo");
			}

	 		//aggiorna le ore di volo del pacchetto in base alla citt� modificata
	 		for(int i=0; i<NUM_VOLI; i++){
				if(v[i].partenzaVolo == pacchettoDaModificare.idPartenzaPacchetto && v[i].arrivoVolo == pacchettoDaModificare.idArrivoPacchetto){
					pacchettoDaModificare.oreViaggioPacchetto = v[i].oreVolo;
					pacchettoDaModificare.minutiViaggioPacchetto = v[i].minutiVolo;
				}
			}

	 		pacchettoDaModificare.idHotelPacchetto = inserisciIdHotel(h, pacchettoDaModificare.idArrivoPacchetto);

	 		break;

	 	case 3:
	 		printf("\nModifica la compagnia aerea [attuale: %s]\n", c[p.idCompagniaAereaPacchetto-1].nomeCompagnia);
	 		pacchettoDaModificare.idCompagniaAereaPacchetto = inserisciIdCompagniaAerea(c);

	 		break;

	 	case 4:

			printf("\nModifica categoria di volo [attuale: ");
			if(p.categoriaVoloPacchetto == 1){
				puts("Economy]");
			}else{
				puts(" Business]");
			}
			pacchettoDaModificare.categoriaVoloPacchetto = inserisciCategoriaVolo();

	 		break;

	 	case 5:
			printf("\nModifica hotel [attuale: %s]\n", h[p.idHotelPacchetto-1].nomeHotel);
			pacchettoDaModificare.idHotelPacchetto = inserisciIdHotel(h, pacchettoDaModificare.idArrivoPacchetto);

			break;

	 	case 6:
			printf("\nModifica durata viaggio [attuale: %d giorni]\n", p.giorniPacchetto);
			pacchettoDaModificare.giorniPacchetto = inserisciGiorniPacchetto();

			break;

	 	case 7:
			printf("\nModifica il tour operator [attuale: %s]\n", t[p.idTourOperatorPacchetto-1].nomeTourOperator);
			pacchettoDaModificare.idTourOperatorPacchetto = inserisciIdTourOperator(t);

			break;

	 	case 8:
			printf("\nModifica lo sconto applicato al pacchetto  [attuale: %d%%]\n", p.scontoPacchetto);
			pacchettoDaModificare.scontoPacchetto = inserisciPercentualeSconto();

			break;

	 	case 9:
	 		printf("\nModifica di tutti i dati del pacchetto viaggio selezionato\n");
	 		pacchettoDaModificare = aggiungiPacchettoViaggio(d, v, c, h, t);

	 		break;
	}

	return pacchettoDaModificare;
}


/**
 * Funzione che raggruppa tutte le istruzioni necessarie a effettuare una modifica di un pacchetto viaggio.
 *
 */
void effettuaModificaPacchetto(int indiceMassimo, DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[], DATI_ORARIO_VOLO v[]){
	int sceltaIdModifica;
	int sceltaModifica;

	//controllo se in memoria sono presenti uno o pi� pacchetti viaggio
	if(contaPacchetti(p) != 0){

		indiceMassimo = stampaPacchettiViaggio(p, d, c, t, h);

		puts("\nInserire l'indice del pacchetto viaggio da modificare.\n");
		sceltaIdModifica = inserisciScelta(1, indiceMassimo, 3);

		menuModificaPacchettiViaggio();

		puts("\nScegliere cosa modificare.\n");
		sceltaModifica = inserisciScelta(NUM_MIN_MODIFICA_PACCHETTI, NUM_MAX_MODIFICA_PACCHETTI, 2);

		DATI_PACCHETTO_VIAGGIO pacchettoTemporaneo = modificaPacchettoViaggio(sceltaModifica, p[sceltaIdModifica - 1], d, v, c, h, t);

		if(confermaModifica("modificare") == 1){

			/*se i dati modificati non sono gi� presenti in memoria allora viene calcolato il
			 * nuovo costo del pacchetto modificato e poi questo viene caricato in memoria.*/
			if(controlloPresenzaPacchettoViaggio(p, pacchettoTemporaneo) != 0){

				/* h[pacchettoTemporaneo.idHotelPacchetto-1].prezzoHotel serve a considerare il prezzo dell'hotel
				 * contenuto nel pacchetto viaggio che si sta modificando, gli id degli hotel iniziano da 1 ma l'array hotel inizia
				 * dalla posizione 0, perci� serve il -1.
				 * c[pacchettoTemporaneo.idCompagniaAereaPacchetto-1].prezzoOrarioCompagnia serve a considerare il prezzo della
				 * compagnia aerea contenuta nel pacchetto viaggio che si sta modificando, il -1 serve per lo stesso motivo di prima.
				 *
				 */
				pacchettoTemporaneo.costoTotalePacchetto = calcoloCostoPacchetto(pacchettoTemporaneo, h[pacchettoTemporaneo.idHotelPacchetto-1].prezzoHotel, c[pacchettoTemporaneo.idCompagniaAereaPacchetto-1].prezzoOrarioCompagnia);
				p[sceltaIdModifica - 1] = pacchettoTemporaneo;

				puts("\n\nPERFETTO!!! Pacchetto viaggio modificato con successo.\n");
			}else{
				printf("\n\nERRORE!!! Il pacchetto viaggio modificato e' gia' presente in memoria.\n");
			}
		}

	}else{
		puts("\n\nATTENZIONE!!! Non e' presente nessun pacchetto\n\n");
	}

	printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");
}
