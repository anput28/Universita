#include <stdio.h>
#include "struttureDati.h"
#include "letturaFile.h"

/**
* Questa funzione legge dall'apposito file binario tutti i dati relativi agli hotel e li memorizza nel relativo array.
* Viene aperto il file 'hotel.dat' in lettura, vengono letti tutti i dati relativi agli hotel
* scorrendo tutto il file, tramite un ciclo while che segnala che non ci sono piu' dati da
* leggere quando la fread relativo all'indice dell'hotel restituisce 0.
* Tutti i dati letti dal file vengono memorizzati nell'array h passato come parametro.
*
* @pre i dati contenuti nel file 'hotel.dat' devono essere del giusto tipo e dimensione.
* @post la funzione ritorna 0 quando il file 'hotel.dat' non viene aperto correttamente oppure 1 quando tutti i dati vengono letti con successo
*/
int letturaHotel(DATI_HOTEL h[]){
	FILE *ptrHotel;
	int i=0;

	if((ptrHotel = fopen("datiProgetto/hotel.dat", "rb")) == NULL){
		puts("\nERRORE!!! Impossibile aprire il file 'hotel.dat'.");
		return 0;
	}else{
		while((fread(&h[i].idHotel, sizeof(h[i].idHotel), 1, ptrHotel)) != 0){
			fread(&h[i].nomeHotel, sizeof(h[i].nomeHotel), 1, ptrHotel);
			fread(&h[i].stelleHotel, sizeof(h[i].stelleHotel), 1, ptrHotel);
			fread(&h[i].prezzoHotel, sizeof(h[i].prezzoHotel), 1, ptrHotel);
			fread(&h[i].stanzeTotaliHotel, sizeof(h[i].stanzeTotaliHotel), 1, ptrHotel);
			fread(&h[i].stanzeLibereHotel, sizeof(h[i].stanzeLibereHotel), 1, ptrHotel);
			fread(&h[i].scontoMinoriHotel, sizeof(h[i].scontoMinoriHotel), 1, ptrHotel);
			fread(&h[i].idCittaHotel, sizeof(h[i].idCittaHotel), 1, ptrHotel);
			i += 1;
		}
	}
	fclose(ptrHotel);

	return 1;
}

/**
* Questa funzione legge dall'apposito file binario tutti i dati relativi alle compagnie aeree e li memorizza nel relativo array.
* Viene aperto il file 'compagnieAeree.dat' in lettura, vengono letti tutti i dati relativi alle
* compagnie aeree scorrendo tutto il file, tramite un ciclo while che segnala che non ci sono
* piu' dati da leggere quando la fread relativo all'indice della compagnia aerea restituisce 0.
* Tutti i dati letti dal file vengono memorizzati nell'array c passato come parametro.
*
* @pre i dati contenuti nel file 'compagnieAeree.dat' devono essere del giusto tipo e dimensione.
* @post la funzione ritorna 0 quando il file 'compagnieAeree.dat' non viene aperto correttamente oppure 1 quando tutti i dati vengono letti con successo
*/
int letturaCompagnieAeree(DATI_COMPAGNIA_AEREA c[]){
	FILE *ptrCompagnia;
	int i = 0;

	if((ptrCompagnia = fopen("datiProgetto/compagnieAeree.dat", "rb")) == NULL){
		puts("\nERRORE!!! Impossibile aprire il file 'compagniaAeree.dat'.");
		return 0;
	}else{
		while((fread(&c[i].idCompagnia, sizeof(c[i].idCompagnia), 1, ptrCompagnia)) != 0){
			fread(c[i].nomeCompagnia, sizeof(c[i].nomeCompagnia), 1, ptrCompagnia);
			fread(c[i].nazioneCompagnia, sizeof(c[i].nazioneCompagnia), 1, ptrCompagnia);
			fread(&c[i].prezzoOrarioCompagnia, sizeof(c[i].prezzoOrarioCompagnia), 1, ptrCompagnia);
			i += 1;
		}
	}
	fclose(ptrCompagnia);
	return 1;
}

/**
* Questa funzione legge tutti i dati relativi alle ore di volo da una citta' all'altra dal relativo file .dat.
* Viene aperto il file 'orariVoli.dat' in lettura, vengono letti tutti i dati relativi agli
* orari di volo scorrendo tutto il file, tramite un ciclo while che segnala che non ci sono piu' dati
* da leggere quando la fread relativo alla citta' di partenza restituisce 0.
* Tutti i dati letti dal file vengono memorizzati nell'array v passato come parametro.
*
* @pre i dati contenuti nel file 'orariVoli.dat' devono essere del giusto tipo e dimensione.
* @post la funzione ritorna 0 quando il file 'orariVoli.dat' non viene aperto correttamente oppure 1 quando tutti i dati vengono letti con successo
*/
int letturaOrariVoli(DATI_ORARIO_VOLO v[]){
	FILE *ptrOrariVoli;
	int i = 0;

	if((ptrOrariVoli = fopen("datiProgetto/orariVoli.dat", "rb")) == NULL){
		puts("\nERRORE!!! Impossibile aprire il file 'orariVoli.dat'.");
		return 0;
	}else{
		while((fread(&v[i].partenzaVolo, sizeof(v[i].partenzaVolo), 1, ptrOrariVoli)) != 0){
			fread(&v[i].arrivoVolo, sizeof(v[i].arrivoVolo), 1, ptrOrariVoli);
			fread(&v[i].oreVolo, sizeof(v[i].oreVolo), 1, ptrOrariVoli);
			fread(&v[i].minutiVolo, sizeof(v[i].minutiVolo), 1, ptrOrariVoli);
			i += 1;
		}
	}
	fclose(ptrOrariVoli);
	return 1;
}

/**
* Questa funzione legge dall'apposito file binario tutti i dati relativi alle citta' e li memorizza nel relativo array.
* Viene aperto il file 'destinazioni.dat' in lettura, vengono letti tutti i dati relativi alle
* destinazioni tramite un ciclo while che segnala che non ci sono piu' dati da leggere quando
* la fread relativo all'indice della destinazione restituisce 0.
* Tutti i dati letti dal file vengono memorizzati nell'array d passato come parametro.
*
* @pre i dati contenuti nel file 'destinazione.dat' devono essere del giusto tipo e dimensione.
* @post la funzione ritorna 0 quando il file 'destinazione.dat' non viene aperto correttamente oppure 1 quando tutti i dati vengono letti con successo
*/
int letturaDestinazioni(DATI_DESTINAZIONE d[]){
	FILE *ptrDestinazioni;
	int i = 0;

	if((ptrDestinazioni = fopen("datiProgetto/destinazioni.dat", "rb")) == NULL){
		puts("\nERRORE!!! Impossibile aprire il file 'destinazioni.dat'.");
		return 0;
	}else{
		while((fread(&d[i].idCittaDestinazione, sizeof(d[i].idCittaDestinazione), 1, ptrDestinazioni)) != 0){
			fread(d[i].cittaDestinazione, sizeof(d[i].cittaDestinazione), 1, ptrDestinazioni);
			fread(d[i].nazioneDestinazione, sizeof(d[i].nazioneDestinazione), 1, ptrDestinazioni);
			i += 1;
		}
	}
	fclose(ptrDestinazioni);
	return 1;
}

/**
* Questa funzione legge dall'apposito file binario tutti i dati relativi ai tour operator e li memorizza nel relativo array.
* Viene aperto il file 'tourOperator.dat' in lettura, vengono letti tutti i dati relativi ai
* tour operator scorrendo tutto il file, ramite un ciclo while che segnala che non ci sono piu'
* dati da leggere quando la fread relativo all'id del tour operator restituisce 0.
* Tutti i dati letti dal file vengono memorizzati nell'array t passato come parametro.
*
* @pre i dati contenuti nel file 'tourOperator.dat' devono essere del giusto tipo e dimensione.
* @post la funzione ritorna 0 quando il file 'tourOperator.dat' non viene aperto correttamente oppure 1 quando tutti i dati vengono letti con successo
*/
int letturaTourOperator(DATI_TOUR_OPERATOR t[]){
	FILE *ptrTourOperator;
	int i = 0;

	if((ptrTourOperator = fopen("datiProgetto/tourOperator.dat", "rb")) == NULL){
		puts("\nERRORE!!! Impossibile aprire il file 'tourOperator.dat'.");
		return 0;
	}else{
		while((fread(&t[i].idTourOperator, sizeof(t[i].idTourOperator), 1, ptrTourOperator)) != 0){
			fread(t[i].nomeTourOperator, sizeof(t[i].nomeTourOperator), 1, ptrTourOperator);
			fread(t[i].cittaTourOperator, sizeof(t[i].cittaTourOperator), 1, ptrTourOperator);
			fread(t[i].nazioneTourOperator, sizeof(t[i].nazioneTourOperator), 1, ptrTourOperator);
			i += 1;
		}
	}
	fclose(ptrTourOperator);
	return 1;
}

/**
* Questa funzione legge dall'apposito file binario tutti i dati relativi ai pacchetti viaggio e li memorizza nel relativo array.
* Viene aperto il file 'pacchettiViaggio.dat' in lettura, vengono letti tutti i dati relativi
* ai pacchetti viaggio scorrendo tutto il file, tramite un ciclo while che segnala che non ci
* sono piu' dati da leggere quando la fread relativo all'id della citta' di partenza restituisce 0.
* Tutti i dati letti dal file vengono memorizzati nell'array p passata come parametro.
*
* @pre i dati contenuti nel file 'pacchettiViaggio.dat' devono essere del giusto tipo e dimensione.
* @post la funzione ritorna 0 quando il file 'pacchettiViaggio.dat' non viene aperto correttamente oppure 1 quando tutti i dati vengono letti con successo
*/
int letturaPacchettiViaggio(DATI_PACCHETTO_VIAGGIO p[]){
	FILE *ptrPacchetti;
	int i = 0;

	if((ptrPacchetti = fopen("datiProgetto/pacchettiViaggio.dat", "rb")) == NULL){
		puts("\nERRORE!!! Impossibile aprire il file 'pacchettiViaggio.dat'.");
		return 0;
	}else{
		while((fread(&p[i].idPartenzaPacchetto, sizeof(p[i].idPartenzaPacchetto), 1, ptrPacchetti)) != 0){
			fread(&p[i].idArrivoPacchetto, sizeof(p[i].idArrivoPacchetto), 1, ptrPacchetti);
			fread(&p[i].oreViaggioPacchetto, sizeof(p[i].oreViaggioPacchetto), 1, ptrPacchetti);
			fread(&p[i].minutiViaggioPacchetto, sizeof(p[i].minutiViaggioPacchetto), 1, ptrPacchetti);
			fread(&p[i].idCompagniaAereaPacchetto, sizeof(p[i].idCompagniaAereaPacchetto), 1, ptrPacchetti);
			fread(&p[i].categoriaVoloPacchetto, sizeof(p[i].categoriaVoloPacchetto), 1, ptrPacchetti);
			fread(&p[i].giorniPacchetto, sizeof(p[i].giorniPacchetto), 1, ptrPacchetti);
			fread(&p[i].idHotelPacchetto, sizeof(p[i].idHotelPacchetto), 1, ptrPacchetti);
			fread(&p[i].idTourOperatorPacchetto, sizeof(p[i].idTourOperatorPacchetto), 1, ptrPacchetti);
			fread(&p[i].scontoPacchetto, sizeof(p[i].scontoPacchetto), 1, ptrPacchetti);
			fread(&p[i].costoTotalePacchetto, sizeof(p[i].costoTotalePacchetto), 1, ptrPacchetti);
			i += 1;
		}
	}
	fclose(ptrPacchetti);
	return 1;
}
