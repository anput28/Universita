/**
* @file struttureDati.h
*
* Questo header file contiene tutte le strutture dati utilizzate nel progetto.
*
* @version 0.1
* @authors Angelo Putignano, Roberto Modarelli
* @warning il programma non funziona se non viene inclusa in tutti i file in cui vengono usate le struttre dati che questa libreria contiene
*/

#include "costanti.h"

/**
Il tipo di dato DESTINAZIONI serve a rappresentare tutte le possibili destinazioni dei viaggi.


*/
typedef struct{
	int idCittaDestinazione;
	char cittaDestinazione[LUNGH_NOME_CITTA];
	char nazioneDestinazione[LUNGH_NOME_NAZIONE];
}DATI_DESTINAZIONE;


/**
Il tipo di dato DATI_HOTEL serve a rappresentare tutti i dati relativi agli hotel delle varie citt�
*/
typedef struct{
	int idHotel;
	char nomeHotel[LUNGH_NOME_HOTEL];
	int stelleHotel;
	int prezzoHotel;						//costo per notte per una singola persona, il prezzo � tondo quindi non serve un float
	int stanzeTotaliHotel;
	int stanzeLibereHotel;
	int scontoMinoriHotel;						//sconto in percentuale per gli eventuali minorenni
	int idCittaHotel;							//id della citt� in cui si trova l'hotel
}DATI_HOTEL;


/**
Il tipo di dato DATI_ORARIO_VOLIO serve a memorizzare la partenza, la destinazione e la durata di un volo
*/
typedef struct{
	int partenzaVolo;				//id della citt� di partenza del volo il cui nome � contenuto in DATI_DESTINAZIONE
	int arrivoVolo;					//id della citt� di arrivo del volo il cui nome � contenuto in DATI_DESTINAZIONE
	int oreVolo;					//ore di volo
	int minutiVolo;					//minuti di volo
}DATI_ORARIO_VOLO;


/**
Il tipo di dato DATI_COMPAGNIA_AEREA serve a memorizzare i dati relativi a una compagnia aerea
*/
typedef struct{
	int idCompagnia;								//identificatore della compagnia
	char nomeCompagnia[LUNGH_NOME_COMPAGNIA];		//nome della compagnia
	char nazioneCompagnia[LUNGH_NOME_NAZIONE];		//nazione di appartenenza della compagnia aerea
	float prezzoOrarioCompagnia;					//costo per ora di volo
}DATI_COMPAGNIA_AEREA;


/**
Il tipo di dato DATI_TOUR_OPERATOR serve a memorizzare i dati relativi ai tuor operator
*/
typedef struct{
	int idTourOperator;									//identificatore del tour operator
	char nomeTourOperator[LUNGH_NOME_TOUR_OPERATOR];
	char cittaTourOperator[LUNGH_NOME_CITTA];			//citta' in cui ha sede il tour operator
	char nazioneTourOperator[LUNGH_NOME_NAZIONE];		//nazione in cui ha sede il tour operator
}DATI_TOUR_OPERATOR;

/**
Il tipo di dato DATI_PACCHETTI_VIAGGIO serve a memorizzare i dati relativi ai pacchetti viaggio
*/
typedef struct{
	int idPartenzaPacchetto;			//id della citt� di partenza del viaggio
	int idArrivoPacchetto;				//id della citt� di arrivo del viaggio
	int oreViaggioPacchetto;
	int minutiViaggioPacchetto;
	int idCompagniaAereaPacchetto;		//id della compagnia aerea usata per il viaggio
	int categoriaVoloPacchetto;			//1 per indicare la categoria economy e 2 per indicare la categoria business
	int giorniPacchetto;				//i giorni di permanenza nella citt� di arrivo offerti nel pacchetto
	int idHotelPacchetto;				//id dell'hotel nella citt� di arrivo in cui si allogger�
	int idTourOperatorPacchetto;		//id del tour operator che ha creato il pacchetto
	int scontoPacchetto;
	int costoTotalePacchetto;
}DATI_PACCHETTO_VIAGGIO;
