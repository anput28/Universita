#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "costanti.h"
#include "struttureDati.h"
#include "controlloInput.h"
#include "letturaFile.h"
#include "creazioneFileTestuali.h"
#include "scritturaFile.h"
#include "stampaMenu.h"
#include "aggiungiDati.h"
#include "eliminaDatiHotel.h"
#include "eliminaDatiCompagnie.h"
#include "eliminaDatiOperator.h"
#include "eliminaDatiPacchetti.h"
#include "modificaDati.h"
#include "modificaDatiPacchetto.h"
#include "stampaDati.h"
#include "ricercaDati.h"

int main(void) {
	/*le due coppie di parentesi graffe servono per non far apparire un warning
	 * derivante dal bug 53119 di GCC. Se si usa solo una coppia di parentesi per inizializzare
	 * un dato di tipo struct appare il seguente warning : missing braces around initializer.
	 */
	DATI_HOTEL hotel[MAX_NUM_HOTEL] = {{0, " ",  0, 0, 0, 0, 0, 0}}; //inizializzo hotel a valori di default
	DATI_PACCHETTO_VIAGGIO pacchettiViaggio[MAX_NUM_PACCHETTI] = {{0,0,0,0,0,0,0,0,0,0,0}};  //inizializzo pacchettiViaggio a valori di default
	DATI_COMPAGNIA_AEREA compagnieAeree[MAX_NUM_COMPAGNIE] = {{0, " ", " ", 0.0}}; //inizializzo comagnieAeree a valori di default
	DATI_DESTINAZIONE destinazioni[NUM_DESTINAZIONI] = {{0, " ", " "}}; //inizializzo destinazioni a valori di default
	DATI_TOUR_OPERATOR tourOperator[MAX_NUM_TOUR_OPERATOR] = {{0, " ", " ", " "}}; //inizializzo tourOperator a valori di default
	DATI_ORARIO_VOLO voli[NUM_VOLI] = {{0,0,0,0}}; //inizializzo voli a valori di default

	int sceltaAccesso;
	int sceltaMenu, sceltaSottoMenu, sceltaMenuFinale;
	int maxIndice; //serve a memorizzare il numero di valori contenuti nelle varie struct
	int controlloFileTestuali = 0; //valore sentinella che indica se � stato creato un file testuale

	setvbuf(stdout, NULL, _IONBF, 0);

	//------------------------------------------INIZIO CARICAMENTO DEI DATI DEI FILE .dat------------------------------------------

	letturaHotel(hotel);
	letturaCompagnieAeree(compagnieAeree);
	letturaOrariVoli(voli);
	letturaDestinazioni(destinazioni);
	letturaTourOperator(tourOperator);
	letturaPacchettiViaggio(pacchettiViaggio);

	//------------------------------------------FINE CARICAMENTO DEI DATI DEI FILE .dat------------------------------------------

	printf("\t+-+-+-+-+-+-+-+-+ AGENZIA VIAGGI +-+-+-+-+-+-+-+-+\n\n");
	printf("\tSoftware per la gestione di un'agenzia di viaggi.\n\n\n");

	menuAccesso(); //menu per scegliere se si usa il programma come amministratore o come utente
	/* i parametri di inserisciScelta rispettivamente indicano: la prima voce del menu, l'ultima
	 * voce del menu e numero massimo, di caratteri accettati per la scelta. */
	sceltaAccesso = inserisciScelta(1, 2, 2);

	do{
		menuPrincipale();
		sceltaMenu = inserisciScelta(NUM_MIN_MENU_PRINCIPALE,NUM_MAX_MENU_PRINCIPALE, 2);

		switch(sceltaMenu){
			case 1:

				do{
					maxIndice = stampaPacchettiViaggio(pacchettiViaggio, destinazioni, compagnieAeree, tourOperator, hotel);

					//se si accede come amministratore si possono aggiungere, modificare e eliminare i pacchetti viaggio
					if(sceltaAccesso == 2){
						menuPacchettiViaggio();
						sceltaSottoMenu = inserisciScelta(NUM_MIN_SOTTOMENU,NUM_MAX_SOTTOMENU, 2);

//-----------------------------------------------AGGIUNTA PACCHETTI VIAGGIO-------------------------------------------------------------------------
						if(sceltaSottoMenu == 1){
							if(maxIndice < MAX_NUM_PACCHETTI){
								effettuaAggiuntaPacchetto(maxIndice, pacchettiViaggio, destinazioni, voli, compagnieAeree, hotel, tourOperator);
							}else{
								printf("\nATTENZIONE!!! Impossibile aggiungere un altro pacchetto."
										"		Numero massimo di pacchetti raggiunto.\n");

								printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");

							}

//-----------------------------------------------MODIFICA PACCHETTI VIAGGIO-------------------------------------------------------------------------
						}else if(sceltaSottoMenu == 2){

							effettuaModificaPacchetto(maxIndice, pacchettiViaggio, destinazioni, compagnieAeree, hotel, tourOperator, voli);

//-----------------------------------------------ELIMINAZIONE PACCHETTI VIAGGI-------------------------------------------------------------------------
						}else if(sceltaSottoMenu == 3){
							effettuaRimozionePacchetto(maxIndice, pacchettiViaggio, destinazioni, compagnieAeree, hotel, tourOperator);
						}

					}else{
						/*se si accede come utente non si possono modificare, eliminare o aggiugnere pacchetti
						 *Quindi per evitare di fare queste cose la sceltaSottoMenu viene messa a NUM_MAX_SOTTOMENU,
						 *cio� viene selezionata automaticamente la voce per tornare indietro dal sottomenu, quindi
						 *in questo modo non verr� mai data all'utente la possibilit� di aggiungere, eliminare o modificare
						 *un pacchetto ma solo di visualizzarli.
						 */
						sceltaSottoMenu = NUM_MAX_SOTTOMENU;
					}
				}while(sceltaSottoMenu != NUM_MAX_SOTTOMENU);

				break;

			case 2:
				do{
					maxIndice = stampaHotel(hotel, destinazioni);

					if(sceltaAccesso == 2){

						menuHotel();
						sceltaSottoMenu = inserisciScelta(NUM_MIN_SOTTOMENU,NUM_MAX_SOTTOMENU, 2);

//-----------------------------------------------AGGIUNTA HOTEL -------------------------------------------------------------------------
						if(sceltaSottoMenu == 1){
							if(maxIndice < MAX_NUM_HOTEL){
								effettuaAggiuntaHotel(maxIndice, hotel, destinazioni);
						}else{
							printf("\nATTENZIONE!!! Impossibile aggiungere un altro hotel."
									"		Numero massimo di hotel raggiunto.\n");

							printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");

						}
//-----------------------------------------------MODIFICA HOTEL-------------------------------------------------------------------------
						}else if(sceltaSottoMenu == 2){
							effettuaModificaHotel(maxIndice, hotel, destinazioni, pacchettiViaggio, compagnieAeree);

//-----------------------------------------------ELIMINAZIONE HOTEL-------------------------------------------------------------------------
						}else if(sceltaSottoMenu == 3){
							effettuaRimozioneHotel(maxIndice, hotel, destinazioni, pacchettiViaggio);
						}

					}else{
						sceltaSottoMenu = NUM_MAX_SOTTOMENU;
					}
				}while(sceltaSottoMenu != NUM_MAX_SOTTOMENU);
				break;

			case 3:

				do{
					maxIndice = stampaTourOperator(tourOperator);

					if(sceltaAccesso == 2){

						menuTourOperator();
						sceltaSottoMenu = inserisciScelta(NUM_MIN_SOTTOMENU,NUM_MAX_SOTTOMENU, 2);

//-----------------------------------------------AGGIUNTA TOUR OPERATOR-------------------------------------------------------------------------
						if(sceltaSottoMenu == 1){
							effettuaAggiuntaOperator(maxIndice, tourOperator);

//-----------------------------------------------MODIFICA TOUR OPERATOR-------------------------------------------------------------------------
						}else if(sceltaSottoMenu == 2){
							if(maxIndice < MAX_NUM_TOUR_OPERATOR){
								effettuaModificaOperator(maxIndice, tourOperator);
							}else{
								printf("\nATTENZIONE!!! Impossibile aggiungere un altro tour operator."
										"		Numero massimo di tour operator raggiunto.\n");

								printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");

							}

//-----------------------------------------------ELIMINAZIONE TOUR OPERATOR-------------------------------------------------------------------------
						}else if(sceltaSottoMenu == 3){
							effettuaRimozioneOperator(maxIndice, tourOperator, pacchettiViaggio);
						}

					}else{
						sceltaSottoMenu = NUM_MAX_SOTTOMENU;
					}
				}while(sceltaSottoMenu != NUM_MAX_SOTTOMENU);

				break;

			case 4:
				do{
					maxIndice = stampaCompagnieAeree(compagnieAeree);

					if(sceltaAccesso == 2){
						menuCompagnieAeree();
						sceltaSottoMenu = inserisciScelta(NUM_MIN_SOTTOMENU,NUM_MAX_SOTTOMENU, 2);

//-----------------------------------------------AGGIUNGI COMPAGNIA AEREA-------------------------------------------------------------------------
						if(sceltaSottoMenu == 1){
							if(maxIndice < MAX_NUM_COMPAGNIE){
								effettuaAggiuntaCompagnia(maxIndice, compagnieAeree);
							}else{
								printf("\nATTENZIONE!!! Impossibile aggiungere un altra compagnia aerea."
										"		Numero massimo di compagnie raggiunto.\n");

								printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");

							}

//-----------------------------------------------MODIFICA COMPAGNIA AEREA-------------------------------------------------------------------------
						}else if(sceltaSottoMenu == 2){
							effettuaModificaCompagnia(maxIndice, compagnieAeree, hotel, pacchettiViaggio);

//-----------------------------------------------ELIMINAZIONE COMPAGNIA AEREA-------------------------------------------------------------------------
						}else if(sceltaSottoMenu == 3){
							effettuaRimozioneCompagnia(maxIndice, compagnieAeree, pacchettiViaggio);
						}

					}else{
						sceltaSottoMenu = NUM_MAX_SOTTOMENU;
					}
				}while(sceltaSottoMenu != NUM_MAX_SOTTOMENU);

				break;

//-----------------------------------------------RICERCA PACCHETTI VIAGGIO-------------------------------------------------------------------------
			case 5:
				effettuaRicercaDati(pacchettiViaggio, destinazioni, voli, compagnieAeree, hotel, tourOperator);

				break;

			default:
				break;
		}

	}while(sceltaMenu != NUM_MAX_MENU_PRINCIPALE);

//----------------------------------------------- USCITA PROGRAMMA -------------------------------------------------------------------------

	menuFinale();
	sceltaMenuFinale = inserisciScelta(NUM_MIN_MENU_FINALE,NUM_MAX_MENU_FINALE, 2);
	if(sceltaMenuFinale == NUM_MIN_MENU_FINALE){
		controlloFileTestuali = gestisciCreazioneFileTestuali(destinazioni, compagnieAeree, hotel, tourOperator, pacchettiViaggio);
	}
	//stampa la guida per vedere i file testuali con Excel solo se viene creato un file testuale
	if(controlloFileTestuali == 1){
		printf("\n\n\nATTENZIONE!!! Per aprire i file testuali con ecxel, bisogna seguire questa guida:\n\n");
		printf(	"1) Selezionare la  prima colonna (A) che contiene il testo da dividere.\n"
				"2) Selezionare 'Dati'> 'Testo in colonne'.\n"
				"3) Nella Conversione guidata testo in colonne selezionare 'Delimitato' > 'Avanti'.\n"
				"4) Selezionare 'Virgola'> 'Avanti'.\n"
				"5) Selezionare 'Fine'.\n");
	}

//----------------------------------------------- SCRITTURA SU FILE -------------------------------------------------------------------------
	scritturaHotel(hotel);
	scritturaCompagniaAerea(compagnieAeree);
	scritturaTourOperator(tourOperator);
	scritturaPacchettiViaggio(pacchettiViaggio);

	puts("\n\n\nARRIVEDERCI");

	return 0;
}
