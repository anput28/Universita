 /**
 *  @file eliminaDatiHotel.h
 *
 * Questo header file contiene tutte le funzioni relative all'eliminazione di un hotel,
 * comprese le funzioni per l'aggiornamento dei pacchetti viaggio inseguito all'eliminazione degli hotel.
 *
 * @version 0.1
 * @authors Angelo Putignano, Roberto Modarelli
 */

/**
 * Questa funzione serve a contare il numero di hotel presenti in memoria.
 * @param h Array che contiene i dati degli hotel.
 * @param[in] idHotel Id dell'hotel selezionato
 *
 * @return 1 se nella citta' e' presente pi di un hotel
 * @return 0 se nella citta' non ci sono hotel
 */
int contaHotelPerCitta(DATI_HOTEL h[], int idHotel);

/**
 * Questa funzione elimina un hotel dalla memoria.
 * @param[in] indiceHotel E' l'id dell'hotel da eliminare
 * @param[in] h[] Array che contiene tutti gli hotel
 * @param[in] p[] Array che contiene i pacchetti viaggio, serve per aggiornarli dopo l'eliminazione dell'hotel
 * @param[in] indiceMassimo Contiene la posizione dell'ultimo hotel presente in memoria.
 *
 * @return 1 se il primo e l'ultimo campo dell'hotel da eliminare si trovano a valori di default, 0 altrimenti
 */
int eliminaHotel(int indiceHotel, DATI_HOTEL h[], DATI_PACCHETTO_VIAGGIO p[], int indiceMassimo);

/**
 * Questa funzione riordina gli hotel e i loro id dopo l'eliminazione di uno di essi.
 * @param[in] indice E' l'id dell'hotel che e' stato eliminato
 * @param[in] h[] Array che contiene tutti gli hotel.
 *
 * @return la nuova posizione dell'hotel eliminato nel relativo array degli hotel.
 */
int  riordinaHotel(int indice, DATI_HOTEL h[]);

/**
 * Questa funzione aggiorna i pacchetti viaggio presenti in memoria inseguito all'eliminazione di un hotel
 * @param[in] indiceHotel E' l'id dell'hote che e' stato eliminato.
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria.
 */
void aggiornaPacchettiDaHotel(int indiceHotel, DATI_PACCHETTO_VIAGGIO p[]);

/**
 * Questa funzione elimina un pacchetto viaggio in seguito alla rimozione di un hotel.
 * @param[in] posPacchetto E' la posizione nel relativo array del pacchetto viaggio da eliminare.
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria
 * @param[in] indiceHotel L'id dell'hotel che e' stato eliminato
 *
 * @return 1 se il primo e l'ultimo campo del pacchetto viaggio da eliminare si trovano a valori di default, 0 altrimenti
 */
int eliminaPacchettoDaHotel(int posPacchetto, DATI_PACCHETTO_VIAGGIO p[], int indiceHotel);


/**
 * Questa funzione raggruppa tutte le istruzioni necessarie ad effettuare la rimozione di un hotel.
 * @param[in] indiceMassimo Posizione dell'ultimo hotel caricato in memoria nel relativo array
 * @param[in] h[] Array che contiene tutti i  degli hotel
 * @param[in] d[] Array che contiene tutte le possibili destinazioni dei viaggi
 * @param[in] p[] Array che contiene tutti i pacchetti viaggio
 */
void effettuaRimozioneHotel(int indiceMassimo, DATI_HOTEL h[], DATI_DESTINAZIONE d[], DATI_PACCHETTO_VIAGGIO p[]);
