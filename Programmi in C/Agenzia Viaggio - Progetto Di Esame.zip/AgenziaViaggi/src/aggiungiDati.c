#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "costanti.h"
#include "struttureDati.h"
#include "controlloInput.h"
#include "controlloInputHotel.h"
#include "controlloInputPacchetto.h"
#include "modificaDatiPacchetto.h"
#include "modificaDati.h"
#include "aggiungiDati.h"

//variabili globali che servono ogni volta che viene usata la funzione inserireNome.
char simboliHotel[NUM_SIMBOLI_HOTEL] =  {'-', '$', '_', '!', '\'', '#', '*', '&', ' '}; //elenco dei simboli accettabili nel nome di un hotel
char simboliCompagnia[NUM_SIMBOLI_COMPAGNIA] = {'-', '&', '.', ' '};  //elenco dei simboli accettabili nel nome di una compagnia aerea
char simboliOperator[NUM_SIMBOLI_OPERATOR] = {'&', '.', ' '}; //elenco dei simboli accettabili nel nome di un tour operator


/**
 * Questa funzione si occupa di chiamare le funzioni che permettono di aggiungere i singoli dati di un pacchetto viaggio.
 * Vengono chiamate in ordine tutte le funzioni che permettono di inserire i dati del nuovo pacchetto viaggio.
 * Un ciclo while controlla che l'utente non inserisce la citta' di partenza uguale alla citta' di arrivo.
 * Con un ciclo for scorre l'array dove sono presenti tutti gli orari di voli, per prendere le ore e i minuti di viaggio.
 *
 * @post la funzione ritorna l'insieme dei dati inseriti in un record di tipo DATI_PACCHETTO_VIAGGIO
 */
DATI_PACCHETTO_VIAGGIO aggiungiPacchettoViaggio(DATI_DESTINAZIONE d[], DATI_ORARIO_VOLO v[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[]){
	DATI_PACCHETTO_VIAGGIO pacchettoAggiunto = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

	pacchettoAggiunto.idPartenzaPacchetto = inserisciIdCitta(d, "Partenza");
	pacchettoAggiunto.idArrivoPacchetto = inserisciIdCitta(d, "Arrivo");

	while(pacchettoAggiunto.idPartenzaPacchetto == pacchettoAggiunto.idArrivoPacchetto){
		puts("\nATTENZIONE!!! Inserire citta' di arrivo diversa dalla partenza\n");
		pacchettoAggiunto.idArrivoPacchetto = inserisciIdCitta(d, "Arrivo");
	}

	/*scorre tutti i dati contenuti nell'array 'voli' e quando trova la citt� di partenza e di arrivo inserite
	 * precedentemente salva nel pacchetto temporaneo le ore e i minuti di volo*/
	for(int i=0; i<NUM_VOLI; i++){
		if(v[i].partenzaVolo == pacchettoAggiunto.idPartenzaPacchetto && v[i].arrivoVolo == pacchettoAggiunto.idArrivoPacchetto){
			pacchettoAggiunto.oreViaggioPacchetto = v[i].oreVolo;
			pacchettoAggiunto.minutiViaggioPacchetto = v[i].minutiVolo;
		}
	}

	pacchettoAggiunto.idCompagniaAereaPacchetto = inserisciIdCompagniaAerea(c);
	pacchettoAggiunto.categoriaVoloPacchetto = inserisciCategoriaVolo();
	pacchettoAggiunto.giorniPacchetto = inserisciGiorniPacchetto();
	pacchettoAggiunto.idHotelPacchetto = inserisciIdHotel(h, pacchettoAggiunto.idArrivoPacchetto);
	pacchettoAggiunto.idTourOperatorPacchetto = inserisciIdTourOperator(t);
	pacchettoAggiunto.scontoPacchetto = inserisciPercentualeSconto();

	pacchettoAggiunto.costoTotalePacchetto  = calcoloCostoPacchetto(pacchettoAggiunto, h[pacchettoAggiunto.idHotelPacchetto-1].prezzoHotel, c[pacchettoAggiunto.idCompagniaAereaPacchetto-1].prezzoOrarioCompagnia);


	return pacchettoAggiunto;
}


/**
 * Questa funzione si occupa di chiamare le funzioni che permettono di aggiungere i singoli dati di un hotel.
 * Il parametro ultimoElemento contiene l'indice dell'ultimo elemento contenuto nell'array degli hotel e
 * viene utilizzato per calcolare l'id del nuovo hotel.
 * Poi vengono chiamate in ordine tutte le funzioni che permettono di inserire i dati del nuovo hotel.
 *
 * @post la funzione ritorna l'insieme dei dati inseriti in una variabile di tipo DATI_HOTEL
 */
DATI_HOTEL aggiungiHotel(DATI_DESTINAZIONE d[], int ultimoElemento){
	DATI_HOTEL hotelAggiunto = {0, " ",  0, 0, 0, 0, 0, 0};
	hotelAggiunto.idHotel = ultimoElemento+1;
	strcpy(hotelAggiunto.nomeHotel, inserireNome(LUNGH_NOME_HOTEL, simboliHotel, NUM_SIMBOLI_HOTEL ,"hotel", NUM_MIN_LETTERE_HOTEL,NUM_MAX_SIMBOLI_HOTEL,NUM_MAX_NUMERI_HOTEL));
	hotelAggiunto.stelleHotel = inserireStelle(MIN_NUM_STELLE, MAX_NUM_STELLE);
	hotelAggiunto.prezzoHotel = inserirePrezzoHotel(hotelAggiunto.stelleHotel);
	hotelAggiunto.stanzeTotaliHotel = inserireStanzeTotali(MIN_STANZE_TOTALI, MAX_STANZE_TOTALI);
	hotelAggiunto.stanzeLibereHotel = inserireStanzeLibere(hotelAggiunto.stanzeTotaliHotel);
	hotelAggiunto.scontoMinoriHotel = inserireScontoHotel(MAX_SCONTO_HOTEL);
	hotelAggiunto.idCittaHotel= inserireIdCittaHotel(d);

	return hotelAggiunto;
}

/**
 * Questa funzione si occupa di chiamare le funzioni che permettono di aggiungere i singoli dati di una compagnia aerea.
 * Il parametro ultimoElemento contiene l'indice dell'ultimo elemento contenuto nell'array delle compagnie aeree e
 * viene utilizzato per calcolare l'id della nuova comapagnia aerea.
 * Poi vengono chiamate in ordine tutte le funzioni che permettono di inserire i dati della nuova compagnia aerea.
 *
 * @post la funzione ritorna l'insieme dei dati inseriti in una variabile di tipo DATI_COMPAGNIA_AEREA
 */
DATI_COMPAGNIA_AEREA aggiungiCompagnia(int ultimoElemento){
	DATI_COMPAGNIA_AEREA compagniaAggiunta = {0, " ", " ", 0.0};
	compagniaAggiunta.idCompagnia = ultimoElemento+1;
	strcpy(compagniaAggiunta.nomeCompagnia, inserireNome(LUNGH_NOME_COMPAGNIA, simboliCompagnia, NUM_SIMBOLI_COMPAGNIA,"compagnia aerea", NUM_MIN_LETTERE_COMPAGNIA,NUM_MAX_SIMBOLI_COMPAGNIA,NUM_MAX_NUMERI_COMPAGNIA));
	strcpy(compagniaAggiunta.nazioneCompagnia, inserirePaese(LUNGH_NOME_NAZIONE, "compagnia aerea", "NAZIONE", NUM_MIN_LETTERE_NAZIONE));
	compagniaAggiunta.prezzoOrarioCompagnia = inserirePrezzoCompagnia(MIN_PREZZO_COMPAGNIA, MAX_PREZZO_COMPAGNIA);

	return compagniaAggiunta;
}

/**
 * Questa funzione si occupa di chiamare le funzioni che permettono di aggiungere i singoli dati di un tour operator
 * Il parametro ultimoElemento contiene l'indice dell'ultimo elemento contenuto nell'array dei tour operator e
 * viene utilizzato per calcolare l'id del nuovo tour operator.
 * Poi vengono chiamate in ordine tutte le funzioni che permettono di inserire i dati del nuovo tour operator.
 *
 * @post la funzione ritorna l'insieme dei dati inseriti in una variabile di tipo DATI_TOUR_OPERATOR
 */
DATI_TOUR_OPERATOR aggiungiTourOperator(int ultimoElemento){
	DATI_TOUR_OPERATOR operatorAggiunto = {0, " ", " ", " "};
	operatorAggiunto.idTourOperator = ultimoElemento+1;
	strcpy(operatorAggiunto.nomeTourOperator, inserireNome(LUNGH_NOME_TOUR_OPERATOR, simboliOperator, NUM_SIMBOLI_OPERATOR,"tour operator", NUM_MIN_LETTERE_OPERATOR,NUM_MAX_SIMBOLI_OPERATOR,NUM_MAX_NUMERI_OPERATOR));
	strcpy(operatorAggiunto.cittaTourOperator, inserirePaese(LUNGH_NOME_CITTA, "tour operator", "CITTA'", NUM_MIN_LETTERE_CITTA));
	strcpy(operatorAggiunto.nazioneTourOperator, inserirePaese(LUNGH_NOME_NAZIONE, "tour operator", "NAZIONE", NUM_MIN_LETTERE_NAZIONE));

	return operatorAggiunto;
}

/**
 * Questa funzione raggruppa tutte le istruzioni che servono per aggiungere un pacchetto viaggio in memoria.
 */
void effettuaAggiuntaPacchetto(int indiceMassimo, DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_ORARIO_VOLO v[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[]){
	//i dati del nuovo pacchetto viaggio vengono memorizzati in una variabile temporanea
	DATI_PACCHETTO_VIAGGIO pacchettoTemporaneo = aggiungiPacchettoViaggio(d, v, c, h, t);

	//se il controllo sui dati del nuovo pacchettoViaggio va a buon fine allora i dati vengono memorizzati.
	if(controlloPresenzaPacchettoViaggio(p, pacchettoTemporaneo) != 0){
		p[indiceMassimo] = pacchettoTemporaneo;
		puts("\n\nPERFETTO!!! Pacchetto Viaggio aggiunto con successo.\n");
	}else{
		puts("\n\nERRORE!!!  Il pacchetto viaggio e' gia' presente in memoria.\n");
		puts("Si prega di inserire solo nuovi dati...\n");
	}
	//l'esecuzione si ferma per tre secondi per dare il tempo all'utente di leggere i messaggi.
	//animazione che stampa tre punti ognuno ad una distanza di un secondo dall'altro
	printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");
}

/**
 * Questa funzione raggruppa tutte le istruzioni che servono per aggiungere un hotel in memoria.
 *
 */
void effettuaAggiuntaHotel(int indiceMassimo, DATI_HOTEL h[], DATI_DESTINAZIONE d[]){
	//i dati del nuovo hotel vengono memorizzati in una variabile temporanea
	DATI_HOTEL hotelTemporaneo = aggiungiHotel(d, indiceMassimo);

	//se il controllo sui dati del nuovo hotel va a buon fine allora i dati vengono memorizzati.
	if(controlloPresenzaHotel(h, hotelTemporaneo, d) != 0){
		h[indiceMassimo] = hotelTemporaneo;
		puts("\nPERFETTO!!! Hotel aggiunto con successo.\n");
	}else{
		printf("\nERRORE!!! L'Hotel '%s' e' gia' presente in memoria.\n", hotelTemporaneo.nomeHotel);
		puts("Si prega di inserire solo nuovi dati...");
	}
	printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");

}

/**
 * Questa funzione raggruppa tutte le istruzioni che servono per aggiungere un tour operator in memoria.
 */
void effettuaAggiuntaOperator(int indiceMassimo, DATI_TOUR_OPERATOR t[]){
	DATI_TOUR_OPERATOR operatorTemporaneo = aggiungiTourOperator(indiceMassimo);
	if(controlloPresenzaTourOperator(t, operatorTemporaneo) != 0){
		t[indiceMassimo] = operatorTemporaneo;
		puts("\nPERFETTO!!! Tour Operator aggiunto con successo.\n");
	}else{
		printf("\nERRORE!!! Il tour operator '%s' e' gia' presente in memoria.\n", operatorTemporaneo.nomeTourOperator);
		puts("Si prega di inserire solo nuovi dati...");
	}

	printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");
}

/**
 * Questa funzione raggruppa tutte le istruzioni che servono per aggiungere una compagnia in memoria.
 */
void effettuaAggiuntaCompagnia(int indiceMassimo, DATI_COMPAGNIA_AEREA c[]){
	DATI_COMPAGNIA_AEREA compagniaTemporanea = aggiungiCompagnia(indiceMassimo);
	if(controlloPresenzaCompagnia(c, compagniaTemporanea) != 0){
		c[indiceMassimo] = compagniaTemporanea;
		puts("\nPERFETTO!!! Compagnia aerea aggiunta con successo.\n");
	}else{
		printf("\nERRORE!!! La compagnia aerea '%s' e' gia' presente in memoria.\n", compagniaTemporanea.nomeCompagnia);
		puts("Si prega di inserire solo nuovi dati...");
	}

	printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");
}
