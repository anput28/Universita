#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "costanti.h"
#include "struttureDati.h"
#include "controlloInput.h"
#include "modificaDati.h"
#include "modificaDatiPacchetto.h"
#include "stampaMenu.h"
#include "stampaDati.h"
#include "eliminaDatiPacchetti.h"

/**
 * Questa funzione serve a contare i pacchetti viaggio presenti in memoria.
 * Tramite un for la funzione scorre tutto l'array in cui sono contenuti i pacchetti viaggio, e se l'idPartenzaPacchetto non e' 0
 * (cioe' il pacchetto viaggio ha valori significativi e non di default) incrementa un contatore.
 *
 * @post La funzione ritora il numero di pacchetti viaggio presenti in memoria
 */
int contaPacchetti(DATI_PACCHETTO_VIAGGIO p[]){

	int contaPacchetti = 0;

	for(int i = 0; i < MAX_NUM_PACCHETTI; i++){
		if(p[i].idPartenzaPacchetto != 0){
			contaPacchetti += 1;
		}
	}

	return contaPacchetti;
}

/**
 * Questa funzione elimina un pacchetto viaggio dalla memoria.
 * I dati del pacchetto viaggio che si trova in posizione 'posPacchetto' nell'array dei pacchetti
 * viaggio vengono impostati a valori di default.
 * Dopo aver eliminato il pacchetto viaggio, se questo non e' l'ultimo contenuto nel relativo array,
 * viene riordinato il suddetto array che contiene i pacchetti viaggio.
 * Se il primo e l'ultimo campo di un pacchetto viaggio hanno il valore di default allora si assume
 * che anche i restanti campi abbiamo apportato con successo la modifica.
 *
 * @post ritorna 1 se il primo e l'ultimo campo di un pacchetto viaggio hanno il valore di default, 0 altrimenti.
 */
int eliminaPacchettiViaggio(int posPacchetto, DATI_PACCHETTO_VIAGGIO p[]){
	p[posPacchetto].idPartenzaPacchetto = 0;
	p[posPacchetto].idArrivoPacchetto = 0;
	p[posPacchetto].oreViaggioPacchetto = 0;
	p[posPacchetto].minutiViaggioPacchetto = 0;
	p[posPacchetto].idCompagniaAereaPacchetto = 0;
	p[posPacchetto].categoriaVoloPacchetto = 0;
	p[posPacchetto].giorniPacchetto = 0;
	p[posPacchetto].idHotelPacchetto = 0;
	p[posPacchetto].idTourOperatorPacchetto = 0;
	p[posPacchetto].scontoPacchetto = 0;
	p[posPacchetto].costoTotalePacchetto = 0;


	/*riordino i pacchetti viaggio nell'array solo se non � stato cancellato l'ultimo pacchetto viaggio*/
	if(posPacchetto < MAX_NUM_PACCHETTI-1){
		posPacchetto = riordinaPacchetti(posPacchetto, p);
	}

	if((p[posPacchetto].idPartenzaPacchetto == 0) && (p[posPacchetto].costoTotalePacchetto == 0)){

		return 1;
	}else{

		return 0;
	}
}


/**
 * Questa funzione permette di riordinare l'array dei pacchetti viaggio in seguito alla rimozione
 * di uno di essi.
 * La funzione riceve in input la posizione nell'array del pacchetto viaggio cancellato
 * A partire dalla posizione ricevuta in input la funzione scorre tutto l'array
 * dei pacchetti viaggio e scambia di posizione il pacchetto viaggio eliminato (che contiene dati di
 * default) con quello successivo finche' non ci sono piu' pacchetti viaggio nell'array.
 *
 * @pre I dati del pacchetto viaggio in posizione 'posPacchetto' devono essere stati settati a valori di default
 * @post la funzione restituisce la nuova posizione del pacchetto eliminato nel relativo array
 */
int riordinaPacchetti(int posPacchetto, DATI_PACCHETTO_VIAGGIO p[]){
	DATI_PACCHETTO_VIAGGIO appoggio;
	int nuovaPosizione = posPacchetto;

	for(int i = posPacchetto; i < MAX_NUM_PACCHETTI-1; i++){
		if(p[i+1].idPartenzaPacchetto != 0){

			appoggio = p[i];
			p[i] = p[i+1];
			p[i+1] = appoggio;
			nuovaPosizione = i+1;
		}
	}

	return nuovaPosizione;
}

/**
 * Questa funzione raggruppa tutte le istruzioni necessarie ad effettuare la rimozione di un pacchetto viaggio
 */
void effettuaRimozionePacchetto(int indiceMassimo, DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[]){
	int sceltaIdRimozione;

	/*l'eliminazione di un pacchetto viaggio pu� avvenire solo se nell'array in cui sono memorizzati sono presenti
	 *pi� di un pacchetto viaggio.
	 */
	if(contaPacchetti(p) != 0){

		indiceMassimo = stampaPacchettiViaggio(p, d, c, t, h);
		puts("\nInserire l'indice del pacchetto che si intende eliminare scegliendo tra i seguenti:\n");

		sceltaIdRimozione = inserisciScelta(NUM_MIN_SOTTOMENU, indiceMassimo, 4);

		if(confermaModifica("eliminare") == 1){
			if(eliminaPacchettiViaggio(sceltaIdRimozione-1, p) == 1){
				puts("\nPERFETTO!!! Eliminazione pacchetto viaggio avvenuta con successo.");
			}else{
				puts("\nERRORE!!! Eliminazione pacchetto viaggio non riuscita.");
			}
		}
	}else{
		printf("\nATTENZIONE!!! Non � presente nessun pacchetto\n\n");
	}

	printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");
}
