#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "costanti.h"
#include "struttureDati.h"
#include "stampaDati.h"
#include "controlloInput.h"

/**
 * Permette di inserire una scelta tra le voci dei vari menu' presenti nel programma.
 * Acquisita la stringa, tramite un for controlla, carattere per carattere, se sono stati inseriti
 * solo numeri ,se non e' cosi' la scelta viene messa automaticamente a 0 e stampa un messaggio di errore.
 * Se sono stati inseriti solo numeri (quindi sceltaInt e' diversa da 0), controlla che sia compreso tra
 * i due parametri primo e ultimo.
 * Se non e' compreso stampa un messaggio di errore e aspetta il prossimo input.
 * Quando l'input e' corretto, lo restituisce.
 *
 * @post ritorna la scelta effettuata dall'utente
 *
 */
int inserisciScelta(int primo, int ultimo, int numCaratteri){

	char sceltaChar[numCaratteri];
	char c;
	int sceltaInt;

	do{
		//inizializza sceltaInt ad un valore diverso da 0, perch� 0 indica che il valore inserito non � corretto, per lo scopo � stato scelto 1.
		sceltaInt = 1;
		if( (numCaratteri-1) > 1){
			printf("Il sistema considera solo i primi %d caratteri inseriti.\n", numCaratteri-1);
		}else{
			puts("Il sistema considera solo il primo carattere inserito.");
		}
		printf("Inserisci scelta --> ");
		fgets(sceltaChar,numCaratteri,stdin);

		//pulisce il buffer solo se vengono inseriti pi� caratteri di quanti indicati
		if(strlen(sceltaChar) > 0 && sceltaChar[strlen(sceltaChar)-1] != '\n'){
			while((c = getchar()) != '\n' && c != EOF);
		}


		//dopo l'input la funzione sostituisce l'evenutale carattere '\n' che prende fgets con '\0'
		for(int i=0; i<strlen(sceltaChar); i++){
			if(sceltaChar[i] == '\n'){
				sceltaChar[i] = '\0';
			}
		}

		//viene controllato se non sono stati inseriti numeri
		for(int i = 0; i < strlen(sceltaChar) && sceltaInt != 0; i++){
			if(!isdigit(sceltaChar[i])){
				puts("\nERRORE!!! Inserire solo numeri.\n");
				sceltaInt = 0;
			}
		}
		if(sceltaInt != 0){
			//converte sceltaChar in un long int tramite strtol e con un apposito cast viene convertito in int
			sceltaInt = (int)strtol(sceltaChar,NULL, 10);
			if(sceltaInt < primo || sceltaInt > ultimo){
				printf("\nATTENZIONE!!! Inserire un numero compreso tra %d - %d.\n\n",primo,ultimo);
			}
		}
	}while(sceltaInt < primo || sceltaInt > ultimo);

	return sceltaInt;
}

/**
 * Questa funzione permette di inserire correttamente qualsiasi nome che deve essere utilizzato nel programa.
 * Viene acquisito in input il nome e quindi vengono effettuati i controlli in questo ordine:
 * 1) controlla se sono stati inseriti almeno NUM_MIN_CARATTERI_NOME caratteri;
 * 2) se il primo controllo ha esito positivo, rende maiuscolo il primo carattere se questo e' una lettera analizzando ogni singolo carattere,
 * 	  poi conta quante lettere e quanti numeri sono stati inseriti, se il carattere e' un simbolo, tramite la funzione controlloSimboli viene controllato
 * 	  se il simbolo e' contenuto nell'array 'simboliAccettati', il quale contiene una lista di tutti i simboli accettati, se il simbolo e' tra quelli
 * 	  accettabili il flag che indica la correttezza viene messo a 1, poi se il simbolo e' uno spazio e il carattere succesivo e' una lettera, questa
 * 	  viene resa maiucola e infine viene incrementato l'apposito contatore dei simboli, altrimenti il flag viene settato a 0;
 * 3) se le lettere inserite sono troppo poche (minori di NUM_MIN_LETTERE_HOTEL) allora viene stampato un messaggio di errore e viene settato il flag che
 *    indica la correttezza dell'input a 0;
 * 4) se i numeri inseriti sono troppi (maggiori di maxNumeri) allora viene stampato un messaggio di errore viene settato il flag che indica la
 * 	  correttezza dell'input a 0;
 * 5) se i simboli inseriti sono troppi (maggiori di maxSimboli) allora viene stampato un messaggio di errore viene settato il flag che indica la
 * 	  correttezza dell'input a 0;
 * La funzione fa reinserire l'input finche' il flag e' uguale a 0 (il che indica che l'input inserito non e' corretto).
 *
 *
 * @post restituisce il nome inserito da tastiera.
 *
 */
char* inserireNome(int lunghezzaNome, char simboliAccettati[], int dim, char categoria[], int minLettere, int maxSimboli, int maxNumeri){
	int flag = 0; 			//flag che indica se l'input � corretto (1) o sbagliato (0)
	char* nome = (char*) calloc(lunghezzaNome, sizeof(char)); //alloca e inizializza memoria per il puntatore che deve essere restituito
	char c;
	int contaSimboli;
	int contaLettere;
	int contaNumeri;

	puts("\n\n------------------------------------ NOME ------------------------------------");

	do{
		flag = 0;
		contaSimboli = 0;
		contaLettere = 0;
		contaNumeri = 0;

		printf("\nIl sistema considera solo %d caratteri\n", lunghezzaNome-1);
		printf("Inserire il NOME %s --> ", categoria);
		fgets(nome, lunghezzaNome, stdin);

		//pulisce il buffer solo se vengono inseriti pi� caratteri di quanti indicati
		if(strlen(nome) > 0 && nome[strlen(nome)-1] != '\n'){
			while((c = getchar()) != '\n' && c != EOF);
		}

		//dopo l'input la funzione sostituisce l'eventuale carattere '\n' che prende fgets con '\0'
		for(int i = 0; i < strlen(nome); i++){
			if(nome[i] == '\n'){
				nome[i] = '\0';
			}
		}

		if(strlen(nome) >= NUM_MIN_CARATTERI_NOME ){
			flag = 1;

			for(int i = 0; (i < strlen(nome) && flag==1); i++){
				if(isalpha(nome[i])){
					//se il primo carattere � una lettera la rende maiuscola
					if(i == 0){
						nome[i] = toupper(nome[i]);
					}
					contaLettere +=  1;

				}else if(isdigit(nome[i])){
					contaNumeri += 1;

				}else if(!isalnum(nome[i])){
					/*controlla se il carattere � uno dei simboli accettabili dalla funzione e il valore di ritorno di controlloInput (0 o 1)
					  viene assegnato al flag.*/
					flag = controlloSimboli(simboliAccettati, dim, nome[i] );
					//se flag = 1, cio� il carattere � un simbolo accettato dalla funzione, viene incrementato il contatore dei simboli
					if(flag){
						/*se il simbolo accettato � uno spazio e il carattere successivo � una lettera allora
						 * trasforma quest'ultima in maiuscolo */
						if(nome[i] == ' '){
							if( isalpha(nome[i+1])){
								nome[i+1] = toupper(nome[i+1]);
							}
						}else{
							contaSimboli += 1;
						}

					}
				}
			}


			if(flag == 0){

				printf("\nERRORE!!! Gli unici caratteri accettati sono: ");


				for(int j = 0; j < dim; j++){
					if(simboliAccettati[j] != ' '){
						//l'ultimo elemento non lo conto perch� � lo spazio
						if(j != dim-2){
							printf("%c ", simboliAccettati[j]);
						}else{
							printf("e %c", simboliAccettati[j]);
						}
					}
				}

				puts("");

			}else if (contaNumeri > maxNumeri){
				flag = 0;
				printf("\nATTENZIONE!!! Bisogna inserire massimo %d numeri.\n", maxNumeri);

			}else if(contaLettere < minLettere){
				flag = 0;
				printf("\nATTENZIONE!!! Bisogna inserire almeno %d lettere.\n", minLettere);

			}

			if(contaSimboli > maxSimboli){
				printf("\nATTENZIONE!!! Inserire massimo %d simboli.\n",maxSimboli);
				flag = 0;
			}
		}else{
			printf("\nATTENZIONE!!! Il nome deve avere almeno %d caratteri.\n", NUM_MIN_CARATTERI_NOME);
		}
	}while(flag == 0);


	return nome;
}

/**
* Questa funzione permette di controllare se un certo carattere (passato come parametro) e' presente tra i simboli presenti in un certo array.
* Tramite un ciclo for che itera un numero di volte pari alla dimensione dell'array 'simboli' passato nel parametro 'dimensione' e ad ogni
* iterazione controlla se 'carattere' e' uguale ad un elemento di 'simboli'.
*
* @post la funzione ritorna 1 se 'carattere' e' presente in 'simboli', 0 se 'carattere' non e' presente in 'simboli'
*/
int controlloSimboli(char simboli[], int dimensione, char carattere){
	int flag = 0;
	for(int j = 0; j < dimensione; j++){
		if(carattere == simboli[j]){
			flag = 1;
		}

	}
	return flag;
}

/**
 * Questa funzione permette di inserire correttamente il nome di un paese (citta' o nazione) da tastiera.
 * Viene acquisito in input il nome e quindi vengono effettuati i controlli in questo ordine:
 * 1) controlla se sono stati inseriti almeno NUM_MIN_CARATTERI_NOME caratteri;
 * 2) se il primo controllo ha esito positivo, rende maiuscolo il primo carattere se questo e' una lettera analizzando ogni singolo carattere,
 * 	  poi conta quante lettere e quanti numeri sono stati inseriti, se il carattere e' un simbolo, tramite la funzione controlloSimboli viene controllato
 * 	  se il simbolo e' uno spazio, che e' l'unico simbolo accettato dalla funzione, se e' cosi' il flag che indica la correttezza viene messo a 1, e quindi
 * 	  se il carattere succesivo e' una lettera, questa viene resa maiucola, altrimenti il flag viene settato a 0;
 * 3) se le lettere inserite sono troppo poche (minori di NUM_MIN_LETTERE_HOTEL) allora viene stampato un messaggio di errore e viene settato il flag che
 *    indica la correttezza dell'input a 0;
 * 4) se sono stati inseriti numeri allora viene stampato un messaggio di errore viene settato il flag che indica la
 * 	  correttezza dell'input a 0;
 * 5) se vengono inseriti simboli diversi dallo spazio viene stampato un messaggio di errore viene settato il flag che indica la
 * 	  correttezza dell'input a 0;
 * La funzione fa reinserire l'input finche' il flag e' uguale a 0 (il che indica che l'input inserito non e' corretto).
 *
 *
 * @post restituisce il nome del paese inserito da tastiera.
 *
 */
char* inserirePaese(int lunghezzaNome, char categoria[], char tipoPaese[], int minLettere){
	int flag = 0; 			//flag che indica se l'input � corretto (1) o sbagliato (0)
	char* paese = (char*) calloc(lunghezzaNome, sizeof(char)); //alloca e inizializza memoria per il puntatore che deve essere restituito
	char simboloAccettato[] = {' '};
	char c;
	int contaLettere;
	int contaNumeri;

	puts("\n\n------------------------------------ CITTA'/NAZIONE ------------------------------------");


	do{
		flag = 0;
		contaLettere = 0;
		contaNumeri = 0;

		printf("\nIl sistema considera solo %d caratteri\n", lunghezzaNome-1);
		printf("Inserire %s %s -->",tipoPaese, categoria);
		fgets(paese, lunghezzaNome, stdin);

		//pulisce il buffer solo se vengono inseriti pi� caratteri di quanti indicati
		if(strlen(paese) > 0 && paese[strlen(paese)-1] != '\n'){
			while((c = getchar()) != '\n' && c != EOF);
		}

		//dopo l'input la funzione sostituisce il carattere '\n' che prende fgets con '\0'
		for(int i = 0; i < strlen(paese); i++){
			if(paese[i] == '\n'){
				paese[i] = '\0';
			}
		}

		if(strlen(paese) >= NUM_MIN_CARATTERI_NOME ){
			flag = 1;

			for(int i = 0; (i < strlen(paese) && flag==1); i++){
				//se il primo carattere � una lettera la rende maiuscola
				if(isalpha(paese[i])){
					if(i == 0){
						paese[i] = toupper(paese[i]);
					}
					contaLettere +=  1;

				}else if(isdigit(paese[i])){
					contaNumeri += 1;

				}else if(!isalnum(paese[i])){
					/*controlla se il carattere � uno spazio (unico simbolo accettato dalla funzione)
					 *e il valore di ritorno di controlloInput (0 o 1) viene assegnato al flag.*/
					flag = controlloSimboli(simboloAccettato,sizeof(simboloAccettato), paese[i] );

					//se flag = 1, cio� il carattere � uno spazio, viene incrementato il contatore dei simboli
					if(flag){
						if(paese[i] == ' ' && isalpha(paese[i+1])){
							paese[i+1] = toupper(paese[i+1]);
						}
					}
				}
			}


			if(flag == 0){
				printf("\nERRORE!!! Non sono ammessi simboli.\n");

			}else if (contaNumeri > 0){
				flag = 0;
				printf("\nATTENZIONE!!! Non sono ammessi numeri.\n");

			}else if(contaLettere < minLettere){
				flag = 0;
				printf("\nATTENZIONE!!! Bisogna inserire almeno %d lettere.\n", minLettere);
			}

		}else{
			printf("\nATTENZIONE!!! Il nome del paese deve avere almeno %d caratteri.\n", NUM_MIN_CARATTERI_NOME);
		}
	}while(flag == 0);


	return paese;
}

/**
 * Questa funzione permette di inserire il prezzo orario di una compagnia aerea.
 * Il prezzo viene inserito come una stringa, quindi per prima cosa viene controllato che non siano
 * stati inseriti simboli o lettere (apparte il punto separatore di interi e decimali), se questi sono
 * stati inseriti, il prezzo viene messo a 0.0 per indicare che l'input non e' corretto e viene stampato
 * un messaggio di errore.
 * Nel frattempo la funzione conta quanti simboli di punto sono stati inseriti, se sono un numero diverso
 * da 1 viene stampato un messaggio di errore.
 * Se i controlli hanno esito positivo la stringa viene convertita in float, poi tramite la funzione
 * verificaDecimaliDaStrina viene verificato se sono stati inseriti solo 2 decimali o meno, se non e' cosi' il prezzo
 * viene messo a 0.0 e viene stampato un messaggio di errore.
 * Se i decimali inseriti sono 2 allora si controlla il range di valori che il prezzo deve rispettare (minPrezzo e
 * maxPrezzo) se il range non viene rispettato il prezzo viene messo a 0.0 e viene stampato un messaggio di errore.
 * L'input viene fatto reinserire finche' il prezzo e' diverso da 0.0 e il numero di punti inseriti e' divero da 1.
 *
 * @post La funzione restituisce il prezzo inserito.
 */

float inserirePrezzoCompagnia(float minPrezzo, float maxPrezzo){
	char prezzoChar[MAX_CARATTERI_PREZZO_COMPAGNIA];
	float prezzoFloat;
	int contaPunti; //serve a contare quanti simboli '.' vengono inseriti, se pi� di 1 l'input non � corretto
	char c;

	puts("\n\n------------------------------------ PREZZO COMPAGNIA ------------------------------------");

	do{
    	//inizializza prezzoFloat ad un valore diverso da 0, perch� 0 indica che il valore inserito non � corretto, per lo scopo � stato scelto 1.
		prezzoFloat = 1;
		contaPunti = 0;
		printf("\nIl sistema considera solo i primi %d caratteri.\n", MAX_CARATTERI_PREZZO_COMPAGNIA-1);
		puts("Inserire un valore decimale utilizzando il '.' per separare interi da decimali.");
		printf("Inserire il PREZZO ORARIO della compagnia aerea --> ");
		fgets(prezzoChar,MAX_CARATTERI_PREZZO_COMPAGNIA,stdin);

		//pulisce il buffer solo se vengono inseriti pi� caratteri di quanti indicati
		if(strlen(prezzoChar) > 0 && prezzoChar[strlen(prezzoChar)-1] != '\n'){
			while((c = getchar()) != '\n' && c != EOF);
		}


		//dopo l'input la funzione sostituisce il carattere '\n' che prende fgets con '\0'
		for(int i = 0; i < strlen(prezzoChar); i++){
			if(prezzoChar[i] == '\n'){
				prezzoChar[i] = '\0';
			}
		}

		/*Se sono stati inseriti simboli o lettere, se il simbolo � un punto il contatore
		 * dei punti viene incrementato altrimenti il prezzo viene messo a 0.0 per indicare
		 * che l'input non � corretto.*/
		for(int i = 0; i < strlen(prezzoChar); i++){
			if(!isdigit(prezzoChar[i])){
				if(prezzoChar[i] == '.'){
					contaPunti += 1;
				}else{
					prezzoFloat = 0.0;
				}
			}
		}

		if(prezzoFloat != 0.0){
			if(contaPunti == 1){
				prezzoFloat = strtof(prezzoChar, NULL);
				if(verificaDecimaliDaStringa(prezzoChar,strlen(prezzoChar), 2) != 1){
					puts("\nERRORE!!! Inserire due cifre decimali.\n");
					prezzoFloat = 0.0;
				}else if(prezzoFloat < minPrezzo || prezzoFloat > maxPrezzo){
					printf("\nERRORE!!! Il prezzo deve essere compreso tra %.2f e %.2f",minPrezzo, maxPrezzo);
					prezzoFloat = 0.0;
				}
			}else if(contaPunti < 1){
				puts("\nERRORE!!! Inserire il punto per separare gli interi dai decimali.");
			}else if(contaPunti > 1){
				puts("\nERRORE!!! E' ammesso un solo punto separatore di interi e decimali.");
			}
		}else{
			puts("\nERRORE!!! Non sono ammesse lettere o simboli tranne il punto separatore di interi e decimali.");
		}
	}while(prezzoFloat == 0.0 || (contaPunti < 1 || contaPunti > 1));

	return prezzoFloat;
}

/**
* Questa controlla se il numero di valori decimali inseriti in una stringa (un numero sottoforma di stringa) sia uguale ad
* un numero che ci si aspetta (il parametro 'decimali').
* Un primo for serve a trovare la posizione del punto nella stringa del numero.
* Questa posizone verra' usata come punto di inizio del secondo for, in cui si controlla se i caratteri
* da quel punto in poi sono numeri, se si viene incrementato il contatore di cifre decimali.
* Se il valore del contatore di cifre decimali e' diverso dal valore del parametro 'decimali' viene
* restituito 0 altrimenti 1
*
* @post la funzione ritorna 1 il valore di 'decimali' coincide con il numero di cifre decimali del parametro 'numero', alrimenti ritorna 0.
*/

int verificaDecimaliDaStringa(char numero[], int dimensione, int decimali){
	int contaDecimali = 0;
	int posizionePunto = 0;

	//scorro tutta la stringa ricevuta come input e memorizzo la posizione in cui compare il punto
	for(int i = 0; i < dimensione; i++){
		if(numero[i] == '.'){
			posizionePunto = i;
			break;
		}
	}
	//a partire dalla posizione in cui compare il punto conto quanti numeri sono presenti nella stringa
	for(int i = posizionePunto; i < dimensione; i++){
		if(isdigit(numero[i])){
			contaDecimali += 1;
		}
	}

	//se i numeri contati sono diversi dai decimali che ci si aspetta (passati come parametri) ritorna 0 altrimenti ritorna 1
	if(contaDecimali != decimali){
		return 0;
	}else{
		return 1;
	}
}
