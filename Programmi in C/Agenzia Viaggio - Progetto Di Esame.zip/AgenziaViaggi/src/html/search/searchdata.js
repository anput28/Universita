var indexSectionsWithContent =
{
  0: "acdegilmnorsv",
  1: "d",
  2: "acelmrs",
  3: "acegilmorsv",
  4: "clmn",
  5: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Strutture dati",
  2: "File",
  3: "Funzioni",
  4: "Definizioni",
  5: "Pagine"
};

