var searchData=
[
  ['ordinapacchetticercati',['ordinaPacchettiCercati',['../ricerca_dati_8h.html#abcfcc9240ffc102fd5ec80d7215c3ac5',1,'ricercaDati.c']]]
];
