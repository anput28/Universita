var searchData=
[
  ['eliminadaticompagnie_2eh',['eliminaDatiCompagnie.h',['../elimina_dati_compagnie_8h.html',1,'']]],
  ['eliminadatihotel_2eh',['eliminaDatiHotel.h',['../elimina_dati_hotel_8h.html',1,'']]],
  ['eliminadatioperator_2eh',['eliminaDatiOperator.h',['../elimina_dati_operator_8h.html',1,'']]],
  ['eliminadatipacchetti_2eh',['eliminaDatiPacchetti.h',['../elimina_dati_pacchetti_8h.html',1,'']]]
];
