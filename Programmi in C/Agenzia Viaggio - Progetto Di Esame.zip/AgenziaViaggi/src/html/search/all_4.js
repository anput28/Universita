var searchData=
[
  ['gestiscicreazionefiletestuali',['gestisciCreazioneFileTestuali',['../creazione_file_testuali_8h.html#affe387e7d64d51f54f8a61c3548aa509',1,'creazioneFileTestuali.c']]]
];
