var searchData=
[
  ['aggiungidati_2eh',['aggiungiDati.h',['../aggiungi_dati_8h.html',1,'']]]
];
