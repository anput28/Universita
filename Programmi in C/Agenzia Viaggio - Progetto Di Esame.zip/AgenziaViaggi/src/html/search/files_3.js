var searchData=
[
  ['letturafile_2eh',['letturaFile.h',['../lettura_file_8h.html',1,'']]]
];
