var searchData=
[
  ['ricercadati_2eh',['ricercaDati.h',['../ricerca_dati_8h.html',1,'']]]
];
