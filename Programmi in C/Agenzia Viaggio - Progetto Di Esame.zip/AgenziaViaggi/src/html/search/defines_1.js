var searchData=
[
  ['lungh_5fnome_5fcitta',['LUNGH_NOME_CITTA',['../costanti_8h.html#a0c2b7b995a8f50576f674226f11eaf7a',1,'costanti.h']]],
  ['lungh_5fnome_5fcompagnia',['LUNGH_NOME_COMPAGNIA',['../costanti_8h.html#a8b4e974e7da960349eb8ef6da2b9f8c5',1,'costanti.h']]],
  ['lungh_5fnome_5fhotel',['LUNGH_NOME_HOTEL',['../costanti_8h.html#a2c3e54eaf001d1e9f1add07630fd7fc4',1,'costanti.h']]],
  ['lungh_5fnome_5fnazione',['LUNGH_NOME_NAZIONE',['../costanti_8h.html#ae94709846eb92bf2d28dad25d30938bb',1,'costanti.h']]],
  ['lungh_5fnome_5ftour_5foperator',['LUNGH_NOME_TOUR_OPERATOR',['../costanti_8h.html#a27538a82b6c02bb0bb476e063ecd574b',1,'costanti.h']]]
];
