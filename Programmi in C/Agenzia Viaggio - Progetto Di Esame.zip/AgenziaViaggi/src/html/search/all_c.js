var searchData=
[
  ['verificadecimalidastringa',['verificaDecimaliDaStringa',['../controllo_input_8h.html#ac4b7113bf445c60f54c12f15c6cfc411',1,'controlloInput.c']]]
];
