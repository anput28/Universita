var searchData=
[
  ['dati_5fcompagnia_5faerea',['DATI_COMPAGNIA_AEREA',['../struct_d_a_t_i___c_o_m_p_a_g_n_i_a___a_e_r_e_a.html',1,'']]],
  ['dati_5fdestinazione',['DATI_DESTINAZIONE',['../struct_d_a_t_i___d_e_s_t_i_n_a_z_i_o_n_e.html',1,'']]],
  ['dati_5fhotel',['DATI_HOTEL',['../struct_d_a_t_i___h_o_t_e_l.html',1,'']]],
  ['dati_5forario_5fvolo',['DATI_ORARIO_VOLO',['../struct_d_a_t_i___o_r_a_r_i_o___v_o_l_o.html',1,'']]],
  ['dati_5fpacchetto_5fviaggio',['DATI_PACCHETTO_VIAGGIO',['../struct_d_a_t_i___p_a_c_c_h_e_t_t_o___v_i_a_g_g_i_o.html',1,'']]],
  ['dati_5ftour_5foperator',['DATI_TOUR_OPERATOR',['../struct_d_a_t_i___t_o_u_r___o_p_e_r_a_t_o_r.html',1,'']]]
];
