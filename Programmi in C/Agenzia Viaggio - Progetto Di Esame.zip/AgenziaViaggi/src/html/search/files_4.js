var searchData=
[
  ['modificadati_2eh',['modificaDati.h',['../modifica_dati_8h.html',1,'']]],
  ['modificadatipacchetto_2eh',['modificaDatiPacchetto.h',['../modifica_dati_pacchetto_8h.html',1,'']]]
];
