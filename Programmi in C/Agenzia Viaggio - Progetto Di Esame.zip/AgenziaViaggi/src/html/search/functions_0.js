var searchData=
[
  ['aggiornacostodacompagnia',['aggiornaCostoDaCompagnia',['../modifica_dati_pacchetto_8h.html#aed052f92a097f7b50e63a4186cdbc805',1,'modificaDatiPacchetto.c']]],
  ['aggiornacostodahotel',['aggiornaCostoDaHotel',['../modifica_dati_pacchetto_8h.html#a0ed200a2e0908f696807e5b31ffaa659',1,'modificaDatiPacchetto.c']]],
  ['aggiornapacchettidacompagnia',['aggiornaPacchettiDaCompagnia',['../elimina_dati_compagnie_8h.html#a084124a7ea2daeeb116e28b83ff583b1',1,'eliminaDatiCompagnie.c']]],
  ['aggiornapacchettidahotel',['aggiornaPacchettiDaHotel',['../elimina_dati_hotel_8h.html#a0a290a378208b3a5ed1596a1bfa86e53',1,'eliminaDatiHotel.c']]],
  ['aggiornapacchettidaoperator',['aggiornaPacchettiDaOperator',['../elimina_dati_operator_8h.html#af823f5f7e9c4769f0fdf74638d306025',1,'eliminaDatiOperator.c']]],
  ['aggiungicompagnia',['aggiungiCompagnia',['../aggiungi_dati_8h.html#aaf03c2a11c309db3463e6492a19b9189',1,'aggiungiDati.c']]],
  ['aggiungihotel',['aggiungiHotel',['../aggiungi_dati_8h.html#a45d708991b6f6261f5d4e69386f154cf',1,'aggiungiDati.c']]],
  ['aggiungipacchettoviaggio',['aggiungiPacchettoViaggio',['../aggiungi_dati_8h.html#aefbf98fc588881c1ecd83cdecafa74d1',1,'aggiungiDati.c']]],
  ['aggiungitouroperator',['aggiungiTourOperator',['../aggiungi_dati_8h.html#a6a5998698ce9737eec101c969302c5a6',1,'aggiungiDati.c']]]
];
