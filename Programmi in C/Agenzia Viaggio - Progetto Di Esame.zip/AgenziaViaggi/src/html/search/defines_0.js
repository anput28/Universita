var searchData=
[
  ['costo_5ftour_5foperator',['COSTO_TOUR_OPERATOR',['../costanti_8h.html#a9f845ece830b7c569b93f0228d7c57fe',1,'costanti.h']]]
];
