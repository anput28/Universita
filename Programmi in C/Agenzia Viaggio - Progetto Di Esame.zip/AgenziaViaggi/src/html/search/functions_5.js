var searchData=
[
  ['letturacompagnieaeree',['letturaCompagnieAeree',['../lettura_file_8h.html#a1a5aa0f8a87bfd98f54b52ad4e68c28a',1,'letturaFile.c']]],
  ['letturadestinazioni',['letturaDestinazioni',['../lettura_file_8h.html#a8eccf2daa259ca97c1715c132ca6ebda',1,'letturaFile.c']]],
  ['letturahotel',['letturaHotel',['../lettura_file_8h.html#af5de48ba49b8c1fd684d3f39f92f9107',1,'letturaFile.c']]],
  ['letturaorarivoli',['letturaOrariVoli',['../lettura_file_8h.html#a23ef4fa8907b30555a8e9ddf491ffd32',1,'letturaFile.c']]],
  ['letturapacchettiviaggio',['letturaPacchettiViaggio',['../lettura_file_8h.html#a6b49c16a21b96b0c032c1d989f569ec1',1,'letturaFile.c']]],
  ['letturatouroperator',['letturaTourOperator',['../lettura_file_8h.html#a1f2018ca391f48903c87e6627eaae757',1,'letturaFile.c']]]
];
