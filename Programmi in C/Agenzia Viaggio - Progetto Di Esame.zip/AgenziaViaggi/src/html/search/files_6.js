var searchData=
[
  ['scritturafile_2eh',['scritturaFile.h',['../scrittura_file_8h.html',1,'']]],
  ['stampadati_2eh',['stampaDati.h',['../stampa_dati_8h.html',1,'']]],
  ['stampamenu_2eh',['stampaMenu.h',['../stampa_menu_8h.html',1,'']]],
  ['strutturedati_2eh',['struttureDati.h',['../strutture_dati_8h.html',1,'']]]
];
