var searchData=
[
  ['ricercapacchetti',['ricercaPacchetti',['../ricerca_dati_8h.html#ab2a47fe6b459bd2e0b8da9d4737b1ed7',1,'ricercaDati.c']]],
  ['riordinacompagnieaeree',['riordinaCompagnieAeree',['../elimina_dati_compagnie_8h.html#a1f47e1d7bba483fe411c251e92cb4f7f',1,'eliminaDatiCompagnie.c']]],
  ['riordinahotel',['riordinaHotel',['../elimina_dati_hotel_8h.html#ac06e10ae90431e11ac58df2bad861889',1,'eliminaDatiHotel.c']]],
  ['riordinapacchetti',['riordinaPacchetti',['../elimina_dati_pacchetti_8h.html#ad7cd3dae0380839f32c1127e7f2b0db3',1,'eliminaDatiPacchetti.c']]],
  ['riordinatouroperator',['riordinaTourOperator',['../elimina_dati_operator_8h.html#ac0f8590b53abe0da095077c70b0f5503',1,'eliminaDatiOperator.c']]]
];
