/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var menudata={children:[
{text:"Pagina Principale",url:"index.html"},
{text:"Pagine collegate",url:"pages.html"},
{text:"Strutture dati",url:"annotated.html",children:[
{text:"Strutture dati",url:"annotated.html"},
{text:"Indice delle strutture dati",url:"classes.html"}]},
{text:"File",url:"files.html",children:[
{text:"Elenco dei file",url:"files.html"},
{text:"Elementi globali",url:"globals.html",children:[
{text:"Tutto",url:"globals.html",children:[
{text:"a",url:"globals.html#index_a"},
{text:"c",url:"globals.html#index_c"},
{text:"e",url:"globals.html#index_e"},
{text:"g",url:"globals.html#index_g"},
{text:"i",url:"globals.html#index_i"},
{text:"l",url:"globals.html#index_l"},
{text:"m",url:"globals.html#index_m"},
{text:"n",url:"globals.html#index_n"},
{text:"o",url:"globals.html#index_o"},
{text:"r",url:"globals.html#index_r"},
{text:"s",url:"globals.html#index_s"},
{text:"v",url:"globals.html#index_v"}]},
{text:"Funzioni",url:"globals_func.html",children:[
{text:"a",url:"globals_func.html#index_a"},
{text:"c",url:"globals_func.html#index_c"},
{text:"e",url:"globals_func.html#index_e"},
{text:"g",url:"globals_func.html#index_g"},
{text:"i",url:"globals_func.html#index_i"},
{text:"l",url:"globals_func.html#index_l"},
{text:"m",url:"globals_func.html#index_m"},
{text:"o",url:"globals_func.html#index_o"},
{text:"r",url:"globals_func.html#index_r"},
{text:"s",url:"globals_func.html#index_s"},
{text:"v",url:"globals_func.html#index_v"}]},
{text:"Definizioni",url:"globals_defs.html",children:[
{text:"c",url:"globals_defs.html#index_c"},
{text:"l",url:"globals_defs.html#index_l"},
{text:"m",url:"globals_defs.html#index_m"},
{text:"n",url:"globals_defs.html#index_n"}]}]}]}]}
