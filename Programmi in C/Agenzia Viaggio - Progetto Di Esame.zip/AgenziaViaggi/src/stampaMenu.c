#include <stdio.h>
#include "stampaMenu.h"
#include "costanti.h"

/**
* Questa funzione permette di stampare le voci del menu' principale
*
* @post la funzione stampa i dati su schermo
*/
void menuPrincipale(){
	printf("\n\n--------------- MENU' PRINCIPALE ---------------\n\n");
	printf("1) Pacchetti Viaggio\n");
	printf("2) Hotel\n");
	printf("3) Tour operator\n");
	printf("4) Compagnie aeree\n");
	printf("5) Ricerca per filtri\n");
	printf("6) Esci\n\n");
}

/**
* Questa funzione permette di stampare le voci del menu' relativo ai pacchetti viaggio.
*
* @post la funzione stampa i dati su schermo
*/
void menuPacchettiViaggio(){
	printf("\n\n----------------SOTTOMENU' PACCHETTI VIAGGIO----------------\n\n");
	printf("1) Aggiungi Pacchetto Viaggio\n");
	printf("2) Modifica Pacchetto Viaggio\n");
	printf("3) Rimuovi Pacchetto Viaggio\n");
	printf("4) Indietro\n\n");
}

/**
* Questa funzione permette di stampare le voci del menu' relativo agli hotel.
*
* @post la funzione stampa i dati su schermo
*/
void menuHotel(){
	printf("\n\n----------------SOTTOMENU' HOTEL----------------\n\n");
	printf("1) Aggiungi Hotel\n");
	printf("2) Modifica Hotel\n");
	printf("3) Rimuovi Hotel\n");
	printf("4) Indietro\n\n");

}

/**
* Questa funzione permette di stampare le voci del menu' relativo ai tour operator.
*
* @post la funzione stampa i dati su schermo
*/
void menuTourOperator(){
	printf("\n\n----------------SOTTOMENU' TOUR OPERATOR----------------\n\n");
	printf("1) Aggiungi Tour Operator\n");
	printf("2) Modifica Tour Operator\n");
	printf("3) Rimuovi Tour Operator\n");
	printf("4) Indietro\n\n");

}

/**
* Questa funzione permette di stampare le voci del menu' relativo alle compagnie aeree.
*
* @post la funzione stampa i dati su schermo
*/
void menuCompagnieAeree(){

	printf("\n\n----------------SOTTOMENU' COMPAGNIE AEREE----------------\n\n");
	printf("1) Aggiungi Compagnia Aerea\n");
	printf("2) Modifica Compagnia Aerea\n");
	printf("3) Rimuovi Compagnia Aerea\n");
	printf("4) Indietro\n\n");

}

/**
 * Stampa le voci del menu' per creare i file testuali.
 *
 * @post la funzione stampa le voci del menu' su schermo
 */
void menuFileTestuali(){

	printf("\n\nScegli quale file testuale creare:\n");
	printf("1) Destinazioni\n");
	printf("2) Hotel\n");
	printf("3) Compagnie aeree\n");
	printf("4) Tour operator\n");
	printf("5) Pacchetti viaggio\n");
	printf("6) CHIUDI PROGRAMMA\n\n");

}

/**
 * Stampa le voci del menu' per la modifica degli hotel.
 *
 * @post la funzione stampa le voci del menu' su schermo
 */
void menuModificaHotel(){
	printf("\n\n----------------MENU' MODIFICA HOTEL ----------------\n\n");
	printf("1) Nome\n");
	printf("2) Stelle\n");
	printf("3) Prezzo\n");
	printf("4) Stanze Totali\n");
	printf("5) Stanze libere\n");
	printf("6) Sconto minori\n");
	printf("7) Citta'\n");
	printf("8) Modifica tutti i dati\n\n");
}

/**
 * Stampa le voci del menu' per la modifica dei tour operator.
 *
 * @post la funzione stampa le voci del menu' su schermo
 */
void menuModificaTourOperator(){
	printf("\n\n----------------MENU' MODIFICA TOUR OPERATOR ----------------\n\n");
	printf("1) Nome\n");
	printf("2) Citta\n");
	printf("3) Nazione\n");
	printf("4) Modifica tutti i dati\n\n");
}

/**
 * Stampa le voci del menu' per la modifica delle compagnie aeree.
 *
 * @post la funzione stampa le voci del menu' su schermo
 */
void menuModificaCompagnieAeree(){
	printf("\n\n----------------MENU' MODIFICA COMPAGNIE AEREE ----------------\n\n");
	printf("1) Nome\n");
	printf("2) Nazione\n");
	printf("3) Prezzo Orario\n");
	printf("4) Modifica tutti i dati\n\n");
}

/**
 * Stampa le voci del menu' per la modifica dei pacchetti viaggio.
 *
 * @post la funzione stampa le voci del menu' su schermo
 */
void menuModificaPacchettiViaggio(){
	printf("\n\n----------------MENU' MODIFICA PACCHETTI VIAGGIO ----------------\n\n");
	printf("1) Partenza\n");
	printf("2) Arrivo\n");
	printf("3) Compagnia Aerea\n");
	printf("4) Categoria Volo\n");
	printf("5) Hotel\n");
	printf("6) Giorni\n");
	printf("7) Tour Operator\n");
	printf("8) Sconto Pacchetto\n");
	printf("9) Modifica tutti i dati\n\n");
}

/**
 *  Stampa le voci del menu per la ricerca dei pacchetti viaggio.
 *
 * @post la funzione stampa le voci del menu' su schermo
 */
void menuRicerca(){
	printf("\n\n----------------MENU' FILTRI RICERCA ----------------\n\n");
	printf("1) Partenza\n");
	printf("2) Arrivo\n");
	printf("3) Compagnia Aerea\n");
	printf("4) Categoria Volo\n");
	printf("5) Hotel\n");
	printf("6) Giorni\n");
	printf("7) Tour Operator\n");
	printf("8) Costo Totale\n");
	printf("9) RICERCA\n");
	printf("10) Indietro\n\n");
}

/**
 * Stampa le varie fasce di prezzo per la ricerca dei pacchetti.
 *
 * @post la funzione stampa le voci del menu' su schermo
 */
void menuIntervalloPrezzi(){
	printf("\n\tFASCE PREZZI\n");
	printf("1) < 500\n");
	printf("2) 500 - 1000\n");
	printf("3) 1000 - 1500\n");
	printf("4) > 1500\n\n");
}

/**
 * Stampa le due possibilita' di accesso alle funzionalita' del programma
 *
 *  @post la funzione stampa le voci del menu' su schermo
 */
void menuAccesso(){
	puts("Scegli opzione di accesso: ");
	puts("1) Utente");
	puts("2) Amministratore\n\n");

}

/**
 * Stampa il menu' per scegliere se uscire o produrre i file testuali
 *
 * @post la funzione stampa le voci del menu' su schermo
 */
void menuFinale(){
	printf("\n\n\n\t+-+-+-+-+-+-+-+-+ AGENZIA VIAGGI +-+-+-+-+-+-+-+-+\n\n");
	printf("1) Crea file testuale\n");
	printf("2) CHIUDI PROGRAMMA\n\n");
}
