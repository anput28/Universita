/**
* @file scritturaFile.h
*
* Questo header file contiene i prototipi delle funzioni che gestiscono la scrittura dei dati sui file .dat per aggiornarli.
*
* @version 0.1
* @authors Angelo Putignano, Roberto Modarelli
*/


/**
 * Questa funzione aggiorna il file binario degli hotel, scrivendo sul file i dati degli hotel presenti in memoria.
 *
 * @param[in] h[] Array da dove prendere i nuovi dati da scrivere su file
 *
 * @return 0 in caso di errore nell'apertura del file
 * @return 1 se tutti i dati sono letti con successo
 */
int scritturaHotel(DATI_HOTEL h[]);

/**
 * Questa funzione aggiorna il file binario delle compagnie aeree, scrivendo sul file i dati delle
 * compagnie aeree presenti in memoria.
 *
 * @param[in] c[] Array da dove prendere i nuovi dati da scrivere su file
 *
 * @return 0 in caso di errore nell'apertura del file
 * @return 1 se tutti i dati sono letti con successo
 */
int scritturaCompagniaAerea(DATI_COMPAGNIA_AEREA c[]);


/**
 * Questa funzione aggiorna il file binario delle compagnie aeree, scrivendo sul file i dati dei
 * tour operator presenti in memoria.
 *
 * @param[in] t[] Array da dove prendere i nuovi dati da scrivere su file
 *
 * @return 0 in caso di errore nell'apertura del file
 * @return 1 se tutti i dati sono letti con successo
 */
int scritturaTourOperator(DATI_TOUR_OPERATOR t[]);

/**
 * Questa funzione aggiorna il file binario delle compagnie aeree, scrivendo sul file i dati dei
 * pacchetti viaggio presenti in memoria.
 *
 * @param[in] p[] Array da dove prendere i nuovi dati da scrivere su file
 *
 * @return 0 in caso di errore nell'apertura del file
 * @return 1 se tutti i dati sono letti con successo
 */
int scritturaPacchettiViaggio(DATI_PACCHETTO_VIAGGIO p[]);
