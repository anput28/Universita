/**
* @file controlloInputPacchetto.h
*
* Questo header file contiene i prototipi delle funzioni che permettono di inserire  e controllare
* l'input relativo ai dati di nuovi pacchetti viaggio.
*
* @version 0.1
* @authors Angelo Putignano, Roberto Modarelli
*/


/**
 * Questa funzione permette di inserire l'id della citta' di partenza e di arrivo del pacchetto.
 *
 * @param[in] d Array che contiene tutte le possibili destinazioni dei viaggi
 * @param[in] posizione E' una stringa (Partenza oppure Arrivo) che serve ad usare la funzione in diversi contesti
 *
 * @return L'id della citta' scelta
 */
int inserisciIdCitta(DATI_DESTINAZIONE d[], char posizione[]);

/**
 *	Questa funzione permette di inserire l'id della compagnia aerea prevista nel pacchetto
 *
 *	@param[in] c Array che contiene tutti i dati delle compagnie aeree
 *
 *	@return L'id della compagnia aerea scelta
 */
int inserisciIdCompagniaAerea(DATI_COMPAGNIA_AEREA c[]);

/**
 * Questa funzione permette di inserire la categoria di volo
 *
 * @return La categoria di volo scelta
 */
int inserisciCategoriaVolo();

/**
 * Questa funzione permette di inserire i giorni di durata del pacchetto.
 *
 * @return I giorni del pacchetto viaggio
 */
int inserisciGiorniPacchetto();

/**
 * Questa funzione permette di inserire l'id dell'hotel nella citta' di arrivo del pacchetto.
 *
 * @param[in] h Array che contiene tutti i dati degli hotel
 * @param[in] arrivoInt E' l'id della citta' di arrivo del pacchetto
 *
 * @return L'id dell'hotel
 */
int inserisciIdHotel(DATI_HOTEL h[], int arrivoInt);

/**
 *	Questa funzione permette di inserire l'id del tour operator che ha organizzato il pacchetto.
 *
 *	@param[in] t Array che contiene tutti i dati dei tour operator
 *
 *	@return L'id del tout operator
 */
int inserisciIdTourOperator(DATI_TOUR_OPERATOR t[]);

/**
 * Questa funzione permette di inserire lo sconto percentuale da applicare al pacchetto viaggio.
 *
 * @return Lo sconto da applicare al pacchetto
 */
int inserisciPercentualeSconto();
