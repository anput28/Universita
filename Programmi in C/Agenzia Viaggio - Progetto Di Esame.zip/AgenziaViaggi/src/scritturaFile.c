#include <stdio.h>
#include "costanti.h"
#include "struttureDati.h"
#include "scritturaFile.h"


/**
 * Questa funzione aggiorna il file binario degli hotel, scrivendo sul file i dati degli
 * hotel presenti in memoria.
 * Un for scorre tutto l'array che contiene gli hotel e scrive sul file hotel.dat i dati
 * che incontra man mano.
 *
 * @post il valore restituito e' 0 quando c'e' un errore nell'apertura del file
 * @post il valore restituito e' 1 quando l'aggiunta dei nuovi dati e' andata a buon fine.
 */

int scritturaHotel(DATI_HOTEL h[]){
	FILE *ptrHotel;
	int i = 0;
	if((ptrHotel = fopen("datiProgetto/hotel.dat","wb")) == NULL){
		puts("\nERRORE!!! Impossibile aprire il file 'hotel.dat'.");
		return 0;
	}else{
		while(h[i].idCittaHotel != 0){
			fwrite(&h[i].idHotel, sizeof(h[i].idHotel), 1, ptrHotel);
			fwrite(h[i].nomeHotel, sizeof(h[i].nomeHotel), 1, ptrHotel);
			fwrite(&h[i].stelleHotel, sizeof(h[i].stelleHotel), 1, ptrHotel);
			fwrite(&h[i].prezzoHotel, sizeof(h[i].prezzoHotel), 1, ptrHotel);
			fwrite(&h[i].stanzeTotaliHotel, sizeof(h[i].stanzeTotaliHotel), 1, ptrHotel);
			fwrite(&h[i].stanzeLibereHotel, sizeof(h[i].stanzeLibereHotel), 1, ptrHotel);
			fwrite(&h[i].scontoMinoriHotel, sizeof(h[i].scontoMinoriHotel), 1, ptrHotel);
			fwrite(&h[i].idCittaHotel, sizeof(h[i].idCittaHotel), 1, ptrHotel);
			i += 1;
		}
	}

	fclose(ptrHotel);
	return 1;
}


/**
 * Questa funzione aggiorna il file binario delle compagnie aeree, scrivendo sul file i dati delle
 * compagnie aeree presenti in memoria.
 * Un for scorre tutto l'array che contiene le compagnieAeree e scrive sul file compagnieAeree.dat i dati
 * che incontra man mano.
 *
 * @post il valore restituito e' 0 quando c'e' un errore nell'apertura del file
 * @post il valore restituito e' 1 quando l'aggiunta dei nuovi dati e' andata a buon fine
 */


int scritturaCompagniaAerea(DATI_COMPAGNIA_AEREA  c[]){
	FILE *ptrCompagniaAerea;
	int i = 0;
	if((ptrCompagniaAerea = fopen("datiProgetto/compagnieAeree.dat","wb")) == NULL){
		puts("\nERRORE!!! Impossibile aprire il file 'compagnieAeree.dat'.");
		return 0;
	}else{
		while(c[i].idCompagnia != 0){
			fwrite(&c[i].idCompagnia, sizeof(c[i].idCompagnia), 1, ptrCompagniaAerea);
			fwrite(c[i].nomeCompagnia, sizeof(c[i].nomeCompagnia), 1, ptrCompagniaAerea);
			fwrite(c[i].nazioneCompagnia, sizeof(c[i].nazioneCompagnia), 1, ptrCompagniaAerea);
			fwrite(&c[i].prezzoOrarioCompagnia, sizeof(c[i].prezzoOrarioCompagnia), 1, ptrCompagniaAerea);
			i += 1;
		}

	}

	fclose(ptrCompagniaAerea);
	return 1;
}


/**
 * Questa funzione aggiorna il file binario dei tour operator, scrivendo sul file i dati dei
 * tour operator presenti in memoria.
 * Un for scorre tutto l'array che contiene i tour operator e scrive sul file tourOperator.dat i dati
 * che incontra man mano
 *
 * @post il valore restituito e' 0 quando c'e' un errore nell'apertura del file
 * @post il valore restituito e' 1 quando l'aggiunta dei nuovi dati e' andata a buon fine
 */

int scritturaTourOperator(DATI_TOUR_OPERATOR t[]){
	FILE *ptrTourOperator;
	int i = 0;

	if((ptrTourOperator = fopen("datiProgetto/tourOperator.dat","wb")) == NULL){
		puts("\nERRORE!!! Impossibile aprire il file 'tourOperator.dat'.");
		return 0;
	}else{
		while(t[i].idTourOperator != 0){
			fwrite(&t[i].idTourOperator, sizeof(t[i].idTourOperator), 1, ptrTourOperator);
			fwrite(&t[i].nomeTourOperator, sizeof(t[i].nomeTourOperator), 1, ptrTourOperator);
			fwrite(&t[i].cittaTourOperator, sizeof(t[i].cittaTourOperator), 1, ptrTourOperator);
			fwrite(&t[i].nazioneTourOperator, sizeof(t[i].nazioneTourOperator), 1, ptrTourOperator);
			i += 1;
		}
	}

	fclose(ptrTourOperator);
	return 1;
}

/**
 * Questa funzione aggiorna il file binario dei pacchetti viaggio, scrivendo sul file i dati dei
 * pacchetti viaggio presenti in memoria.
 * Un for scorre tutto l'array che contiene pacchettiViaggio e scrive sul file pacchettiViaggio.dat i dati
 * che incontra man mano.
 *
 * @post il valore restituito e' 0 quando c'e' un errore nell'apertura del file
 * @post il valore restituito e' 1 quando l'aggiunta dei nuovi dati e' andata a buon fine
 */
int scritturaPacchettiViaggio(DATI_PACCHETTO_VIAGGIO p[]){
	FILE *ptrPacchetti;
	int i = 0;

	if((ptrPacchetti = fopen("datiProgetto/pacchettiViaggio.dat","wb")) == NULL){
		puts("\nERRORE!!! Impossibile aprire il file 'pacchettiViaggio.dat'.");
		return 0;
	}else{
		while(p[i].idPartenzaPacchetto != 0){
			fwrite(&p[i].idPartenzaPacchetto, sizeof(p[i].idPartenzaPacchetto), 1, ptrPacchetti);
			fwrite(&p[i].idArrivoPacchetto, sizeof(p[i].idArrivoPacchetto), 1, ptrPacchetti);
			fwrite(&p[i].oreViaggioPacchetto, sizeof(p[i].oreViaggioPacchetto), 1, ptrPacchetti);
			fwrite(&p[i].minutiViaggioPacchetto, sizeof(p[i].minutiViaggioPacchetto), 1, ptrPacchetti);
			fwrite(&p[i].idCompagniaAereaPacchetto, sizeof(p[i].idCompagniaAereaPacchetto), 1, ptrPacchetti);
			fwrite(&p[i].categoriaVoloPacchetto, sizeof(p[i].categoriaVoloPacchetto), 1, ptrPacchetti);
			fwrite(&p[i].giorniPacchetto, sizeof(p[i].giorniPacchetto), 1, ptrPacchetti);
			fwrite(&p[i].idHotelPacchetto, sizeof(p[i].idHotelPacchetto), 1, ptrPacchetti);
			fwrite(&p[i].idTourOperatorPacchetto, sizeof(p[i].idTourOperatorPacchetto), 1, ptrPacchetti);
			fwrite(&p[i].scontoPacchetto, sizeof(p[i].scontoPacchetto), 1, ptrPacchetti);
			fwrite(&p[i].costoTotalePacchetto, sizeof(p[i].costoTotalePacchetto), 1, ptrPacchetti);
			i += 1;
		}
	}

	fclose(ptrPacchetti);
	return 1;
}

