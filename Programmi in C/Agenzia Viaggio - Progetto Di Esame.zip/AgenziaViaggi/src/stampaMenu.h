/**
* @file stampaMenu.h
*
* Questo header file contiene i prototipi delle funzioni che stampano le voci dei menu' a cui si accede dal menu principale.
*
* @version 0.1
* @authors Angelo Putignano, Roberto Modarelli
*/

/**
 * Stampa le voci del menu principale
 *
 */
void menuPrincipale();

/**
 * Stampa le voci del menu relativo ai pacchetti viaggio.
 *
 */
void menuPacchettiViaggio();

/**
 * Stampa le voci del menu relativo agli hotel.
 *
 */
void menuHotel();

/**
 * Stampa le voci del menu relativo ai tour operator.
 *
 */
void menuTourOperator();

/**
 * Stampa le voci del menu relativo alle compagnie aeree.
 *
 */
void menuCompagnieAeree();

/**
 * Stampa le voci del menu per creare i file testuali.
 *
 */
void menuFileTestuali();

/**
 * Stampa le voci del menu per la modifica degli hotel.
 *
 */
void menuModificaHotel();

/**
 * Stampa le voci del menu per la modifica dei tour operator.
 *
 */
void menuModificaTourOperator();

/**
 * Stampa le voci del menu per la modifica delle compagnie aeree.
 *
 */
void menuModificaCompagnieAeree();

/**
 * Stampa le voci del menu per la modifica dei pacchetti viaggio.
 *
 */
void menuModificaPacchettiViaggio();

/**
 * Stampa le voci del menu per la ricerca dei pacchetti viaggio
 *
 */
void menuRicerca();

/**
 * Stampa le varie fasce di prezzo per la ricerca dei pacchetti.
 *
 */
void menuIntervalloPrezzi();

/**
 * Stampa le due possibilita' di accesso alle funzionalita' del programma
 */
void menuAccesso();

/**
 * Stampa il menu per scegliere se uscire o produrre i file testuali
 */
void menuFinale();
