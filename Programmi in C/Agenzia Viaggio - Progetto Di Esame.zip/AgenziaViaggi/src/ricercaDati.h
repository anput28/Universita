/**
* @file ricercaDati.h
*
* Questo header file contiene i prototipi delle funzioni per la ricerca dei pacchetti viaggio
*
* @version 0.1
* @authors Angelo Putignano, Roberto Modarelli
*/

/**
 * Questa funzione permette di inserire i dati dei pacchetti che si vogliono cercare.
 * @param[in] scelta E' la scelta del filtro che si vuole inserire
 * @param[in] filtri[] Array in cui verra' inserito in filtro inserito
 * @param[in] p[] Array che contiene tutti i pacchetti viaggio presenti in memoria.
 * @param[in] d[] Array che contiene tutte le destinazioni presenti in memoria.
 * @param[in] v[] Array che contiene tutti gli orari dei voli tra le varie citta' presenti in memoria.
 * @param[in] c[] Array che contiene tutti le compagnie aeree presenti in memoria.
 * @param[in] h[] Array che contiene tutti gli hotel presenti in memoria
 * @param[in] t[] Array che contiene tutti i tour operator presenti in memoria.
 *
 * @return 1 se il filtro e' stato inserito correttamente nella giusta posizione dell'array 'filtri'
 * @return 0 se il filtro non e' stato inserito correttamente nella giusta posizione dell'array 'filtri'
 *
 */
int inserisciFiltri (int scelta,  int filtri[], DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_ORARIO_VOLO v[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[]);

/**
 * Questa funzione si occupa di ricercare i pacchetti viaggio che corrispondono ai filtri inseriti.
 * @param[in] p[] Array che contiene tutti i pacchetti viaggio
 * @param[in] indiciPacchetti[] Array in cui verranno messe le posizioni in p dei pacchetti viaggio che soddisfano i filtri scelti
 * @param[in] filtri[] Array che contiene tutti i dati che si vogliono cercare.
 *
 * @return La funzione ritorna il numero di pacchetti trovati.
 */
int ricercaPacchetti(DATI_PACCHETTO_VIAGGIO p[], int indiciPacchetti[], int filtri[]);

/**
 * Questa fuzione ordina in ordine crescente in base al prezzo i pacchetti viaggio trovati inseguito ad una ricerca.
 *
 * @param[in] contaIndici Serve a contare i pacchetti viaggio che vengono trovati
 * @param[in] indiciPacchetti[] Serve a memorizzare le posizioni dei pacchetti trovati
 * @param[in] p[] Array che contiene tutti i pacchetti viaggio
 */
void ordinaPacchettiCercati(int contaIndici, int indiciPacchetti[], DATI_PACCHETTO_VIAGGIO p[]);

/**
 * Funzione che raggruppa tutte le istruzioni necessarie ad effettuare la ricerca dei pacchetti viaggi.
 * @param[in] p[] Array che contiene tutti i pacchetti viaggio
 * @param[in] d[] Array che contiene tutte le possibili destinazioni dei viaggi
 * @param[in] v[] Array che contiene tutti gli orari dei voli
 * @param[in] c[] Array che contiene tutte le compagnie aeree
 * @param[in] h[] Array che contiene tutti gli hotel
 * @param[in] t[] Array che contiene tutti i tour operator
 */
void effettuaRicercaDati(DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_ORARIO_VOLO v[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[]);
