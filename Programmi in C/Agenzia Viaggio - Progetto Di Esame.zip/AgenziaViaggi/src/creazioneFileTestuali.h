/**
* @file creazioneFileTestuali.h
*
* Questo header file contiene i prototipi delle funzioni che gestiscono la creazione
* dei file testuali a partire dai dati presenti in memoria.
*
* @version 0.1
* @authors Roberto Modarelli, Angelo Putignano
*
*/


/**
* Questa funzione scrive sul file 'hotel.csv' tutti i dati relativi agli hotel.
*
* @param[in] h[] Array da cui verranno presi i dati da scrivere nel file 'hotel.csv'
* @param[in] d[] Array che serve per poter accedere al nome della citta' in cui si trova l'hotel
*
* @return 0 in caso di errore nell'apertura del file
* @return 1 se tutti i dati sono stati scritti con successo
*/
int creazioneHotelTestuale(DATI_HOTEL h[], DATI_DESTINAZIONE d[]);

/**
* Questa funzione scrive sul file 'pacchettiViaggio.csv' tutti i dati relativi ai pacchetti viaggio.
*
* @param[in] p[] Array che serve a leggere tutti i dati relativi ai pacchetti viaggio contenuti nel parametro attuale
* @param[in] d[] Array da cui verranno presi il nome della citta' di partenza e di arrivo
* @param[in] c[] Array da cui verra' preso il nome della compagnia aerea
* @param[in] t[] Array da cui verra' preso il nome del tour operator
* @param[in] h[] Array da cui verra' preso il nome dell'hotel
*
*
* @return 0 in caso di errore nell'apertura del file
* @return 1 se tutti i dati sono stati scritti con successo
*/
int creazionePacchettiViaggioTestuale(DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_COMPAGNIA_AEREA c[], DATI_TOUR_OPERATOR t[], DATI_HOTEL h[]);

/**
* Questa funzione scrive sul file 'destinazioni.csv' i dati delle citta' presenti in memoria.
*
* @param[in] d[] Array da cui verranno presi tutti i dati da scrivere nel file .csv
*
* @return 0 in caso di errore nell'apertura del file
* @return 1 se tutti i dati sono stati scritti con successo
*/
int creazioneDestinazioniTestuale(DATI_DESTINAZIONE d[]);

/**
* La funzione scrive tutti i dati relativi alle compagnie aeree nel file 'compagnieAeree.csv'.
*
* @param[in] c[] Array da cui verranno presi tutti i dati da scrivere nel file .csv
*
* @return 0 in caso di errore nell'apertura del file
* @return 1 se tutti i dati sono stati scritti con successo
*/
int creazioneCompagnieTestuale(DATI_COMPAGNIA_AEREA c[]);

/**
* La funzione scrive tutti i dati relativi ai tour operator nel file 'tourOperator.csv'.
*
* @param[in] t[] Array da cui verranno presi tutti i dati da scrivere nel file .csv
*
* @return 0 in caso di errore nell'apertura del file
* @return 1 se tutti i dati sono stati scritti con successo
*/
int creazioneTourOperatorTestuale(DATI_TOUR_OPERATOR t[]);

/**
 * Questa funzione raggruppa tutte le istruzioni per gestire la creazione dei file testuali.
 *
 * @param[in] d[] Array che contiene tutte le possibili destinazioni dei viaggi
 * @param[in] c[] Array che contiene tutti i dati delle compagnie aeree
 * @param[in] h[] Array che contiene tutti i dati degli hotel
 * @param[in] t[] Array che contiene tutti i dati dei tour operator
 * @param[in] p[] Array che contiene tutti i pacchetti viaggio presenti in memoria
 *
 * @return Valore che indica se e' stato creato almeno un file testuale
 */
int gestisciCreazioneFileTestuali(DATI_DESTINAZIONE d[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[], DATI_PACCHETTO_VIAGGIO p[]);
