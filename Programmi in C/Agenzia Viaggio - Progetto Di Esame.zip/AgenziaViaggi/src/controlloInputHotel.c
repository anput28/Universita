#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "struttureDati.h"
#include "controlloInput.h"
#include "controlloInputHotel.h"
#include "costanti.h"

/**
* Questa funzione permette di inserire il numero di stelle di un hotel.
* Controlla solo il primo carattere inserito da tastiera.
* Acquisita la stringa, controlla se il primo carattere non sia un numero, se e' cosi' le stelle vengono messe automaticamente a 0,
* altrimenti stampa un messaggio di errore e aspetta il prossimo input.
* Se il primo carattere e' un numero, controlla che sia compreso tra i due parametri passati (minStelle e maxStelle).
* Se non e' compreso stampa un messaggio di errore e aspetta il prossimo input.
* Quando l'input e' corretto, lo restituisce.
*
* @post la funzione ritorna il numero di stelle inserite.
*/
int inserireStelle(int minStelle, int maxStelle){
	char stelleChar[2];
	int stelleInt;
	char c;

	puts("\n\n------------------------------------ STELLE HOTEL ------------------------------------");

	do{
		puts("\nIl sistema considera solo il primo carattere inserito.");
		printf("Inserire il numero di STELLE dell'hotel --> ");
		fgets(stelleChar,2,stdin);

		//pulisce il buffer solo se vengono inseriti pi� caratteri di quanti indicati
		if(strlen(stelleChar) > 0 && stelleChar[strlen(stelleChar)-1] != '\n'){
			while((c = getchar()) != '\n' && c != EOF);
		}

		if(!isdigit(stelleChar[0])){
			puts("\nERRORE!!! Inserire solo numeri.\n");
			stelleInt = 0;
		}else{
			//converte stelleChar in un long int tramite strtol e con un apposito cast viene convertito in int
			stelleInt = (int)strtol(stelleChar,NULL, 10);
			if(stelleInt < minStelle || stelleInt > maxStelle){
				printf("\nATTENZIONE!!! Inserire un numero delle stelle compreso tra %d - %d.\n", MIN_NUM_STELLE, MAX_NUM_STELLE);
			}
		}
	}while(stelleInt < minStelle || stelleInt > maxStelle);

	return stelleInt;
}

/**
* Questa funzione permette di inserire il prezzo di un hotel.
* Una volta inserito il prezzo sotto forma di stringa, analizzando ogni carattere di questa controlla che non siano stati inseriti simboli o
* lettere. Se il controllo ha esito negativo viene stampato un messaggio di errore e il prezzo viene messo a 0 per indicare che l'input non e' valido.
* Se sono stati inseriti solo numeri allora il prezzo in stringa viene convertito in intero e in base al numero di stelle, passate per parametro,
* tramite una switch viene controllato se l'input rientra nel range di valori previsti nella prima fascia (1 stella), nella seconda fascia (2, 3 stelle)
* e nella terza fascia (4,5 stelle).
* Se il prezzo inserito non e' compreso nel range questo viene messo a 0 (scelto come valore di non correttezza).
* La funzione fa reinserire il prezzo finche' questo non e' diverso da 0.
*
*
* @post la funzione ritorna il prezzo dell'hotel.
*/
int inserirePrezzoHotel(int stelle){
	char prezzoChar[MAX_CARATTERI_PREZZO_HOTEL];
	int prezzoInt;
	char c;

	puts("\n\n------------------------------------ PREZZO HOTEL ------------------------------------");

	do{
		//inizializza prezzoInt ad un valore diverso da 0, perch� 0 indica che il valore inserito non � corretto, per lo scopo � stato scelto 1.
		prezzoInt = 1;
		printf("\nIl sistema considera solo i primi %d caratteri.\n", MAX_CARATTERI_PREZZO_HOTEL-1);
		puts("Inserire un valore intero, il sistema non accetta valori decimali.");
		printf("Inserire il PREZZO per notte dell'hotel --> ");
		fgets(prezzoChar,MAX_CARATTERI_PREZZO_HOTEL,stdin);

		//pulisce il buffer solo se vengono inseriti pi� caratteri di quanti indicati
		if(strlen(prezzoChar) > 0 && prezzoChar[strlen(prezzoChar)-1] != '\n'){
			while((c = getchar()) != '\n' && c != EOF);
		}


		//dopo l'input la funzione sostituisce il carattere '\n' che prende fgets con '\0'
		for(int i = 0; i < strlen(prezzoChar); i++){
			if(prezzoChar[i] == '\n'){
				prezzoChar[i] = '\0';
			}
		}

		/*controlla che non siano state inserite lettere o simboli, se sono stati inseriti il prezzo
		 * viene messo di default a 0.*/
		for(int i = 0; i < strlen(prezzoChar); i++){
			if(!isdigit(prezzoChar[i])){
				prezzoInt = 0;
			}
		}

		if(prezzoInt == 0){
			puts("\nERRORE!!! Inserire solo numeri.");
		}else{
			//converte prezzoChar in un long int tramite strtol e con un apposito cast viene convertito in int
			prezzoInt = (int)strtol(prezzoChar,NULL, 10);

			switch(stelle){
				case 1:
					if(prezzoInt < MIN_PREZZO_PRIMA_FASCIA || prezzoInt > MAX_PREZZO_PRIMA_FASCIA){
						printf("\nERRORE!!! Il prezzo dell'hotel deve essere compreso tra %d e %d.\n", MIN_PREZZO_PRIMA_FASCIA, MAX_PREZZO_PRIMA_FASCIA);
						prezzoInt = 0;
					}
					break;
				case 2:
				case 3:
					if(prezzoInt < MIN_PREZZO_SECONDA_FASCIA || prezzoInt > MAX_PREZZO_SECONDA_FASCIA){
						printf("\nERRORE!!! Il prezzo dell'hotel deve essere compreso tra %d e %d.\n", MIN_PREZZO_SECONDA_FASCIA, MAX_PREZZO_SECONDA_FASCIA);
						prezzoInt = 0;
					}
					break;
				case 4:
				case 5:
					if(prezzoInt < MIN_PREZZO_TERZA_FASCIA || prezzoInt > MAX_PREZZO_TERZA_FASCIA){
						printf("\nERRORE!!! Il prezzo dell'hotel deve essere compreso tra %d e %d.\n", MIN_PREZZO_TERZA_FASCIA, MAX_PREZZO_TERZA_FASCIA);
						prezzoInt = 0;
					}
					break;
				}
		}
	}while(prezzoInt == 0);

	return prezzoInt;
}

/**
* Questa funzione permette di inserire il numero di stanze totali di un hotel.
* Una volta inserito il numero di stanze totali sotto forma di stringa, analizzando ogni carattere di
* questa controlla che non siano stati inseriti simboli o lettere. Se il controllo ha esito negativo viene
* stampato un messaggio di errore e il numero di stanze totali viene messo a 0 per indicare che l'input
* non e' valido. Se sono stati inseriti solo numeri allora il numero di stanze totali in stringa viene
* convertito in intero.
* Se il numero di stanze totali inserito non e' compreso nel range dei valori attesi (da minStanze
* a maxStanze) questo viene messo a 0 (scelto come valore di non correttezza).
* La funzione fa reinserire il numero di stanze totali finche' questo non e' diverso da 0.
*
*
* @post la funzione ritorna il numero di stanze totali dell'hotel.
*/
int inserireStanzeTotali(int minStanze, int maxStanze){
	char stanzeTotaliChar[MAX_CARATTERI_STANZE_HOTEL];
	int stanzeTotaliInt;
	char c;

	puts("\n\n----------------------------- STANZE TOTALI HOTEL -----------------------------");

	do{
		//inizializza stanzeTotaliInt ad un valore diverso da 0, perch� 0 indica che il valore inserito non � corretto, per lo scopo � stato scelto 1.
		stanzeTotaliInt = 1;
		printf("\nIl sistema considera solo i primi %d caratteri.\n",MAX_CARATTERI_STANZE_HOTEL-1);
		puts("Inserire un valore intero, il sistema non accetta valori decimali.");
		printf("Inserire il numero di STANZE TOTALI dell'hotel --> ");
		fgets(stanzeTotaliChar,MAX_CARATTERI_STANZE_HOTEL,stdin);

		//pulisce il buffer solo se vengono inseriti pi� caratteri di quanti indicati
		if(strlen(stanzeTotaliChar) > 0 && stanzeTotaliChar[strlen(stanzeTotaliChar)-1] != '\n'){
			while((c = getchar()) != '\n' && c != EOF);
		}

		//dopo l'input la funzione sostituisce il carattere '\n' che prende fgets con '\0'
		for(int i = 0; i < strlen(stanzeTotaliChar); i++){
			if(stanzeTotaliChar[i] == '\n'){
				stanzeTotaliChar[i] = '\0';
			}
		}

		/*controlla che non siano stati inserite lettere o simboli, se sono stati inseriti il numero
		 * di stanze totali viene messo di default a 0
		 */
		for(int i = 0; i < strlen(stanzeTotaliChar); i++){
			if(!isdigit(stanzeTotaliChar[i])){
				stanzeTotaliInt = 0;
			}
		}

		if(stanzeTotaliInt == 0){
			puts("\nERRORE!!! Inserire solo numeri.");
		}else{
			//converte stanzaTotaliChar in un long int tramite strtol e con un apposito cast viene convertito in int
			stanzeTotaliInt = (int)strtol(stanzeTotaliChar,NULL, 10);
			if(stanzeTotaliInt < minStanze || stanzeTotaliInt > maxStanze){
				printf("\nERRORE!!! Inserire un numero compreso tra %d e %d.\n", minStanze, maxStanze);
				stanzeTotaliInt = 0;
			}
		}
	}while(stanzeTotaliInt == 0);

	return stanzeTotaliInt;
}

/**
* Questa funzione permette di inserire il numero di stanze libere di un hotel.
* Una volta inserito il numero di stanze libere sotto forma di stringa, analizzando ogni carattere di
* questa controlla che non siano stati inseriti simboli o lettere. Se il controllo ha esito negativo viene
* stampato un messaggio di errore e il numero di stanze libere viene messo a 0 per indicare che l'input
* non e' valido. Se sono stati inseriti solo numeri allora il numero di stanze libere in stringa viene
* convertito in intero.
* Se il numero di stanze libere e' maggiore del numero di stanze totali  allora viene stampato un messaggio
* di errore e il numero di stanze libere viene messo a 0.
* La funzione fa reinserire il numero di stanze libere finche' questo non e' diverso da 0.
*
*
* @post la funzione ritorna il numero di stanze libere dell'hotel.
*/
int inserireStanzeLibere(int stanzeTotali){
	char stanzeLibereChar[MAX_CARATTERI_STANZE_HOTEL];
	int stanzeLibereInt;
	char c;

	puts("\n\n----------------------------- STANZE LIBERE HOTEL -----------------------------");

	do{
		//inizializza stanzeLibereInt ad un valore diverso da 0, perch� 0 indica che il valore inserito non � corretto, per lo scopo � stato scelto 1.
		stanzeLibereInt = 1;
		printf("\nIl sistema considera solo i primi %d caratteri.\n",MAX_CARATTERI_STANZE_HOTEL-1);
		puts("Inserire un valore intero, il sistema non accetta valori decimali.");
		printf("Inserire il numero di STANZE LIBERE dell'hotel --> ");
		fgets(stanzeLibereChar,MAX_CARATTERI_STANZE_HOTEL,stdin);

		//pulisce il buffer solo se vengono inseriti pi� caratteri di quanti indicati
		if(strlen(stanzeLibereChar) > 0 && stanzeLibereChar[strlen(stanzeLibereChar)-1] != '\n'){
			while((c = getchar()) != '\n' && c != EOF);
		}

		//dopo l'input la funzione sostituisce il carattere '\n' che prende fgets con '\0'
		for(int i = 0; i < strlen(stanzeLibereChar); i++){
			if(stanzeLibereChar[i] == '\n'){
				stanzeLibereChar[i] = '\0';
			}
		}

		/*controlla che non siano stati inserite lettere o simboli, se sono stati inseriti il numero
		 * di stanze libere viene messo di default a 0
		 */
		for(int i = 0; i < strlen(stanzeLibereChar); i++){
			if(!isdigit(stanzeLibereChar[i])){
				stanzeLibereInt = 0;
			}
		}

		if(stanzeLibereInt == 0){
			puts("\nERRORE!!! Inserire solo numeri.");
		}else{
			//converte stanzaTotaliChar in un long int tramite strtol e con un apposito cast viene convertito in int
			stanzeLibereInt = (int)strtol(stanzeLibereChar,NULL, 10);
			if(stanzeLibereInt > stanzeTotali){
				puts("\nERRORE!!! Le stanze libere non possono essere maggiori di quelle totali.");
				stanzeLibereInt = 0;
			}else if(stanzeLibereInt == 0){
				puts("\nATTENZIONE!!! Deve esserci almeno una stanza libera\n");
			}
		}
	}while(stanzeLibereInt == 0);

	return stanzeLibereInt;
}

/**
* Questa funzione permette di inserire la percentuale di sconto minorenni applicata da un hotel.
* Una volta inserito l'input sotto forma di stringa, analizzando ogni carattere di
* questa controlla che non siano stati inseriti simboli o lettere. Se il controllo ha esito negativo viene
* stampato un messaggio di errore e il flag che indica la correttezza dell'input viene messo a 0 per indicare che l'input
* non e' valido. Se sono stati inseriti solo numeri allora l'input in stringa viene convertito in intero.
* Se la percentuale di sconto e' maggiore della massima percentuale di sconto applicabile (maxSconto)
* allora viene stampato di errore e il flag viene messo a 0.
* La funzione fa reinserire la percentuale di sconto finche' il flag di correttezza non e' diverso da 0.
*
*
* @post la funzione ritorna la percentuale di sconto minorenni applicata dall'hotel
*/
int inserireScontoHotel(int maxSconto){
	char scontoChar[MAX_CARATTERI_SCONTO];
	int scontoInt;
	int flag; //variabile booleana che indica se l'input � corretto (1) o meno (0)
	char c;

	puts("\n\n------------------------------------ SCONTO HOTEL ------------------------------------");

	do{
		//il flag viene inizializzato ad un valore che indica che l'input � corretto
		flag = 1;

		printf("\nIl sistema considera solo i primi %d caratteri.\n", MAX_CARATTERI_SCONTO-1);
		puts("Inserire un valore intero, il sistema non accetta valori decimali.");
		printf("Inserire la percentuale di SCONTO MINORI previsto dall'hotel --> ");
		fgets(scontoChar,MAX_CARATTERI_SCONTO,stdin);

		//pulisce il buffer solo se vengono inseriti pi� caratteri di quanti indicati
		if(strlen(scontoChar) > 0 && scontoChar[strlen(scontoChar)-1] != '\n'){
			while((c = getchar()) != '\n' && c != EOF);
		}

		//dopo l'input la funzione sostituisce il carattere '\n' che prende fgets con '\0'
		for(int i = 0; i < strlen(scontoChar); i++){
			if(scontoChar[i] == '\n'){
				scontoChar[i] = '\0';
			}
		}

		/*controlla che non siano stati inserite lettere o simboli, se sono stati inseriti il numero
		 * di stanze libere viene messo di default a 0
		 */
		for(int i = 0; i < strlen(scontoChar); i++){
			if(!isdigit(scontoChar[i])){
				flag = 0;
			}
		}

		if(flag == 0){
			puts("\nERRORE!!! Inserire solo numeri.");
			flag = 0;
		}else{
			//converte scontoChar in un long int tramite strtol e con un apposito cast viene convertito in int
			scontoInt = (int)strtol(scontoChar,NULL, 10);

			if(scontoInt > maxSconto){
				printf("\nERRORE!!! Il massimo sconto applicabile e' pari a %d.\n", maxSconto);
				flag = 0;
			}
		}
	}while(flag == 0);

	return scontoInt;
}

/**
 * Questa funzione permette di inserire l'id della citta' in cui e' situato un hotel.
 * Prima vengono stampati i nomi delle possibili citta' di appartenenza (4 per riga) sottoforma
 * di menu, quindi l'utente deve scegliere la citta' scrivendo l'indice corrispondente,
 * cosa che viene fatta utilizzando la funzione inserisciScelta.
 *
 * @post la funzione ritorna l'id della citta' scelta.
 */
int inserireIdCittaHotel(DATI_DESTINAZIONE d[]){
	int sceltaIdCitta;
	int i;

	puts("\n\n------------------------------------ CITTA' HOTEL ------------------------------------");


	puts("\nScegli la CITTA' in cui e' situato l'hotel:");
	for(i = 1; i <= NUM_DESTINAZIONI; i++){
		if(i % 4 == 0){
			printf("%2d) %-20s\n",i, d[i-1].cittaDestinazione);
		}else{
			printf("%2d) %-20s",i, d[i-1].cittaDestinazione);
		}

	}
	puts("\n");
	//1 � la scelta minima, i � la scelta massima e 3 � il numero di caratteri inseribili nella scelta
	sceltaIdCitta = inserisciScelta(1, NUM_DESTINAZIONI, 3);

	return sceltaIdCitta;
}
