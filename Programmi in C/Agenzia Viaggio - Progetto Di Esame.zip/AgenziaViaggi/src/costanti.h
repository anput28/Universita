/**
* @file costanti.h
*
* Questo header file contiene tutte le costanti utilizzate nel progetto.
*
* @version 0.1
* @authors Angelo Putignano, Roberto Modarelli
* @warning il programma non funziona se non viene inclusa in tutti i file in cui vengono usate le costanti che questa libreria contiene
*/
///Lunghezza massima del nome di una citta'.
#define LUNGH_NOME_CITTA 20
///Lunghezza massima del nome di una nazione.
#define LUNGH_NOME_NAZIONE 20
///Lunghezza massima del nome di un hotel.
#define LUNGH_NOME_HOTEL 30
///Lunghezza massima del nome di una compagnia aerea.
#define LUNGH_NOME_COMPAGNIA 20
///Lunghezza massima del nome di un tour operator.
#define LUNGH_NOME_TOUR_OPERATOR 20

/// Numero massimo di hotel memorizzabili.
#define MAX_NUM_HOTEL 150
///Numero massimo di tour operator memorizzabili.
#define MAX_NUM_TOUR_OPERATOR 50
///Numero massimo di compagnie aeree memorizzabili.
#define MAX_NUM_COMPAGNIE 30
///Numero massimo di pacchetti viaggio memorizzabili.
#define MAX_NUM_PACCHETTI 150
 ///Numero di citta' presenti in memoria.
#define NUM_DESTINAZIONI 27
 ///Numero totale dei voli che possono essere  organizzati tra le citta' presenti nel programma
#define NUM_VOLI 729

/// Prima voce del menu' principale.
#define NUM_MIN_MENU_PRINCIPALE 1
///Ultima voce del menu' principale.
#define NUM_MAX_MENU_PRINCIPALE 6
///Prima voce del menu' finale.
#define NUM_MIN_MENU_FINALE 1
///Ultima voce del menu' finale.
#define NUM_MAX_MENU_FINALE 2
///Prima voce del menu' per la creazione dei file testuali.
#define NUM_MIN_MENU_FILE_TESTUALI 1
///Ultima voce del menu' per la creazione dei file testuali.
#define NUM_MAX_MENU_FILE_TESTUALI 6
///Prima voce del sottomenu' del menu' principale.
#define NUM_MIN_SOTTOMENU 1
///Ultima voce del sottomenu' del menu' principale.
#define NUM_MAX_SOTTOMENU 4
///Prima voce del menu' per la modifica degli hotel
#define NUM_MIN_MODIFICA_HOTEL 1
///Ultima voce del menu' per la modifica degli hotel
#define NUM_MAX_MODIFICA_HOTEL 8
///Prima voce del menu' per la modifica dei tour operator
#define NUM_MIN_MODIFICA_OPERATOR 1
///Ultima voce del menu' per la modifica dei tour operator
#define NUM_MAX_MODIFICA_OPERATOR 4
///Prima voce del menu' per la modifica delle compagnie aeree
#define NUM_MIN_MODIFICA_COMPAGNIA 1
///Ultima voce del menu' per la modifica delle compagnie aeree
#define NUM_MAX_MODIFICA_COMPAGNIA 4
///Prima voce del menu' per la modifica dei pacchetti viaggio
#define NUM_MIN_MODIFICA_PACCHETTI 1
///Ultima voce del menu' per la modifica dei pacchetti viaggio
#define NUM_MAX_MODIFICA_PACCHETTI 9
///Prima voce del menu' per la ricerca dei pacchetti viaggio
#define NUM_MIN_MENU_RICERCA 1
///Ultima voce del menu' per la ricerca dei pacchetti viaggio
#define NUM_MAX_MENU_RICERCA 10
///Prima voce del menu' per scegliere la fascia di prezzo entro cui cercare i pacchetti
#define NUM_MIN_MENU_FASCE_PREZZO 1
/// Ultima voce del menu' per scegliere la fascia di prezzo entro cui cercare i pacchetti
#define NUM_MAX_MENU_FASCE_PREZZO 4

///Numero massimo di simboli ammessi per il nome dell'hotel
#define NUM_MAX_SIMBOLI_HOTEL 4
/// Numero massimo di simobli ammessi nel nome di una compagnia aerea
#define NUM_MAX_SIMBOLI_COMPAGNIA 2
///Numero massimo di simboli ammessi nel nome di un tour operator
#define NUM_MAX_SIMBOLI_OPERATOR 1

///Numero minimo di caratteri del nome di : hotel, citta', nazioni, tour operator, compagnie aeree.
#define NUM_MIN_CARATTERI_NOME 4

///Numero massimo di numeri ammessi nel nome dell'hotel.
#define NUM_MAX_NUMERI_HOTEL 5
///Numero massimo di numeri ammessi nel nome di una compagnia aerea
#define NUM_MAX_NUMERI_COMPAGNIA 4
///Numero massimo di numeri ammessi nel nome di un tour operator
#define NUM_MAX_NUMERI_OPERATOR 2

///Numero minimo di lettere ammesse nel nome dell'hotel.
#define NUM_MIN_LETTERE_HOTEL 4
///Numero minimo di lettere ammesse nel nome di una compagnia aerea
#define NUM_MIN_LETTERE_COMPAGNIA 3
/// Numero minimo di lettere ammesse nel nome di una citta'
#define NUM_MIN_LETTERE_CITTA 4
///Numero minimo di lettere ammesse nel nome di una nazione
#define NUM_MIN_LETTERE_NAZIONE 4
///Numero minimo di lettere ammesse nel nome di un tour operator
#define NUM_MIN_LETTERE_OPERATOR 6

/// Numero minimo di stelle di un hotel.
#define MIN_NUM_STELLE 1
///Numero massimo di stelle di un hotel.
#define MAX_NUM_STELLE 5

///Prezzo minimo per gli hotel con 1 stella.
#define MIN_PREZZO_PRIMA_FASCIA 10
///Prezzo massimo per gli hotel con 1 stella.
#define MAX_PREZZO_PRIMA_FASCIA 200
/// Prezzo minimo per gli hotel con 2 e 3 stelle.
#define MIN_PREZZO_SECONDA_FASCIA 30
///Prezzo massimo per gli hotel con 2 e 3 stelle.
#define MAX_PREZZO_SECONDA_FASCIA 500
///Prezzo minimo per gli hotel con 4 e 5 stelle.
#define MIN_PREZZO_TERZA_FASCIA 50
///Prezzo massimo per gli hotel con 4 e 5 stelle.
#define MAX_PREZZO_TERZA_FASCIA 20000

///Numero massimo di caratteri inseribili per indicare il prezzo dell'hotel.
#define MAX_CARATTERI_PREZZO_HOTEL 6
///Numero massimo di caratteri inseribili per indicare il numero di stanze (totali/libere) di un hotel.
#define MAX_CARATTERI_STANZE_HOTEL 5
///Numero massimo di caratteri inseribili per indicare lo sconto minorenni di un hotel.
#define MAX_CARATTERI_SCONTO 3
///Numero massimo di caratteri inseribili per indicare il prezzo orario di una compagnia aerea come una stringa
#define MAX_CARATTERI_PREZZO_COMPAGNIA 7

///Numero minimo di stanze di un hotel.
#define MIN_STANZE_TOTALI 7
/// Numero massimo di stanze di un hotel.
#define MAX_STANZE_TOTALI 3000
///Massima percentuale di sconto minorenni che puo' essere applicata da un hotel.
#define MAX_SCONTO_HOTEL 70
///Minima percentuale di sconto che pu� essere applicata ad un pacchetto viaggio
#define MIN_SCONTO_PACCHETTO 10
///Massima percentuale di sconto che pu� essere applicata ad un pacchetto viaggio
#define MAX_SCONTO_PACCHETTO 70

///Prezzo orario minimo di una compagnia aerea
#define MIN_PREZZO_COMPAGNIA 10.00
///Prezzo orario massimo di una compagnia aerea
#define MAX_PREZZO_COMPAGNIA 100.00

///Costante che indica la categoria di volo Economy
#define NUM_MIN_CATEGORIA 1
///Costante che indica la categoria di volo Business
#define NUM_MAX_CATEGORIA 2
///Durata minima di un pacchetto viaggio
#define NUM_MIN_GIORNI 2
///Durata massima di un pacchetto viaggio
#define NUM_MAX_GIORNI 10

///Costo del tour operator (uguale per tutti, usato nel calcolo del costo del pacchetto viaggio)
#define COSTO_TOUR_OPERATOR 30

///Numero di simboli ammessi nel nome di un hotel
#define NUM_SIMBOLI_HOTEL 9
///Numero di simboli ammessi nel nome di una compagnia aerea
#define NUM_SIMBOLI_COMPAGNIA 4
///Numero di simboli ammessi nel nome di un tour operator
#define NUM_SIMBOLI_OPERATOR 3
