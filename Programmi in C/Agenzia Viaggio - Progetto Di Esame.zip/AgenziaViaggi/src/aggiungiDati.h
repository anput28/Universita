/**
* @file aggiungiDati.h
*
* Questo header file contiene i prototipi delle funzioni che permettono di inserire i dati relativi
* all'aggiunta di : un nuovo hotel, una nuova compagnia aerea, un nuovo tour operator e un
* nuovo pacchetto viaggio.
*
* @version 0.1
* @authors Angelo Putignano, Roberto Modarelli
*/

//variabili globali che servono ogni volta che viene usata la funzione inserireNome.
extern char simboliHotel[NUM_SIMBOLI_HOTEL]; //elenco dei simboli accettabili nel nome di un hotel
extern char simboliCompagnia[NUM_SIMBOLI_COMPAGNIA];  //elenco dei simboli accettabili nel nome di una compagnia aerea
extern char simboliOperator[NUM_SIMBOLI_OPERATOR]; //elenco dei simboli accettabili nel nome di un tour operator

/**
 * Questa funzione si occupa di chiamare le funzioni che permettono di aggiungere i singoli dati di un pacchetto viaggio.
 *
 * @param[in] d[] Array che contiene tutte le possibili destinazioni dei viaggi
 * @param[in] v[] Array che contiene tutti gli orari dei voli
 * @param[in] c[] Array che contiene tutti i dati delle compagnie aeree
 * @param[in] h[] Array che contiene tutti i dati degli hotel
 * @param[in] t[] Array che contiene tutti i dati dei tour operator
 *
 * @return l'insieme dei dati inseriti in una variabile di tipo DATI_PACCHETTO_VIAGGIO
 */
DATI_PACCHETTO_VIAGGIO aggiungiPacchettoViaggio(DATI_DESTINAZIONE d[], DATI_ORARIO_VOLO v[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[]);

/**
 * Questa funzione si occupa di chiamare le funzioni che permettono di aggiungere i singoli dati di un nuovo hotel.
 *
 * @param[in] d[] Array che contiene tutte le possibili destinazioni dei viaggi
 * @param[in] ultimoElemento Contiene l'indice dell'ultimo elemento nel vettore degli hotel, serve per calcolare l'id del nuovo hotel.
 *
 * @return l'insieme dei dati inseriti in una variabile di tipo DATI_HOTEL
 */
DATI_HOTEL aggiungiHotel(DATI_DESTINAZIONE d[], int ultimoElemento);

/**
 * Questa funzione si occupa di chiamare le funzioni che permettono di aggiungere i singoli dati di una nuova compagnia aerea.
 *
 * @param[in] ultimoElemento Contiene l'indice dell'ultimo elemento nell'array delle compagnie aeree, serve per calcolare l'id della nuova compagnia aerea.
 *
 * @return l'insieme dei dati inseriti in una variabile di tipo DATI_COMPAGNIA_AEREA
 */
DATI_COMPAGNIA_AEREA aggiungiCompagnia(int ultimoElemento);

/**
 * Questa funzione si occupa di chiamare le funzioni che permettono di aggiungere i singoli dati di un nuovo tour operator.
 *
 * @param[in] ultimoElemento Contiene l'indice dell'ultimo elemento nell'array delle tour operator, serve per calcolare l'id della nuova tour operator.
 *
 * @return l'insieme dei dati inseriti in una variabile di tipo DATI_TOUR_OPERATOR
 */
DATI_TOUR_OPERATOR aggiungiTourOperator(int ultimoElemento);

/**
 * Questa funzione raggruppa tutte le istruzioni che servono per aggiungere un pacchetto viaggio in memoria.
 * @param[in] indiceMassimo Posizione dell'ultimo pacchetto viaggio presente in memoria
 * @param[in] p[] Array che contiene tutti i pacchetti viaggio presenti in memoria
 * @param[in] d[] Array che contiene tutte le possibili destinazioni dei viaggi
 * @param[in] v[] Array che contiene gli orari di tutti i possibili voli tra le varie citta'
 * @param[in] c[] Array che contiene tutte le compagnie aeree presenti in memoria
 * @param[in] h[] Array che contiene tutti gli hotel presenti in memoria
 * @param[in] t[] Array che contiene tutti i tour operator presenti i memoria
 */
void effettuaAggiuntaPacchetto(int indiceMassimo, DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_ORARIO_VOLO v[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[]);

/**
 * Questa funzione raggruppa tutte le istruzioni che servono per aggiungere un hotel in memoria.
 * @param[in] indiceMassimo Posizione dell'ultimo hotel presente in memoria
 * @param[in] p[] Array che contiene tutti i pacchetti viaggio presenti in memoria
 * @param[in] d[] Array che contiene tutte le possibili destinazioni dei viaggi
 * @param[in] v[] Array che contiene gli orari di tutti i possibili voli tra le varie citta'
 * @param[in] c[] Array che contiene tutte le compagnie aeree presenti in memoria
 * @param[in] h[] Array che contiene tutti gli hotel presenti in memoria
 * @param[in] t[] Array che contiene tutti i tour operator presenti i memoria
 */
void effettuaAggiuntaHotel(int indiceMassimo, DATI_HOTEL h[], DATI_DESTINAZIONE d[]);

/**
 * Questa funzione raggruppa tutte le istruzioni che servono per aggiungere un tour operator in memoria.
 * @param[in] indiceMassimo Posizione dell'ultimo tour operator presente in memoria
 * @param[in] p[] Array che contiene tutti i pacchetti viaggio presenti in memoria
 * @param[in] d[] Array che contiene tutte le possibili destinazioni dei viaggi
 * @param[in] v[] Array che contiene gli orari di tutti i possibili voli tra le varie citta'
 * @param[in] c[] Array che contiene tutte le compagnie aeree presenti in memoria
 * @param[in] h[] Array che contiene tutti gli hotel presenti in memoria
 * @param[in] t[] Array che contiene tutti i tour operator presenti i memoria
 */
void effettuaAggiuntaOperator(int indiceMassimo, DATI_TOUR_OPERATOR t[]);

/**
 * Questa funzione raggruppa tutte le istruzioni che servono per aggiungere una compagnia aerea in memoria.
 * @param[in] indiceMassimo Posizione dell'ultima compagnia aerea presente in memoria
 * @param[in] p[] Array che contiene tutti i pacchetti viaggio presenti in memoria
 * @param[in] d[] Array che contiene tutte le possibili destinazioni dei viaggi
 * @param[in] v[] Array che contiene gli orari di tutti i possibili voli tra le varie citta'
 * @param[in] c[] Array che contiene tutte le compagnie aeree presenti in memoria
 * @param[in] h[] Array che contiene tutti gli hotel presenti in memoria
 * @param[in] t[] Array che contiene tutti i tour operator presenti i memoria
 */
void effettuaAggiuntaCompagnia(int indiceMassimo, DATI_COMPAGNIA_AEREA c[]);
