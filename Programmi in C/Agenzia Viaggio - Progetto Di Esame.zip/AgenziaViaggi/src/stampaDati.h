/**
* @file stampaDati.h
*
* Questo header file contiene i prototipi delle funzioni che gestiscono la stampa dei dati presenti in memoria.
*
* @version 0.1
* @authors Angelo Putignano, Roberto Modarelli
*
*/

/**
* Questa funzione legge tutti i dati relativi ai pacchetti viaggio e li stampa su schermo.
*
* @param[in] p[] Array da cui prendere i dati relativi ai pacchetti viaggio
* @param[in] d[] Array da cui prendere i dati relativi alle destinazioni
* @param[in] c[] Array da cui prendere i dati relativi le compagnie aeree
* @param[in] t[] Array da cui prendere i dati relativi ai tour operator
* @param[in] h[] Array da cui prendere i dati relativi agli hotel
*
* @return La posizione dell'ultimo pacchetto viaggio in memoria
*/
int stampaPacchettiViaggio(DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_COMPAGNIA_AEREA c[], DATI_TOUR_OPERATOR t[], DATI_HOTEL h[]);

/**
* Questa funzione legge tutti i dati relativi agli hotel e li stampa su schermo
*
* @param[in] d[] Array da cui prendere i dati relativi alle destinazioni
* @param[in] h[] Array da cui prendere i dati relativi agli hotel
*
* @return La posizione dell'ultimo hotel in memoria
*/
int stampaHotel(DATI_HOTEL h[],DATI_DESTINAZIONE d[]);


/**
* Questa funzione legge tutti i dati relativi ai tour operator e li stampa su schermo
*
* @param[in] t[] Array da cui prendere i dati relativi ai tour operator
*
* @return La posizione dell'ultimo tour operator in memoria
*/
int stampaTourOperator(DATI_TOUR_OPERATOR t[]);

/**
* Questa funzione legge tutti i dati relativi alle compagnie aeree e li stampa su schermo
*
* @param[in] c[] Array da cui prendere i dati relativi alle compagnie aeree
*
* @return La posizione dell'ultima comapagnia aerea in memoria
*/

int stampaCompagnieAeree(DATI_COMPAGNIA_AEREA c[]);

/**
 * Questa funzione stampa i dati dei pacchetti viaggio che soddisfano i filtri di una ricerca.
 *
 * @param[in] indiciPacchetti[] Array che contiene la posizione dei pacchetti che soddisfano i filtri di una ricerca
 * @param[in] numIndici Numero di pacchetti che soddisfano una ricerca
 * @param[in] p[] Array che contiene tutti i pacchetti viaggio presenti in memoria
 * @param[in] d[] Array da cui prendere i dati relativi alle destinazioni
 * @param[in] c[] Array da cui prendere i dati relativi alle compagnie aeree
 * @param[in] t[] Array da cui prendere i dati relativi ai tour operator
 * @param[in] h[] Array da cui prendere i dati relativi agli hotel
 */
void stampaPacchettiCercati(int indiciPacchetti[], int numIndici, DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_COMPAGNIA_AEREA c[], DATI_TOUR_OPERATOR t[], DATI_HOTEL h[]);
