/**
 *  @file eliminaDatiOperator.h
 *
 * Questo header file contiene tutte le funzioni relative all'eliminazione di un tour operator,
 * comprese le funzioni per l'aggiornamento dei pacchetti viaggio inseguito all'eliminazione di un tour operator.
 *
 * @version 0.1
 * @authors Angelo Putignano, Roberto Modarelli
 */

/**
 * Questa funzione serve a indicare se puo' essere eliminato o meno un tour operator.
 *
 * @param[in] t[] Array che contiene i dati dei tour operator.
 *
 * @return 1 se si puo' ancora eliminare un tour operator
 * @return 0 se non si possono piu' eliminare tour operator.
 */
int controlloRimozioneOperator(DATI_TOUR_OPERATOR t[]);

/**
 * Questa funzione elimina un tour operator dalla memoria.
 *
 * @param[in] indiceOperator E' l'id dei tour operator da eliminare
 * @param[in] t[] Array che contiene tutti i tour operator
 * @param[in] p[] Array che contiene i pacchetti viaggio, serve per aggiornarli dopo l'eliminazione della tour operator
 * @param [in] indiceMassimo Contiene la posizione dell'ultimo tour operator presente in memoria.
 *
 * @return 1 se il primo e l'ultimo campo del tour operator da eliminare si trovano a valori di default, 0 altrimenti
 */
int eliminaTourOperator(int indiceOperator, DATI_TOUR_OPERATOR t[], DATI_PACCHETTO_VIAGGIO p[], int indiceMassimo);

/**
 * Questa funzione riordina i tour operator e il loro id dopo l'eliminazione di uno di essi.
 *
 * @param[in] indice E' l'id della tour operator che e' stato eliminato
 * @param[in] t[] Array che contiene tutti i tour operator
 *
 * @return la nuova posizione del tour operator eliminato
 */
int riordinaTourOperator(int indice, DATI_TOUR_OPERATOR t[]);

/**
 * Questa funzione aggiorna i pacchetti viaggio presenti in memoria inseguito all'eliminazione di un tour operator
 * @param[in] indiceOperator E' l'id del tour operator che e' stato eliminato.
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria.
 */
void aggiornaPacchettiDaOperator(int indiceOperator, DATI_PACCHETTO_VIAGGIO p[]);

/**
 * Questa funzione elimina un pacchetto viaggio in seguito alla rimozione di un tour operator.
 * @param[in] posPacchetto E' la posizione nel relativo array del pacchetto viaggio da eliminare.
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria
 * @param[in] indiceOperator L'id della tour operator che e' stato eliminato
 *
 * @return 1 se il primo e l'ultimo campo del pacchetto viaggio da eliminare si trovano a valori di default, 0 altrimenti
 */
int eliminaPacchettoDaOperator(int posPacchetto, DATI_PACCHETTO_VIAGGIO p[], int indiceOperator);


/**
 * Funzione che raggruppa tutte le istruzioni necessarie ad effettuare la rimozione di un tour operator.
 * @param[in] indiceMassimo  Posizione dell'ultimo tour operator caricato in memoria nel relativo array
 * @param[in] t[] Array che contiene i tour operator presenti in memoria
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria
 */
void effettuaRimozioneOperator(int indiceMassimo, DATI_TOUR_OPERATOR t[], DATI_PACCHETTO_VIAGGIO p[]);
