/**
* @file letturaFile.h
*
* Questo header file contiene i prototipi delle funzioni che gestiscono la lettura dei dati dal file per memorizzarli in memoria
*
* @version 0.1
* @authors Angelo Putignano, Roberto Modarelli
* @warning un uso scorretto di queste funzioni puo' provocare il crash dell'intero programma, o il completo malfunzionamento di quest'ultimo dovuto a dati non corretti presenti sul file
*/


/**
* Questa funzione legge dall'apposito file binario tutti i dati relativi agli hotel e li memorizza nel relativo array.
*
* @param[in] h[] Array su cui verranno memorizzati i dati
*
* @return 0 in caso di errore nell'apertura del file
* @return 1 se tutti i dati sono stati letti con successo
* @bug se si modifica il file 'hotel.dat' dall'esterno le varie fread potrebbero andare in crash
*/
int letturaHotel(DATI_HOTEL h[]);

/**
* Questa funzione legge dall'apposito file binario tutti i dati relativi alle compagnie aeree e li memorizza nel relativo array.
*
* @param[in] c[] Array su cui verranno memorizzati i dati delle compagnie aeree
*
* @return 0 in caso di errore nell'apertura del file
* @return 1 se tutti i dati sono stati letti con successo
* @bug se si modifica il file 'compagnieAeree.dat' dall'esterno le varie fread potrebbero andare in crash
*/
int letturaCompagnieAeree(DATI_COMPAGNIA_AEREA c[]);

/**
* Questa funzione legge dall'apposito file binario tutti i dati relativi alle ore di volo tra le varie citta' e li memorizza nel relativo array.
*
* @param[in] v[] Array su cui verranno memorizzati gli orari dei voli
*
* @return 0 in caso di errore nell'apertura del file
* @return 1 se tutti i dati sono stati letti con successo
* @bug se si modifica il file 'orariVoli.dat' dall'esterno le varie fread potrebbero andare in crash
*/
int letturaOrariVoli(DATI_ORARIO_VOLO v[]);

/**
* Questa funzione legge dall'apposito file binario tutti i dati relativi alle citta' e li memorizza nel relativo array.
*
* @param[in] d[] Array su cui verranno memorizzati i dati delle destinazioni
*
* @return 0 in caso di errore nell'apertura del file
* @return 1 se tutti i dati sono stati letti con successo
* @bug se si modifica il file 'destinazioni.dat' dall'esterno le varie fread potrebbero andare in crash
*/
int letturaDestinazioni(DATI_DESTINAZIONE d[]);

/**
* Questa funzione legge dall'apposito file binario tutti i dati relativi ai tour operator e li memorizza nel relativo array.
*
* @param[in] t[] Array su cui verranno memorizzati i dati dei tour operator
*
* @return 0 in caso di errore nell'apertura del file
* @return 1 se tutti i dati sono stati letti con successo
* @bug se si modifica il file 'tourOperator.dat' dall'esterno le varie fread potrebbero andare in crash
*/
int letturaTourOperator(DATI_TOUR_OPERATOR t[]);

/**
* Questa funzione legge dall'apposito file binario tutti i dati relativi ai pacchetti viaggio e li memorizza nel relativo array.
*
* @param[in] p[] Array su cui verranno memorizzati i dati dei pacchetti viaggio
*
* @return 0 in caso di errore nell'apertura del file
* @return 1 se tutti i dati sono stati letti con successo
* @bug se si modifica il file 'pacchettiViaggio.dat' dall'esterno le varie fread potrebbero andare in crash
*/
int letturaPacchettiViaggio(DATI_PACCHETTO_VIAGGIO p[]);
