/**
 *  @file eliminaDatiCompagnie.h
 *
 * Questo header file contiene tutte le funzioni relative all'eliminazione di una compagnia aerea,
 * comprese le funzioni per l'aggiornamento dei pacchetti viaggio inseguito all'eliminazione delle compagnie aeree.
 *
 * @version 0.1
 * @authors Angelo Putignano, Roberto Modarelli
 */

/**
 * Questa funzione serve a indicare se puo' essere eliminata o meno una compagnia aerea.
 *
 * @param[in] c[] Array che contiene i dati delle compagnie aeree
 *
 * @return 1 se si puo' ancora eliminare un hotel
 * @return 0 se non si possono piu' eliminare hotel.
 */
int controlloRimozioneCompagnie(DATI_COMPAGNIA_AEREA c[]);

/**
 * Questa funzione elimina una compagnia aerea dalla memoria.
 * @param[in] indiceCompagnia E' l'id della compagnia aerea da eliminare
 * @param[in] c[] Array che contiene tutte le compagnie aeree
 * @param[in] p[] Array che contiene i pacchetti viaggio, serve per aggiornarli dopo l'eliminazione della compagnia aerea
 * @param[in] indiceMassimo Contiene la posizione dell'ultima compagnia aerea presente in memoria.
 *
 * @return 1 se il primo e l'ultimo campo della compagnia aerea da eliminare si trovano a valori di default, 0 altrimenti
 */
int eliminaCompagnia(int indiceCompagnia, DATI_COMPAGNIA_AEREA c[], DATI_PACCHETTO_VIAGGIO p[], int indiceMassimo);

/**
 * Questa funzione riordina le compagnie aeree e i loro id dopo l'eliminazione di una di esse.
 * @param[in] indice E' l'id della compagnia aerea che e' stata eliminata
 * @param[in] c[] Array che contiene tutte le compagnie aeree
 *
 * @return la nuova posizione della compagnia aerea eliminata
 */
int  riordinaCompagnieAeree(int indice, DATI_COMPAGNIA_AEREA c[]);

/**
 * Questa funzione aggiorna i pacchetti viaggio presenti in memoria inseguito all'eliminazione di una compagnia aerea
 * @param[in] indiceCompagnia E' l'id della compagnia aerea che e' stata eliminata.
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria.
 */
void aggiornaPacchettiDaCompagnia(int indiceCompagnia, DATI_PACCHETTO_VIAGGIO p[]);

/**
 * Questa funzione elimina un pacchetto viaggio in seguito alla rimozione di una compagnia aerea.
 * @param[in] posPacchetto E' la posizione nel relativo array del pacchetto viaggio da eliminare.
 * @param[in] p[] Array che contiene i pacchetti viaggio presenti in memoria
 * @param[in] indiceCompagnia L'id della compagnia che e' stata eliminata
 *
 * @return 1 se il primo e l'ultimo campo del pacchetto viaggio da eliminare si trovano a valori di default, 0 altrimenti
 */
int eliminaPacchettoDaCompagnia(int posPacchetto, DATI_PACCHETTO_VIAGGIO p[], int indiceCompagnia);


/**
 * Questa funzione raggruppa tutte le istruzioni necessarie ad effettuare la rimozione di una compagnia aerea.
 * @param[in] indiceMassimo Posizione dell'ultima compagnia aerea presente in memoria
 * @param[in] c[] Array che contiene tutti i dati delle compagnie aeree
 * @param[in] p[] Array che contiene tutti i pacchetti viaggio presenti in memoria
 */
void effettuaRimozioneCompagnia(int indiceMassimo, DATI_COMPAGNIA_AEREA c[], DATI_PACCHETTO_VIAGGIO p[]);
