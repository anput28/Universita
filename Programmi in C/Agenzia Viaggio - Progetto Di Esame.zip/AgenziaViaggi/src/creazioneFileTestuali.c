#include <stdio.h>
#include "struttureDati.h"
#include "costanti.h"
#include "creazioneFileTestuali.h"
#include "controlloInput.h"
#include "stampaMenu.h"

/**
* La funzione scrive tutti i dati contenuti nel parametro h[] nel file 'hotel.csv'.
* Un for itera un numero di volte pari al numero massimo di hotel memorizzabili nel programma e ad ogni ciclo
* scrive i dati contenuti in h nel file .csv, finche' non viene incontrato un idHotel uguale a 0 (che indica che
* da quel punto in poi l'array h contiene solo dati di default e quindi i dati degli hotel sono finiti).
*
* @pre l'array h[] deve contenere tutti i dati che si trovano sul file 'hotel.dat'.
* @post la funzione ritorna 0 quando il file 'hotel.csv' non viene aperto correttamente oppure 1 quando tutti i dati vengono scritti con successo sul file .csv.
*/
int creazioneHotelTestuale(DATI_HOTEL h[], DATI_DESTINAZIONE d[]){
	FILE *ptrHotel;
	int i;
	if((ptrHotel = fopen("fileTestuali/hotel.csv", "w")) == NULL){
		puts("ERRORE!!! Impossibile creare il file 'hotel.csv'.");
		return 0;
	}else{
		fprintf(ptrHotel, "%s, %s, %s, %s, %s, %s, %s, %s\n", "id Hotel", "Nome", "Stelle", "Prezzo(�)",
				"Stanze totali", "Stanze libere", "Sconto Minori", "Citta'");
		for(i = 0; i < MAX_NUM_HOTEL; i++){
			if(h[i].idHotel != 0){
				fprintf(ptrHotel, "%d, ", h[i].idHotel);
				fprintf(ptrHotel, "%s, ", h[i].nomeHotel);
				fprintf(ptrHotel, "%d, ", h[i].stelleHotel);
				fprintf(ptrHotel, "%d, ", h[i].prezzoHotel);
				fprintf(ptrHotel, "%d, ", h[i].stanzeTotaliHotel);
				fprintf(ptrHotel, "%d, ", h[i].stanzeLibereHotel);
				fprintf(ptrHotel, "%d%%, ", h[i].scontoMinoriHotel); //%% serve per stampare il simbolo '%'
				/*uso h[i].idCittaHotel come indice dell'array per accedere alla
				 * posizione dell'array in cui si trova la citt� in cui � situato l'hotel.
				 * Sottraggo 1 perch� gli id delle citt� partono da 1 per� gli array iniziano da 0,
				 * per esempio ROMA ha come id 1 ma si trova all'indice 0 dell'array d[].
				 */
				fprintf(ptrHotel, "%s\n", d[(h[i].idCittaHotel)-1].cittaDestinazione);
			}
		}
	}
	fclose(ptrHotel);

	return 1;
}

/**
* La funzione scrive tutti i dati relativi ai pacchetti viaggio nel file 'pacchettiViaggio.csv'.
* Un for itera un numero di volte pari al massimo numero di pacchetti viaggio memorizzabili nel programma
* e ad ogni ciclo scrive i dati relativi ai pacchetti viaggio nel file .csv. Il vettore p[] contiene elementi che rappresentano
* indici (che partono da 1) e quindi ogni elemento di p sottratto di 1 (perche' gli array partono da 0 mentre gli
* indici contenuti in p partono da 1) viene usato come indice per l'array relativo al dato da scrivere che contiene il
* dato vero e proprio.
* Il for continua a iterare finche' non viene incontrato un idPartenzaPacchetto uguale a 0 (che indica che
* da quel punto in poi l'array p contiene solo dati di default e quindi i dati dei pacchetti viaggio sono finiti).
*
* @pre l'array p[] deve contenere tutti i dati che si trovano sul file 'pacchettiViaggio.dat'.
* @post la funzione ritorna 0 quando il file 'pacchettiViaggio.csv' non viene aperto correttamente oppure 1 quando tutti i dati vengono scritti con successo sul file .csv.
*/
int creazionePacchettiViaggioTestuale(DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_COMPAGNIA_AEREA c[], DATI_TOUR_OPERATOR t[], DATI_HOTEL h[]) {
	FILE *ptrPacchetti;
	int i;
	if((ptrPacchetti = fopen("fileTestuali/pacchettiViaggio.csv", "w")) == NULL){
		puts("ERRORE!!! Impossibile creare il file 'pacchettiViaggio.csv'.");
		return 0;
	}else{
		fprintf(ptrPacchetti, "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s\n", "Partenza", "Arrivo",
				"Ore di viaggio", "Minuti di viaggio","Compagnia Aerea", "Categoria Volo",
				"Giorni", "Hotel", "Tour Operator", "Sconto Pacchetto", "Costo Totale(�)");
		for(i = 0; i < MAX_NUM_PACCHETTI; i++){
			if(p[i].idPartenzaPacchetto != 0){
				fprintf(ptrPacchetti, "%s, ", d[(p[i].idPartenzaPacchetto)-1].cittaDestinazione);
				fprintf(ptrPacchetti, "%s, ", d[(p[i].idArrivoPacchetto)-1].cittaDestinazione);
				fprintf(ptrPacchetti, "%d, ", p[i].oreViaggioPacchetto);
				fprintf(ptrPacchetti, "%d, ", p[i].minutiViaggioPacchetto);
				fprintf(ptrPacchetti, "%s, ", c[(p[i].idCompagniaAereaPacchetto)-1].nomeCompagnia);
				/*economy e business in p sono memorizzati rispettivamente nella forma 1 e 2
				 * quindi questo controllo serve a stampare in modo esplicito la categoria di volo
				 */
				if(p[i].categoriaVoloPacchetto == 1){
					fprintf(ptrPacchetti, "%s, ", "Economy");
				}else{
					fprintf(ptrPacchetti, "%s, ", "Business");
				}
				fprintf(ptrPacchetti, "%d, ", p[i].giorniPacchetto);
				fprintf(ptrPacchetti, "%s, ", h[(p[i].idHotelPacchetto)-1].nomeHotel);
				fprintf(ptrPacchetti, "%s, ", t[(p[i].idTourOperatorPacchetto)-1].nomeTourOperator);
				fprintf(ptrPacchetti, "%d%%, ", p[i].scontoPacchetto);
				fprintf(ptrPacchetti, "%d\n", p[i].costoTotalePacchetto);
			}
		}
	}
	fclose(ptrPacchetti);

	return 1;
}


/**
*  Questa funzione scrive sul file 'destinazioni.csv' i dati delle citta' presenti in memoria.
* Un for itera un numero di volte pari al numero di destinazioni presenti nel programma e ad ogni ciclo
* scrive i dati contenuti in d nel file .csv.
*
*
* @pre l'array d[] deve contenere tutti i dati che si trovano sul file 'destinazioni.dat'.
* @post la funzione ritorna 0 quando il file 'destinazioni.csv' non viene aperto correttamente oppure 1 quando tutti i dati vengono scritti con successo sul file .csv.
*/
int creazioneDestinazioniTestuale(DATI_DESTINAZIONE d[]){
	FILE *ptrDestinazione;
	int i;
	if((ptrDestinazione = fopen("fileTestuali/destinazioni.csv", "w")) == NULL){
		puts("ERRORE!!! Impossibile creare il file 'destinazioni.csv'.");
		return 0;
	}else{
		fprintf(ptrDestinazione, "%s, %s, %s\n", "idDestinazione", "Citta'", "Nazione");
		for(i = 0; i < NUM_DESTINAZIONI; i++){
			fprintf(ptrDestinazione, "%d, ", d[i].idCittaDestinazione);
			fprintf(ptrDestinazione, "%s, ", d[i].cittaDestinazione);
			fprintf(ptrDestinazione, "%s\n", d[i].nazioneDestinazione);
		}
	}
	fclose(ptrDestinazione);

	return 1;
}

/**
* La funzione scrive tutti i dati contenuti nel parametro c[] nel file 'comapagnieAeree.csv'.
* Un for itera un numero di volte pari al numero massimo di compagnie aeree memorizzabili nel
* programma e ad ogni ciclo scrive i dati contenuti in c nel file .csv, finche' non viene incontrato
* un idCompagnia uguale a 0 (che indica che da quel punto in poi il vettore c contiene solo dati di
* default e quindi i dati delle compagnie aeree sono finiti).
*
*
* @pre l'array c[] deve contenere tutti i dati che si trovano sul file 'compagnieAeree.dat'.
* @post la funzione ritorna 0 quando il file 'compagnieAeree.csv' non viene aperto correttamente oppure 1 quando tutti i dati vengono scritti con successo sul file .csv.
*/
int creazioneCompagnieTestuale(DATI_COMPAGNIA_AEREA c[]){
	FILE *ptrCompagnia;
	int i;
	if((ptrCompagnia = fopen("fileTestuali/compagnieAeree.csv", "w")) == NULL){
		puts("ERRORE!!! Impossibile creare il file 'compagnieAeree.csv'.");
		return 0;
	}else{
		fprintf(ptrCompagnia, "%s, %s, %s, %s\n", "idCompagniaAerea", "Nome", "Nazione", "Prezzo per ora di volo");
		for(i = 0; i < MAX_NUM_COMPAGNIE; i++){
			if(c[i].idCompagnia != 0){
				fprintf(ptrCompagnia, "%d, ", c[i].idCompagnia);
				fprintf(ptrCompagnia, "%s, ", c[i].nomeCompagnia);
				fprintf(ptrCompagnia, "%s, ", c[i].nazioneCompagnia);
				fprintf(ptrCompagnia, "%.2f\n", c[i].prezzoOrarioCompagnia);
			}
		}
	}
	fclose(ptrCompagnia);

	return 1;
}

/**
* La funzione scrive tutti i dati contenuti nel parametro t[] nel file 'comapagnieAeree.csv'.
* Un for itera un numero di volte pari al numero massimo di tour operator memorizzabili nel
* programma e ad ogni ciclo scrive i dati contenuti in t nel file .csv, finche' non viene incontrato
* un idTourOperator uguale a 0 (che indica che da quel punto in poi il vettore d contiene solo dati di
* default e quindi i dati dei tour operator sono finiti).
*
*
* @pre l'array t[] deve contenere tutti i dati che si trovano sul file 'tourOperator.dat'.
* @post la funzione ritorna 0 quando il file 'tourOperator.csv' non viene aperto correttamente oppure 1 quando tutti i dati vengono scritti con successo sul file .csv.
*/
int creazioneTourOperatorTestuale(DATI_TOUR_OPERATOR t[]){
	FILE *ptrTourOperator;
	int i;
	if((ptrTourOperator = fopen("fileTestuali/tourOperator.csv", "w")) == NULL){
		puts("ERRORE!!! Impossibile creare il file 'tourOperator.csv'.");
		return 0;
	}else{
		fprintf(ptrTourOperator, "%s, %s, %s, %s\n", "idTourOperator", "Nome", "Citta'", "Nazione");
		for(i = 0; i < MAX_NUM_TOUR_OPERATOR; i++){
			if(t[i].idTourOperator != 0){
				fprintf(ptrTourOperator, "%d, ", t[i].idTourOperator);
				fprintf(ptrTourOperator, "%s, ", t[i].nomeTourOperator);
				fprintf(ptrTourOperator, "%s, ", t[i].cittaTourOperator);
				fprintf(ptrTourOperator, "%s\n", t[i].nazioneTourOperator);
			}
		}
	}
	fclose(ptrTourOperator);

	return 1;
}

/**
 * Questa funzione raggruppa tutte le istruzioni per gestire la creazione dei file testuali.
 * Viene stampato un menu con i possibili file testuali che si possono creare, viene fatta inserire la scelta e in base a questa
 * viene chiamata la funzione che si occupa di creare il file testuale.
 * Viene fatta inserire la scelta finche' non si sceglie di uscire definitivamente dal programma.
 *
 * @post La funzione ritorna il valore di flag, che indica se e' stato creato almeno un file testuale (1) o meno (0)
 */
int gestisciCreazioneFileTestuali(DATI_DESTINAZIONE d[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[], DATI_PACCHETTO_VIAGGIO p[]){
	int flag;
	int scelta;
	do{
		menuFileTestuali();
		scelta = inserisciScelta(NUM_MIN_MENU_FILE_TESTUALI,NUM_MAX_MENU_FILE_TESTUALI, 2);

		switch(scelta){
			case 1:
				creazioneDestinazioniTestuale(d);
				puts("\nIl file 'destinazioni.csv' e' stato creato nella cartella 'fileTestuali'.");
				flag = 1;
				break;
			case 2:
				creazioneHotelTestuale(h, d);
				puts("\nIl file 'hotel.csv' e' stato creato nella cartella 'fileTestuali'.");
				flag = 1;
				break;
			case 3:
				creazioneCompagnieTestuale(c);
				puts("\nIl file 'compagnieAeree.csv' e' stato creato nella cartella 'fileTestuali'.");
				flag = 1;
				break;
			case 4:
				creazioneTourOperatorTestuale(t);
				puts("\nIl file 'tourOperator.csv' e' stato creato nella cartella 'fileTestuali'.");
				flag = 1;
				break;
			case 5:
				creazionePacchettiViaggioTestuale(p, d, c, t, h);
				puts("\nIl file 'pacchettiViaggio.csv' e' stato creato nella cartella 'fileTestuali'.");
				flag = 1;
				break;
		}

	}while(scelta != NUM_MAX_MENU_FILE_TESTUALI);

	return flag;
}
