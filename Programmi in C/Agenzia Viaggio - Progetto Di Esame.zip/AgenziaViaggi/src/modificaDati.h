/**
* @file modificaDati.h
*
* Questo header file contiene i prototipi delle funzioni per la modifica dei dati di hotel, compagnie aeree e tour operator.
*
* @version 0.1
* @authors Angelo Putignano, Roberto Modarelli
*/

/**
 * Questa funzione permette di modificare i dati di un hotel.
 * @param[in] scelta E' la scelta del dato dell'hotel che si vuole modificare.
 * @param[in] h L'hotel scelto per essere modificato.
 * @param[in] d[] Array che contiene tutte le destinazioni presenti in memoria.
 *
 * @return Un elemento di tipo DATI_HOTEL con le modifiche effettuate e gli eventuali dati non modificati.
 */
DATI_HOTEL modificaHotel(int scelta, DATI_HOTEL h, DATI_DESTINAZIONE d[]);

/**
 * Questa funzione permette di modificare i dati di un tour operator.
 * @param[in] scelta E' la scelta del dato del tour operator che si vuole modificare.
 * @param[in] t Il tour operator scelto per essere modificato.
 *
 * @return Un elemento di tipo DATI_TOUR_OPERATOR con le modifiche effettuate e gli eventuali dati non modificati.
 */
DATI_TOUR_OPERATOR modificaTourOperator(int scelta, DATI_TOUR_OPERATOR t);

/**
 * Questa funzione permette di modificare i dati di una compagnia aerea.
 * @param[in] scelta E' la scelta del dato della compagnia aerea che si vuole modificare.
 * @param[in] c La compagnia aerea scelta per essere modificata.
 *
 * @return Un elemento di tipo DATI_COMPAGNIA_AEREA con le modifiche effettuate e gli eventuali dati non modificati.
 */
DATI_COMPAGNIA_AEREA modificaCompagniaAerea(int scelta, DATI_COMPAGNIA_AEREA c);

/**
 * Questa funzione controlla se esiste gia' un hotel con i dati nuovi inseriti/modificati.
 *
 * @param[in] h[] Array che contiene i dati di tutti gli hotel presenti in memoria
 * @param[in] hotelInserito Contiene i dati dell'hotel inserito dall'utente
 * @param[in] d[] Array che contiene i dati delle citta' presenti in memoria, serve per stampare il nome della citta' nel messaggio di errore.
 *
 * @return 1 se l'hotel non e' gia' presente in memoria
 * @return 0 se l'hotel e' gia' presente in memoria
 */
int controlloPresenzaHotel(DATI_HOTEL h[], DATI_HOTEL hotelInserito, DATI_DESTINAZIONE d[]);

/**
 * Questa funzione controlla se esiste gia' una compagnia aerea con i dati nuovi inseriti/modificati.
 * @param[in] c[] Array che contiene i dati di tutte le compagnie aeree gia' presenti in memoria.
 * @param[in] compagniaInserita Contiene i dati della compagnia aerea inserita dall'utente.
 *
 * @return 1 se la compagnia aerea non e' gia' presente in memoria
 * @return 0 se la compagnia aerea e' gia' presente in memoria
 */
int controlloPresenzaCompagnia(DATI_COMPAGNIA_AEREA c[], DATI_COMPAGNIA_AEREA compagniaInserita);

/**
 * Questa funzione controlla se esiste gia' un tour operator con i dati nuovi inseriti/modificati.
 * @param[in] t[] Array che contiene i dati di tutti i tour operator gia' presenti in memoria.
 * @param[in] tourOperatorInserito Contiene i dati del tour operator inserita dall'utente.
 *
 * @return 1 se il tour operator non e' gia' presente in memoria
 * @return 0 se il tour operator e' gia' presente in memoria
 */
int controlloPresenzaTourOperator(DATI_TOUR_OPERATOR t[], DATI_TOUR_OPERATOR tourOperatorInserito);

/**
 * Funzione che raggruppa tutte le istruzioni necessarie a effettuare una modifica di un hotel
 *
 * @param[in] indiceMassimo Contiene la posizione dell'ultimo hotel presente in memoria
 * @param[in] h[] Array che contiene tutti i dati degli hotel
 * @param[in] d[] Array che contiene tutte le possibili destinazioni
 * @param[in] p[] Array che contiene tutti i dati dei pacchetti viaggi
 * @param[in] c[] Array che contiene tutti i dati delle compagnie aeree
 *
 */
void effettuaModificaHotel(int indiceMassimo, DATI_HOTEL h[], DATI_DESTINAZIONE d[], DATI_PACCHETTO_VIAGGIO p[],  DATI_COMPAGNIA_AEREA c[]);

/**
 * Funzione che raggruppa tutte le istruzioni necessarie a effettuare una modifica di un tour operator
 *
 * @param[in] indiceMassimo Contiene la posizione dell'ultimo hotel presente in memoria
 * @param[in] t[] Array che contiene tutti i dati dei tour operator
 *
 */
void effettuaModificaOperator(int indiceMassimo, DATI_TOUR_OPERATOR t[]);


/**
 * Funzione che raggruppa tutte le istruzioni necessarie a effettuare una modifica di una compagnia aerea
 *
 * @param[in] indiceMassimo Contiene la posizione dell'ultimo hotel presente in memoria
 * @param[in] c[] Array che contiene tutti i dati delle compagnie aeree
 * @param[in] h[] Array che contiene tutti i dati degli hotel
 * @param[in] p[] Array che contiene tutti i dati dei pacchetti viaggi
 *
 */
void effettuaModificaCompagnia(int indiceMassimo, DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_PACCHETTO_VIAGGIO p[]);

/**
 * Funzione che permette di confermare la modifica/eliminazione di dati
 *
 * @param[in] azione[] Stringa che indica l'azione da compiere (modificare/cancellare).
 *
 * @return 1 se l'azione viene confermata.
 * @return 2 se l'azione non viene confermata.
 */
int confermaModifica(char azione[]);
