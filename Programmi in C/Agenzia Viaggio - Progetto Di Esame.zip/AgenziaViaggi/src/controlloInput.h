/**
* @file controlloInput.h
*
* Questo header file contiene i prototipi delle funzioni che permettono di gestire l'input da tastiera,
* di funzioni generali che possono essere usate in diversi contesti.
*
* @version 0.1
* @authors Angelo Putignano, Roberto Modarelli
*/

/**
 * Permette di inserire una scelta tra le voci dei vari menu' presenti nel programma
 *
 * @param[in] primo La scelta minima effettuabile
 * @param[in] ultimo La scelta massima effettuabile
 * @param[in] numCaratteri Il numero massimo di caratteri che possono essere inseriti da tastiera
 *
 * @return la scelta effettuata.
 */
int inserisciScelta(int primo, int ultimo, int numCaratteri);

/**
 * Questa funzione permette di inserire correttamente qualsiasi nome che deve essere utilizzato nel programa.
 *
 * @param[in] lunghezzaNome Indica la lunghezza massima che il nome puo' avere.
 * @param[in] simboliAccettati[] Array contenente i simboli che possono essere contenuti nel nome.
 * @param[in] dim Dimensione dell'array che contiene i simboli
 * @param[in] categoria E' una stringa che indica a chi e' riferito il nome (hotel, compagnia aerea, ecc.).
 * @param[in] minLettere Indica il numero minimo di lettere ammesse nel nome.
 * @param[in] maxSimboli Indica il numero massimo di simboli ammessi nel nome.
 * @param[in] maxNumeri Indica il numero massimo di numeri ammessi nel nome.
 *
 * @return la scelta effettuata.
 */
char* inserireNome(int lunghezzaNome, char simboliAccettati[], int dim, char categoria[], int minLettere, int maxSimboli, int maxNumeri);

/**
 * Questa funzione permette di controllare se un certo carattere (passato come parametro) e' presente tra i simboli presenti in un certo array.
 *
 * @param[in] simboli[] Array che contiene tutti i simboli da confrontare col carattere
 * @param[in] dimensione La dimensione dell'array 'simboli'
 * @param[in] carattere Il carattere che bisogna confrontare con i vari simboli
 *
 * @return 1 se 'carattere' e' presente in 'simboli'
 * @return 0 se 'carattere' non e' presente in 'simboli'
 */
int controlloSimboli(char simboli[], int dimensione, char carattere);


/**
 * Questa funzione permette di inserire correttamente il nome di un paese (citta' o nazione) da tastiera.
 *
 * @param[in] lunghezzaNome Indica la lunghezza massima che il nome del paese puo' avere.
 * @param[in] tipoPaese[] E' la stringa (CITTA' o NAZIONE) che verra' stampata al momento dell'input.
 * @param[in] categoria[] E' una stringa che indica a chi e' riferito il nome (hotel, compagnia aerea, ecc.).
 * @param[in] minLettere Indica il numero minimo di lettere ammesse nel nome del paese.
 *
 * @return Il nome del paese inserito
 */
char* inserirePaese(int lunghezzaNome, char categoria[], char tipoPaese[], int minLettere);

/**
 * Questa funzione permette di inserire il prezzo orario di una compagnia aerea.
 * @param[in] minPrezzo Il prezzo orario minimo che puo' avere una compagnia aerea.
 * @param[in] maxPrezzo Il prezzo orario massimo che puo' avere uan compagnia aerea.
 *
 * @return Il prezzo inserito
 */
float inserirePrezzoCompagnia(float minPrezzo, float maxPrezzo);

/**
 * Questa controlla se il numero di valori decimali inseriti in una stringa (un numero sottoforma di stringa) sia uguale ad
 * un numero che ci si aspetta (il parametro 'decimali').
 *
 * @param[in] numero[] Array che contiene il numero di cui si volgiono controllare le cifre decimali, in stringa.
 * @param[in] dimensione La dimensione dell'array 'numero'.
 * @param[in] decimali E' il numero di cifre decimali che il parametro 'numero' dovrebbe avere.
 *
 * @return 1 se il numero di cifre decimali di 'numero' coincide con il valore di 'decimali'.
 * @return 0 se il numero di cifre decimali di 'numero' e' diverso dal valore di 'decimali'.
 */
int verificaDecimaliDaStringa(char numero[], int dimensione, int decimali);
