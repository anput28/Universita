#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "costanti.h"
#include "struttureDati.h"
#include "modificaDati.h"
#include "controlloInput.h"
#include "controlloInputHotel.h"
#include "controlloInputPacchetto.h"
#include "aggiungiDati.h"
#include "modificaDatiPacchetto.h"
#include "eliminaDatiHotel.h"
#include "stampaMenu.h"
#include "stampaDati.h"


/**
 * Questa funzione permette di modificare i dati di un hotel.
 * La funzione prende in input tutti i dati dell'hotel che si vuole modificare, e anche
 * la scelta del dato che si vuole modificare. I diversi casi vengono gestiti tramite una switch,
 * in cui in base alla scelta del dato da modificare richiama le apposite funzioni per effettuare
 * la modifica.
 * Si puo' scegliere anche di modificare tutti i dati dell'hotel (caso 8 della switch), in questo caso
 * viene chiamata la funzione aggiungiHotel che permette di modificare tutti i dati dell'hotel scelto.
 *
 * @post La funzione ritorna un elemento di tipo DATI_HOTEL con le modifiche effettuate e gli eventuali dati non modificati.
 */
DATI_HOTEL modificaHotel(int scelta, DATI_HOTEL h, DATI_DESTINAZIONE d[]){

	//i dati dell'hotel scelto epr essere modificato vengono copiati in un altra variabile
	DATI_HOTEL hotelDaModificare = h;

	switch(scelta){
	 	case 1:

	 		printf("\nModificare il nome [attuale: %s]\n", h.nomeHotel);
	 		strcpy(hotelDaModificare.nomeHotel, inserireNome(LUNGH_NOME_HOTEL, simboliHotel , NUM_SIMBOLI_HOTEL ,"hotel", NUM_MIN_LETTERE_HOTEL, NUM_MAX_SIMBOLI_HOTEL, NUM_MAX_NUMERI_HOTEL));

	 		break;

	 	case 2:
	 		printf("\nModificare le stelle [attuale: %d]\n", h.stelleHotel);
	 		hotelDaModificare.stelleHotel = inserireStelle(MIN_NUM_STELLE, MAX_NUM_STELLE);

	 		break;

	 	case 3:
	 		printf("\nModifica prezzo [attuale: %d]\n", h.prezzoHotel);
	 		hotelDaModificare.prezzoHotel = inserirePrezzoHotel(h.prezzoHotel);
	 		break;

	 	case 4:
	 		printf("\nModifica stanza totali [attuale: %d]", h.stanzeTotaliHotel);
	 		hotelDaModificare.stanzeTotaliHotel = inserireStanzeTotali(MIN_STANZE_TOTALI, MAX_STANZE_TOTALI);
	 		/*le stanze totali modificate devono essere di pi� delle attuali stanze libere dell'hotel
	 		 *se non � cos� vengono fatte reinserire.
	 		 */
	 		while(hotelDaModificare.stanzeTotaliHotel <= h.stanzeLibereHotel){
	 			printf("\nATTENZIONE!!! Inserire il numero di stanze totali maggiore a quello delle stanze libere\n");
	 			hotelDaModificare.stanzeTotaliHotel = inserireStanzeTotali(MIN_STANZE_TOTALI, MAX_STANZE_TOTALI);
	 		}

	 		break;

	 	case 5:
	 		printf("\nModifica stanza libere [attuale: %d stanze]\n", h.stanzeLibereHotel);
	 		hotelDaModificare.stanzeLibereHotel = inserireStanzeLibere(h.stanzeTotaliHotel);

	 		break;

	 	case 6:
	 		printf("\nModifica sconto minori [attuale: %d stanze]\n", h.scontoMinoriHotel);
	 		hotelDaModificare.scontoMinoriHotel = inserireScontoHotel(MAX_SCONTO_HOTEL);

	 		break;

	 	case 7:
	 		printf("\nModifica citta [attuale: %s]\n", d[h.idCittaHotel-1].cittaDestinazione);
	 		hotelDaModificare.idCittaHotel = inserireIdCittaHotel(d);

	 		break;

	 	case 8:
	 		printf("\nModifica di tutti i dati dell'hotel selezionato\n");
	 		hotelDaModificare = aggiungiHotel(d, hotelDaModificare.idCittaHotel-1);

	 		break;
	}

	return hotelDaModificare;
}


/**
 * Questa funzione permette di modificare i dati di un tour operator.
 * La funzione prende in input tutti i dati del tour operator che si vuole modificare, e anche
 * la scelta del dato che si vuole modificare. I diversi casi vengono gestiti tramite una switch,
 * in cui in base alla scelta del dato da modificare richiama le apposite funzioni per effettuare
 * la modifica.
 * Si puo' scegliere anche di modificare tutti i dati del tour operator (caso 4 della switch), in questo caso
 * viene chiamata la funzione aggiungiTourOperator che permette di modificare tutti i dati del tour operator scelto.
 *
 * @post La funzione ritorna un elemento di tipo DATI_TOUR_OPERATOR con le modifiche effettuate e gli eventuali dati non modificati.
 */
DATI_TOUR_OPERATOR modificaTourOperator(int scelta, DATI_TOUR_OPERATOR t){

	DATI_TOUR_OPERATOR operatorDaModificare = t;

	switch(scelta){
	 	case 1:

	 		printf("\nModificare il nome [attuale: %s]\n", t.nomeTourOperator);
	 		strcpy(operatorDaModificare.nomeTourOperator, inserireNome(LUNGH_NOME_TOUR_OPERATOR, simboliOperator , NUM_SIMBOLI_OPERATOR ,"tour operator", NUM_MIN_LETTERE_OPERATOR, NUM_MAX_SIMBOLI_OPERATOR, NUM_MAX_NUMERI_OPERATOR));

	 		break;

	 	case 2:
	 		printf("\nModificare la citta' [attuale: %s]\n", t.cittaTourOperator);
	 		strcpy(operatorDaModificare.cittaTourOperator, inserirePaese(LUNGH_NOME_CITTA, "tour operator", "CITTA'", NUM_MIN_LETTERE_CITTA));

	 		break;

	 	case 3:
	 		printf("\nModifica la nazione [attuale: %s]\n", t.nazioneTourOperator);
	 		strcpy(operatorDaModificare.nazioneTourOperator, inserirePaese(LUNGH_NOME_NAZIONE, "tour operator", "NAZIONE", NUM_MIN_LETTERE_NAZIONE));

	 		break;

	 	case 4:
	 		printf("\nModifica di tutti i dati del tour operator selezionato\n");
	 		operatorDaModificare = aggiungiTourOperator(operatorDaModificare.idTourOperator-1);

	 		break;
	}

	return operatorDaModificare;
}

/**
 * Questa funzione permette di modificare i dati di una compagnia aerea.
 * La funzione prende in input tutti i dati della compagnia aerea che si vuole modificare, e anche
 * la scelta del dato che si vuole modificare. I diversi casi vengono gestiti tramite una switch,
 * in cui in base alla scelta del dato da modificare richiama le apposite funzioni per effettuare
 * la modifica.
 * Si puo' scegliere anche di modificare tutti i dati della compagnia aerea (caso 4 della switch), in questo caso
 * viene chiamata la funzione aggiungiCompagniaAerea che permette di modificare tutti i dati della compagnia aerea scelta.
 *
 * @post La funzione ritorna un elemento di tipo DATI_COMPAGNIA_AEREA con le modifiche effettuate e gli eventuali dati non modificati.
 */
DATI_COMPAGNIA_AEREA modificaCompagniaAerea(int scelta, DATI_COMPAGNIA_AEREA c){

	DATI_COMPAGNIA_AEREA compagniaDaModificare = c;

	switch(scelta){
	 	case 1:

	 		printf("\nModificare il nome [attuale: %s]\n", c.nomeCompagnia);
	 		strcpy(compagniaDaModificare.nomeCompagnia, inserireNome(LUNGH_NOME_COMPAGNIA, simboliCompagnia, NUM_SIMBOLI_COMPAGNIA,"compagnia aerea", NUM_MIN_LETTERE_COMPAGNIA,NUM_MAX_SIMBOLI_COMPAGNIA,NUM_MAX_NUMERI_COMPAGNIA));

	 		break;

	 	case 2:
	 		printf("\nModificare la Nazione [attuale: %s]\n", c.nazioneCompagnia);
	 		strcpy(compagniaDaModificare.nazioneCompagnia, inserirePaese(LUNGH_NOME_NAZIONE, "compagnia aerea", "NAZIONE", NUM_MIN_LETTERE_NAZIONE));

	 		break;

	 	case 3:
	 		printf("\nModifica il prezzo orario [attuale: %.2f]\n", c.prezzoOrarioCompagnia);
	 		compagniaDaModificare.prezzoOrarioCompagnia = inserirePrezzoCompagnia(MIN_PREZZO_COMPAGNIA, MAX_PREZZO_COMPAGNIA);

	 		break;

	 	case 4:
	 		printf("\nModifica di tutti i dati della compagnia aerea selezionata\n");
	 		compagniaDaModificare = aggiungiCompagnia(compagniaDaModificare.idCompagnia-1);

	 		break;
	}

	return compagniaDaModificare;
}

/**
*
* Questa funzione controlla se esiste gia' un hotel con i dati nuovi inseriti/modificati.
* Tramite un for che itera un numero di volte pari al numero massimo di hotel memorizzabili nel programma,
* controlla se il nome la citta' di provenienza, le stelle, il prezzo, le stanze totali e quelle libere
* di ciascun hotel gia' presente in memoria, coincidono con quelli inseriti dall'utente.
* Se viene trovata una corrispondenza il flag sentinella viene settato a 0.
* Alla fine del controllo se il flag e' a 0, viene stampato l'errore che l'hotel e' gia' presente in
* memoria.
*
* @post la funzione ritorna 0 se l'hotel e' gia' presente in memoria oppure 1 se non e' presente
*/
int controlloPresenzaHotel(DATI_HOTEL h[], DATI_HOTEL hotelInserito, DATI_DESTINAZIONE d[]){
	int flag = 1;
	for(int i = 0; i < MAX_NUM_HOTEL; i++){

		if(h[i].idCittaHotel == hotelInserito.idCittaHotel)
		if(strcmp(h[i].nomeHotel, hotelInserito.nomeHotel) == 0)
		if(h[i].stelleHotel == hotelInserito.stelleHotel)
		if(h[i].prezzoHotel == hotelInserito.prezzoHotel)
		if(h[i].stanzeTotaliHotel == hotelInserito.stanzeTotaliHotel)
		if(h[i].stanzeLibereHotel == hotelInserito.stanzeLibereHotel)
		if(h[i].scontoMinoriHotel == hotelInserito.scontoMinoriHotel)
			flag = 0;
	}

	if(flag == 0){
		/*d[hotelInserito.idCittaHotel-1].cittaDestinazione = il nome della citt� che si trova in posizione
		 *'hotelInserito.idCittaHotel-1' nel vettore che contiene i nomi di tutte le citt�.*/
		printf("\nERRORE!!! L'hotel '%s' nella citta' di %s e' gia' presente in memoria.\n", hotelInserito.nomeHotel, d[hotelInserito.idCittaHotel-1].cittaDestinazione);
		puts("Si prega di inserire solo nuovi dati...");
	}

	return flag;
}

/**
* Questa funzione controlla se esiste gia' una compagnia aerea con i dati nuovi inseriti/modificati.
* Tramite un for che itera un numero di volte pari al numero massimo di compagnie aeree memorizzabili
* nel programma, controlla se il nome, la nazione e il prezzo di ciascuna compagnia aerea gia' presente in memoria,
* coincidono con quelli inseriti dall'utente. Se viene trovata una corrispondenza il flag sentinella viene
* settato a 0.
* Alla fine del controllo se il flag e' a 0, viene stampato l'errore che la compagnia aerea e' gia'
* presente in memoria.
*
* @post la funzione ritorna 0 se la compagnia aerea e' gia' presente in memoria oppure 1 se non e' presente
*/
int controlloPresenzaCompagnia(DATI_COMPAGNIA_AEREA c[], DATI_COMPAGNIA_AEREA compagniaInserita){
	int flag = 1;
	for(int i = 0; i < MAX_NUM_COMPAGNIE; i++){

		if(strcmp(c[i].nomeCompagnia, compagniaInserita.nomeCompagnia) == 0)
		if(strcmp(c[i].nazioneCompagnia, compagniaInserita.nazioneCompagnia) == 0)
		if(c[i].prezzoOrarioCompagnia == compagniaInserita.prezzoOrarioCompagnia)
			flag = 0;
	}

	if(flag == 0){
		printf("\nERRORE!!! La compagnia aerea '%s' e' gia' presente in memoria.\n", compagniaInserita.nomeCompagnia);
		puts("Si prega di inserire solo nuovi dati...");
	}

	return flag;
}

/**
* Questa funzione controlla se esiste gia' un tour operator con i dati nuovi inseriti/modificati.
* Tramite un for che itera un numero di volte pari al numero massimo di tour operator memorizzabili
* nel programma, controlla se il nome, la citta' e la nazione di ciascun tour operator gia' presente in memoria,
* coincidono con quelli inseriti dall'utente. Se viene trovata una corrispondenza il flag sentinella viene
* settato a 0.
* Alla fine del controllo se il flag e' a 0, viene stampato l'errore che il tour operator e' gia'
* presente in memoria.
*
* @post la funzione ritorna 0 se il tour operator e' gia' presente in memoria oppure 1 se non e' presente
*/
int controlloPresenzaTourOperator(DATI_TOUR_OPERATOR t[], DATI_TOUR_OPERATOR tourOperatorInserito){
	int flag = 1;

	for(int i = 0; i < MAX_NUM_TOUR_OPERATOR; i++){

		if(strcmp(t[i].nomeTourOperator, tourOperatorInserito.nomeTourOperator) == 0)
		if(strcmp(t[i].cittaTourOperator, tourOperatorInserito.cittaTourOperator) == 0)
		if(strcmp(t[i].nazioneTourOperator, tourOperatorInserito.nazioneTourOperator) == 0)
			flag = 0;

	}

	return flag;
}

/**
 * Funzione che raggruppa tutte le istruzioni necessarie a effettuare una modifica di un hotel.
 *
 */
void effettuaModificaHotel(int indiceMassimo, DATI_HOTEL h[], DATI_DESTINAZIONE d[], DATI_PACCHETTO_VIAGGIO p[], DATI_COMPAGNIA_AEREA c[]){
	int flag = 0;
	int sceltaIdModifica;
	int sceltaModifica;

	puts("\nATTENZIONE!!! Modificando i dati si possono avere variazioni sui pacchetti viaggio.\n");
	sleep(3);

	indiceMassimo = stampaHotel(h, d);

	puts("\nInserire l'id dell'hotel da modificare.\n");
	sceltaIdModifica = inserisciScelta(1, indiceMassimo, 3);

	menuModificaHotel();
	puts("\nScegliere cosa modificare.\n");
	sceltaModifica = inserisciScelta(NUM_MIN_MODIFICA_HOTEL, NUM_MAX_MODIFICA_HOTEL, 2);

	DATI_HOTEL hotelTemporaneo = modificaHotel(sceltaModifica, h[sceltaIdModifica - 1], d);

	if(confermaModifica("modificare") == 1){

		//controllo che l'idCittaHotel non sia stato cambiato
		if(h[sceltaIdModifica - 1].idCittaHotel != hotelTemporaneo.idCittaHotel){
			/* Se l'idCittaHotel � stato modificato, viene controllato se quella citt� ha pi� di un hotel.
			 * Se non � cosi viene stampato un errore e quindi l'hotel non viene modificato,
			 * perch� ogni citt� deve avere almeno un hotel.
			 * Se la citt� ha pi� di un hotel, allora viene chiamata la funzione aggiornaPacchettiDaHotel
			 * che elimina il pacchetto viaggio in cui � contenuto l'idCittaHotel che � stato poi modificato.
			 */
			if(contaHotelPerCitta(h, sceltaIdModifica - 1) == 0){
				printf("\nATTENZIONE!!! Impossibile modificare hotel,"
						"ci deve essere almeno un hotel nella citta' di \"%s\"\n", d[sceltaIdModifica].cittaDestinazione);
				flag = 1;
			}else{
				aggiornaPacchettiDaHotel(sceltaIdModifica, p);
			}
		}

		if(flag == 0){
			//se il controllo sui dati del nuovo hotel va a buon fine allora i dati vengono memorizzati.
			if(controlloPresenzaHotel(h, hotelTemporaneo, d) != 0){

				h[sceltaIdModifica - 1] = hotelTemporaneo;
				/*il costo totale del pacchetto viaggio viene aggiornato solo se viene modificato il prezzo dell'hotel,
				 * cosa che pu� avvenire solo scegliendo la voce numero 3 e la voce numero 8.
				 */
				if(sceltaModifica == 3 || sceltaModifica == 8){
					aggiornaCostoDaHotel(p, c, h, sceltaIdModifica-1);
				}

				puts("\nPERFETTO!!! Hotel modificato con successo.\n");
			}else{
				printf("\nERRORE!!! L'hotel modificato e' gia' presente in memoria.\n");
			}
		}
	}


	printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");
}

/**
 * Funzione che raggruppa tutte le istruzioni necessarie a effettuare una modifica di un tour operator.
 *
 */
void effettuaModificaOperator(int indiceMassimo, DATI_TOUR_OPERATOR t[]){
	int sceltaIdModifica;
	int sceltaModifica;

	puts("\nATTENZIONE!!! Modificando i dati si possono avere variazioni sui pacchetti viaggio.\n");
	sleep(3);

	indiceMassimo = stampaTourOperator(t);

	puts("\nInserire l'id del tour operator da modificare.\n");
	sceltaIdModifica = inserisciScelta(1, indiceMassimo, 3);

	menuModificaTourOperator();
	puts("\nScegliere cosa modificare.\n");
	sceltaModifica = inserisciScelta(NUM_MIN_MODIFICA_OPERATOR, NUM_MAX_MODIFICA_OPERATOR, 2);
	DATI_TOUR_OPERATOR operatorTemporaneo = modificaTourOperator(sceltaModifica, t[sceltaIdModifica - 1]);

	if(confermaModifica("modificare") == 1){

		if(controlloPresenzaTourOperator(t, operatorTemporaneo) != 0){
			t[sceltaIdModifica - 1] = operatorTemporaneo;
			puts("\nPERFETTO!!! Tour Operator modificato con successo.\n");
		}else{
			printf("\nERRORE!!! Il tour operator modificato e' gia' presente in memoria.\n");
		}
	}
	printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");
}

/**
 * Funzione che raggruppa tutte le istruzioni necessarie a effettuare una modifica di una compagnia aerea.
 *
 */
void effettuaModificaCompagnia(int indiceMassimo, DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_PACCHETTO_VIAGGIO p[]){
	int sceltaIdModifica;
	int sceltaModifica;

	puts("\nATTENZIONE!!! Modificando i dati si possono avere variazioni sui pacchetti viaggio.\n");
	sleep(3);

	indiceMassimo = stampaCompagnieAeree(c);

	puts("\nInserire l'id della compagnia aerea da modificare.\n");
	sceltaIdModifica = inserisciScelta(1, indiceMassimo, 3);

	menuModificaCompagnieAeree();
	puts("\nScegliere cosa modificare.\n");
	sceltaModifica = inserisciScelta(NUM_MIN_MODIFICA_COMPAGNIA, NUM_MAX_MODIFICA_COMPAGNIA, 2);

	DATI_COMPAGNIA_AEREA compagniaTemporanea = modificaCompagniaAerea(sceltaModifica, c[sceltaIdModifica - 1]);

	if(confermaModifica("modificare") == 1){
		if(controlloPresenzaCompagnia(c, compagniaTemporanea) != 0){
			c[sceltaIdModifica - 1] = compagniaTemporanea;

			/*il costo totale del pacchetto viaggio viene aggiornato solo se viene modificato il prezzo della compagnia aerea,
			 * cosa che pu� avvenire solo scegliendo la voce numero 3 e la voce numero 4.
			 */
			if(sceltaModifica == 3 || sceltaModifica == 4){
				aggiornaCostoDaCompagnia(p, c, h, sceltaIdModifica-1);
			}

			puts("\nPERFETTO!!! Compagnia Aerea modificata con successo.\n");

		}else{
			printf("\nERRORE!!! La compagnia aerea modificato e' gia' presente in memoria.\n");
		}
	}

	printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");
}

/**
 * Funzione che permette di confermare la modifica/eliminazione di dati.
 *
 * @post ritorna 1 se l'azione viene confermata, 2 se l'azione non viene confermata
 */
int confermaModifica(char azione[]){
	printf("\nSei sicuro di voler %s i dati? (Premi 1 per SI e 2 per NO)\n", azione);

	return inserisciScelta(1, 2, 2);
}
