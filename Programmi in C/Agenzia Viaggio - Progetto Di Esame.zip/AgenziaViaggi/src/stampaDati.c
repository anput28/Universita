#include <stdio.h>
#include "costanti.h"
#include "struttureDati.h"
#include "stampaDati.h"



/**
* Questa funzione stampa tutti i dati relativi ai pacchetti viaggio.
* Usando gli indici presenti nel array contenente i pacchetti viaggio viene stampato il dato a
* cui si riferiscono negli altri array.
* Tramite un ciclo for, che cicla fino MAX_NUM_PACCHETTI, scorriamo gli elementi dell'array p
* e controlliamo tramite un if che l'indice del pacchetto attuale sia diverso da 0, altrimenti e' vuoto quindi e'
* inutile stamparlo.
*
* @warning Se si modifica l'ordine delle variabili nelle struct, le printf potrebbero andare in crash.
*
* @post la funzione stampa i dati su schermo e ritorna il numero di pacchetti viaggio presenti in memoria
*/

int stampaPacchettiViaggio(DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_COMPAGNIA_AEREA c[], DATI_TOUR_OPERATOR t[], DATI_HOTEL h[]){

	int indice = 0;
	printf("\n\n-----------------------------------------------------------PACCHETTI VIAGGIO-----------------------------------------------------------\n\n");
	printf("    |%-20s|%-20s|%-11s|%-20s|%-9s|%-6s|%-30s|%-20s|%-16s|%s\n","PARTENZA","ARRIVO","ORE VIAGGIO","COMPAGNIA","CATEGORIA","GIORNI","HOTEL","TOUR OPERATOR","SCONTO PACCHETTO(%)","COSTO TOTALE");

	for(int i = 0; i < MAX_NUM_PACCHETTI; i++){

		if(p[i].idPartenzaPacchetto != 0){
			printf("%-3d ", i+1);
			printf("|%-20s", d[(p[i].idPartenzaPacchetto)-1].cittaDestinazione);
			printf("|%-20s", d[(p[i].idArrivoPacchetto)-1].cittaDestinazione);
			printf("|%-11.2f", ((float)p[i].oreViaggioPacchetto + ((float)p[i].minutiViaggioPacchetto / 100)));
			printf("|%-20s", c[(p[i].idCompagniaAereaPacchetto)-1].nomeCompagnia);
			if(p[i].categoriaVoloPacchetto == 1){
				printf("|%-9s","Economy");
			}else{
				printf("|%-9s","Business");
			}
			printf("|%-6d", p[i].giorniPacchetto);
			printf("|%-30s", h[(p[i].idHotelPacchetto)-1].nomeHotel);
			printf("|%-20s", t[(p[i].idTourOperatorPacchetto)-1].nomeTourOperator);
			printf("|%-2d%-17s", p[i].scontoPacchetto, "%");
			printf("|%d\n", p[i].costoTotalePacchetto);
			indice += 1;
		}
	}
	return indice;
}

/**
* Questa funzione stampa tutti i dati relativi agli hotel presenti in memoria.
* Tramite un ciclo for, che cicla fino MAX_NUM_HOTEL, scorriamo gli elementi dell'array contenente gli hotel,
* e controlliamo tramite un if che l'indice dell'hotel sia diverso da 0, altrimenti l'elemento e' vuoto quindi e' inutile stampare.
*
* @warning Se si modifica l'ordine delle variabili nelle struct, le printf potrebbero andare in crash.
*
* @post la funzione stampa i dati su schermo  e ritorna il numero di hotel presenti in memoria
*/

int stampaHotel(DATI_HOTEL h[],DATI_DESTINAZIONE d[]){
	int i;
	int indice = 0;

	printf("\n\n--------------------------------------------------- HOTEL ------------------------------------------------\n\n");
	printf("ID  |%-30s|%-6s|%-6s|%-13s|%-6s|%-13s|%s\n","NOME","STELLE","PREZZO","STANZE TOTALI","LIBERE","SCONTO MINORI(%)","CITTA");

	for(i = 0; i < MAX_NUM_HOTEL; i++){
		if(h[i].idHotel != 0){
			printf("%-3d ", h[i].idHotel);
			printf("|%-30s", h[i].nomeHotel);
			printf("|%-6d", h[i].stelleHotel);
			printf("|%-6d", h[i].prezzoHotel);
			printf("|%-13d", h[i].stanzeTotaliHotel);
			printf("|%-6d", h[i].stanzeLibereHotel);
			printf("|%-2d%-14s", h[i].scontoMinoriHotel, "%");
			printf("|%s\n", d[(h[i].idCittaHotel)-1].cittaDestinazione);
			indice += 1;
		}
	}
	return indice;
}

/**
* Questa funzione stampa tutti i dati relativi ai tour operator,
* Tramite un ciclo for, che cicla fino MAX_NUM_TOUR_OPERATOR, scorriamo gli elementi nell'array contente i tour operator
* e controlliamo tramite un if che l'indice dei tour operator sia diverso da 0, altrimenti l'elemento e' vuoto quindi e' inutile stampare.
*
* @warning Se si modifica l'ordine delle variabili nelle struct, le printf potrebbero andare in crash.
*
* @post la funzione stampa i dati su schermo e ritorna il numero di tour operator presenti in memoria
*/

int stampaTourOperator(DATI_TOUR_OPERATOR t[]){
	int i;
	int indice = 0;

	printf("\n\n------------------------------------ TOUR OPERATOR ------------------------------------\n\n");
	printf("ID |%-20s |%-20s |%s\n","NOME","PAESE","NAZIONE");

	for(i = 0; i < MAX_NUM_TOUR_OPERATOR; i++){
		if(t[i].idTourOperator != 0){
			printf("%-2d ", t[i].idTourOperator);
			printf("|%-20s ", t[i].nomeTourOperator);
			printf("|%-20s ", t[i].cittaTourOperator);
			printf("|%-20s\n", t[i].nazioneTourOperator);
			indice += 1;
		}
	}
	return indice;
}

/**
* Questa funzione stampa tutti i dati relativi alle compagnie aeree.
* Tramite un ciclo for, che cicla fino MAX_NUM_COMPAGNIE, scorriamo gli elementi nell'array contenente le compagnie aeree,
* e controlliamo tramite un if che l'indice dei tour operator sia diverso da 0, altrimenti l'elemento e' vuoto quindi e' inutile stampare.
*
* @warning Se si modifica l'ordine delle variabili nelle struct, le printf potrebbero andare in crash.
*
* @post la funzione stampa i dati su schermo e ritorna il numero di compagnie aeree presenti in memoria
*/

int stampaCompagnieAeree(DATI_COMPAGNIA_AEREA c[]){
	int indice = 0;
	printf("\n\n ------------------------------------ COMPAGNIE AEREE ------------------------------------\n\n");
	printf("ID |%-20s |%-20s |%s\n","NOME","NAZIONE","PREZZO");

	for(int i = 0; i < MAX_NUM_COMPAGNIE; i++){
		if(c[i].idCompagnia != 0){
			printf("%-2d ", c[i].idCompagnia);
			printf("|%-20s ", c[i].nomeCompagnia);
			printf("|%-20s ", c[i].nazioneCompagnia);
			printf("|%.2f\n", c[i].prezzoOrarioCompagnia);
			indice += 1;
		}
	}
	return indice;
}

/**
 * Questa funzione stampa i dati dei pacchetti viaggio che soddisfano i filtri di una ricerca.
 * La funzione riceve il numero dei pacchetti viaggio trovati, un'array con le posizioni dei pacchetti
 * trovati nell'array in cui sono memorizzati tutti i pacchetti viaggio e tramite un for stampa tutti
 * i dati.
 */
void stampaPacchettiCercati(int indiciPacchetti[], int numIndici, DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_COMPAGNIA_AEREA c[], DATI_TOUR_OPERATOR t[], DATI_HOTEL h[]){

	printf("\n\n-----------------------------------------------------------PACCHETTI VIAGGIO-----------------------------------------------------------\n\n");
	printf("    |%-20s|%-20s|%-11s|%-20s|%-9s|%-6s|%-30s|%-20s|%-16s|%s\n","PARTENZA","ARRIVO","ORE VIAGGIO","COMPAGNIA","CATEGORIA","GIORNI","HOTEL","TOUR OPERATOR","SCONTO PACCHETTO(%)","COSTO TOTALE");

	for(int i = 0; i < numIndici; i++){

		if(p[indiciPacchetti[i]].idPartenzaPacchetto != 0){
			printf("%-3d ", i+1);
			printf("|%-20s", d[(p[indiciPacchetti[i]].idPartenzaPacchetto)-1].cittaDestinazione);
			printf("|%-20s", d[(p[indiciPacchetti[i]].idArrivoPacchetto)-1].cittaDestinazione);
			printf("|%-11.2f", ((float)p[indiciPacchetti[i]].oreViaggioPacchetto + ((float)p[indiciPacchetti[i]].minutiViaggioPacchetto / 100)));
			printf("|%-20s", c[(p[indiciPacchetti[i]].idCompagniaAereaPacchetto)-1].nomeCompagnia);
			if(p[indiciPacchetti[i]].categoriaVoloPacchetto == 1){
				printf("|%-9s","Economy");
			}else{
				printf("|%-9s","Business");
			}
			printf("|%-6d", p[indiciPacchetti[i]].giorniPacchetto);
			printf("|%-30s", h[(p[indiciPacchetti[i]].idHotelPacchetto)-1].nomeHotel);
			printf("|%-20s", t[(p[indiciPacchetti[i]].idTourOperatorPacchetto)-1].nomeTourOperator);
			printf("|%-2d%-17s", p[indiciPacchetti[i]].scontoPacchetto, "%");
			printf("|%d\n", p[indiciPacchetti[i]].costoTotalePacchetto);
		}
	}
}
