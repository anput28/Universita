#include <stdio.h>
#include "costanti.h"
#include "struttureDati.h"
#include "controlloInput.h"
#include "stampaDati.h"
#include "controlloInputPacchetto.h"

/**
 * Questa funzione permette di inserire l'id della citta' di partenza e di arrivo del pacchetto.
 * Prima vengono stampati i nomi delle possibili citta' di appartenenza (4 per riga) sottoforma
 * di menu', quindi l'utente deve scegliere la citta' scrivendo l'indice corrispondente,
 * cosa che viene fatta utilizzando la funzione inserisciScelta.
 *
 * @post la funzione ritorna l'id della citta' scelta.
 */
int inserisciIdCitta(DATI_DESTINAZIONE d[], char posizione[]){
	int sceltaIdCitta;

	puts("\n\n------------------------------------ CITTA' ------------------------------------\n");
	for(int i=1; i<=NUM_DESTINAZIONI;i++){
		if(i % 4 == 0){
			printf("%2d) %-20s\n",i, d[i-1].cittaDestinazione);
		}else{
			printf("%2d) %-20s",i, d[i-1].cittaDestinazione);
		}
	}
	printf("\n\nSeleziona la citta' di %s:\n", posizione);
	//1 � la scelta minima, NUM_DESTINAZIONI � la scelta massima e 3 � il numero di caratteri inseribili nella scelta
	sceltaIdCitta = inserisciScelta(1, NUM_DESTINAZIONI, 3);

	return sceltaIdCitta;
}

/**
 * Questa funzione permette di inserire l'id della compagnia aerea prevista nel pacchetto.
 * Prima vengono stampate tutte le compagnie aeree,
 * tramite la funzione stampaCompagnieAeree che ritorna l'indice dell'ultima compagnia memorizzata.
 * L'input della scelta viene gestita dalla funzione inserisciScelta.
 *
 * @post la funzione ritorna l'id della compagnia aerea scelta.
 */
int inserisciIdCompagniaAerea(DATI_COMPAGNIA_AEREA c[]){
	int sceltaIdCompagniaAerea;
	int indiceMax;

	indiceMax = stampaCompagnieAeree(c);

	puts("\n\n------------------------------- ID COMPAGNIA AEREA -------------------------------\n");

	puts("\nSeleziona la compagnia aerea");
	//1 � la scelta minima, indiceMax � la scelta massima e 3 � il numero di caratteri inseribili nella scelta
	sceltaIdCompagniaAerea = inserisciScelta(1, indiceMax, 3);

	return sceltaIdCompagniaAerea;
}

/**
 * Questa funzione permette di inserire la categoria di volo (Economy/Business).
 * Prima vengono stampati le possibili categorie e poi viene fatta inserire la scelta dell'utente,
 * cosa che viene fatta utilizzando la funzione inserisciScelta.
 *
 * @post la funzione ritorna la Categoria di volo scelta
 */
int inserisciCategoriaVolo(){
	int categoria;
	puts("\n\n------------------------------------ CATEGORIA VOLO ------------------------------------");
	puts("\nInserire la categoria di volo:");
	puts("1) Economy");
	puts("2) Business");

	categoria = inserisciScelta(NUM_MIN_CATEGORIA, NUM_MAX_CATEGORIA, 2);

	return categoria;
}

/**
 * Questa funzione permette di inserire i giorni di durata del pacchetto.
 * L'input viene gestito dalla funzione inserisciScelta.
 *
 * @post la funzione ritorna il numero di giorni della durata del pacchetto viaggio
 */
int inserisciGiorniPacchetto(){
	int giorni;
	puts("\n\n------------------------------------ DURATA ------------------------------------");
	puts("\nInserisci giorni:");

	giorni = inserisciScelta(NUM_MIN_GIORNI, NUM_MAX_GIORNI, 3);

	return giorni;
}

/**
 *	Questa funzione permette di inserire l'id dell'hotel nella citta' di arrivo del pacchetto.
 *	Tramite un for memorizza l'id degli hotel presenti nella citta' di arrivo nell'array possibiliHotel.
 *	Poi viene stampato il contenuto di possibiliHotel sottoforma di menu e viene fatta inserire la scelta,
 *	tramite la funzione inserisciScelta.
 *	Tramite un ciclo do-while viene controllato che l'id inserito sia presente nell'array possibiliHotel,
 *	se non e' cosi' ripete l'input.
 *
 *	@post la funzione ritorna l'id dell'hotel scelto
 *
 */
int inserisciIdHotel(DATI_HOTEL h[], int arrivoInt){
	int sceltaIdHotel;
	int possibiliHotel[MAX_NUM_HOTEL]; //array in cui vengono memorizzate le posizioni degli hotel che l'utente pu� scegliere
	int flag = 0;
	int j=0; //contatore degli elementi che vengono inseriti nell'array possibiliHotel

	for(int i=0; i<MAX_NUM_HOTEL; i++){
		if(h[i].idCittaHotel == arrivoInt){
			possibiliHotel[j] = i;
			j++;
		}
	}

	puts("\n\n------------------------------------ HOTEL ------------------------------------\n");

	printf("    |%-30s|%-6s|%-6s|%-13s|%-6s|%-13s\n","NOME","STELLE","PREZZO","STANZE TOTALI","LIBERE","SCONTO MINORI(%)");

	for(int i=0; i<j; i++){
		printf("%-3d ", h[possibiliHotel[i]].idHotel);
		printf("|%-30s", h[possibiliHotel[i]].nomeHotel);
		printf("|%-6d", h[possibiliHotel[i]].stelleHotel);
		printf("|%-6d", h[possibiliHotel[i]].prezzoHotel);
		printf("|%-13d", h[possibiliHotel[i]].stanzeTotaliHotel);
		printf("|%-6d", h[possibiliHotel[i]].stanzeLibereHotel);
		printf("|%-2d%-14s\n", h[possibiliHotel[i]].scontoMinoriHotel, "%");
	}
	puts("\nInserisci l'ID dell'hotel in cui soggiornare:");
	do{
 		sceltaIdHotel = inserisciScelta(1, MAX_NUM_HOTEL, 4);
 		/*analizzo tutti gli id degli hotel che si trovano nelle posizioni salvate in 'possibiliHotel'
 		 *se la scelta non � uguale ad almeno uno di questi allora viene stampato un messaggio di errore
 		 *e viene fatta reinserire la scelta. */
 		for(int i=0; i<j; i++){
 			if(sceltaIdHotel == h[possibiliHotel[i]].idHotel){
 				flag = 1;
 			}
 		}
 		if(flag == 0){
 			puts("\nERRORE!!! Inserire uno degli id presenti nel menu'.\n");
 		}
	}while(flag == 0);

	return sceltaIdHotel;
}

/**
 * Questa funzione permette di inserire l'id del tour operator che ha organizzato il pacchetto.
 * Prima vengono stampati tutti i tour operator, tramite la funzione stampaTourOperator,
 * sottoforma di menu e poi viene fatta inserire la scelta.
 * L'input della scelta viene gestita dalla funzione inserisciScelta.
 *
 * @post la funzione ritorna l'id del tour operator scelto.
 */
int inserisciIdTourOperator(DATI_TOUR_OPERATOR t[]){
	int sceltaIdTourOperator;
	int indiceMax;

	indiceMax = stampaTourOperator(t);

	puts("\nInserisci tour operator:\n");
	//1 � la scelta minima, indiceMax � la scelta massima e 3 � il numero di caratteri inseribili nella scelta
	sceltaIdTourOperator = inserisciScelta(1, indiceMax, 3);

	return sceltaIdTourOperator;
}

/**
 * Questa funzione permette di inserire la percentuale di sconto da applicare al pacchetto,
 * l'input viene gestito dalla funzione inserisciScelta.
 *
 * @post la funzione ritorna la percentuale di sconto
 */
int inserisciPercentualeSconto(){
	int percentualeSconto;

	puts("\n\n------------------------------------ SCONTO PACCHETTO ------------------------------------");
	puts("\nInserisci sconto pacchetto(%):\n");

	percentualeSconto = inserisciScelta(MIN_SCONTO_PACCHETTO, MAX_SCONTO_PACCHETTO, 3);
	return percentualeSconto;
}

