#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "costanti.h"
#include "struttureDati.h"
#include "controlloInput.h"
#include "controlloInputPacchetto.h"
#include "stampaMenu.h"
#include "stampaDati.h"
#include "ricercaDati.h"

/**
 * Questa funzione permette di inserire i dati dei pacchetti che si vogliono cercare.
 * La funzione riceve la scelta del filtro che si vuole inserire quindi in base alla scelta viene chiamata la funzione
 * che permette di inserire il filtro della ricerca.
 * La funzione riceve in input l'array filtri in cui verranno inseriti i dati che si vogliono cercare.
 * Un elemento in una determinata posizione nell'array filtri e' destinato a memorizzare il dato che si vuole cercare
 * relativo solo ad un determinato campo (cioe' filtri[0] memorizza solo la citta' di partenza,
 * cioe' filtri[1] memorizza solo la citta' di arrivo e cosi' via).
 * Quando viene inserito il dato da cercare nella giusta posizione dell'array filtri, viene memorizzata
 * la posizione dell'array filtri modificata in modo da controllare alla fine se effettivamente quel dato
 * e' stato modificato o contiene valori di default.
 * Nel caso in cui viene scelto di cercare il pacchetto in base al costo totale, viene mostrato un menu'
 * da cui selezionare la fascia di prezzo che si vuole cercare, che sono le seguenti:
 * 1. < 500 (che modifica solo filtri[8]);
 * 2. 500 - 1000 (che modifica sia filtri[7] sia filtri[8]);
 * 3. 1000 - 1500 (che modifica sia filtri[7] sia filtri[8]);
 * 4. > 1500 (che modifica solo filtri[7])
 * Se vengono selezionati 2. oppure 3. allora un apposito flag viene messo a 1 in modo che in questo caso
 * alla fine permette di controllare se sia filtri[7] che filtri[8] non contengano valori di default.
 *
 * @post La funzione ritorna 1 se il dato da cercare e' stato inserito nella giusta posizione nell'array filtri, 0 altrimenti.
 */
int inserisciFiltri(int scelta, int filtri[], DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_ORARIO_VOLO v[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[]){
	int sceltaFasciaPrezzo;
	int indiceFiltro = 0;
	int flag = 0;

	switch(scelta){
		case 1:
			puts("\nScegliere la citta' di partenza:");
			filtri[0] = inserisciIdCitta(d, "partenza");
			while(filtri[0] == filtri[1]){
				printf("\nATTENZIONE!!! Inserire citta' di partenza diversa da quella di arrivo\n");
				filtri[0] = inserisciIdCitta(d, "partenza");
			}

			indiceFiltro = 0;
			break;

		case 2:
			if(filtri[4] == 0){
				puts("\nScegliere la citt� di arrivo:");
				filtri[1] = inserisciIdCitta(d, "arrivo");
				while(filtri[1] == filtri[0]){
					printf("\nATTENZIONE!!! Inserire citta' di arriva diversa da quella di partenza\n");
					filtri[1] = inserisciIdCitta(d, "partenza");
				}

				indiceFiltro = 1;
			}else{
				printf("\nL'hotel selezionato e' presente sono nella citta' : %s\n", d[h[filtri[4]].idCittaHotel-1].cittaDestinazione);
			}

			break;

		case 3:
			puts("\nScegliere la compagnia aerea:");
			filtri[2] = inserisciIdCompagniaAerea(c);

			indiceFiltro = 2;
			break;

		case 4:
			puts("\nScegliere la categoria volo:");
			filtri[3] = inserisciCategoriaVolo();

			indiceFiltro = 3;
			break;

		case 5:
			puts("\nScegliere l'hotel:");

			if(filtri[1] != 0){
				filtri[4] = inserisciIdHotel(h, filtri[1]);
			}else{
				int maxIndice = stampaHotel(h, d);
				filtri[4] = inserisciScelta(1, maxIndice, 3);
				filtri[1] = h[filtri[4]].idCittaHotel;
			}


			indiceFiltro = 4;
			break;

		case 6:
			puts("\nInserire il numero di giorni della durata del pacchetto:");
			filtri[5] = inserisciGiorniPacchetto();

			indiceFiltro = 5;
			break;

		case 7:
			puts("\nScegliere il tour operator:");
			filtri[6] = inserisciIdTourOperator(t);

			indiceFiltro = 6;
			break;

		case 8:
			puts("\nScegliere intervallo prezzo:");
			menuIntervalloPrezzi();
			sceltaFasciaPrezzo = inserisciScelta(NUM_MIN_MENU_FASCE_PREZZO, NUM_MAX_MENU_FASCE_PREZZO, 2);

			if(sceltaFasciaPrezzo == 1){
				filtri[8] = 500; // < 500 � la fascia di prezzo minimo che si pu� scegliere di cercare
				indiceFiltro = 8;
			}else if(sceltaFasciaPrezzo == 2){
				filtri[7] = 500; //la seconda fascia di prezzo che si pu� scegliere di cercare va da 500 a 1000
				filtri[8] = 1000;
				flag = 1;
			}else if(sceltaFasciaPrezzo == 3){
				filtri[7] = 1000; //la terza fascia di prezzo che si pu� scegliere di cercare va da 1000 a 1500
				filtri[8] = 1500;
				flag = 1;
			}else{
				filtri[7] = 1500; // > 1500 � la fascia di prezzo minimo che si pu� scegliere di cercare
				indiceFiltro = 7;
			}

			indiceFiltro = 7;
			break;
	}

	/*se il flag assume valore 1 allora vuol dire che � stato scelto di cercare i pacchetti in base al prezzo ed in particolare in base alla seconda o
	alla terza fascia di prezzo (500-100 la prima, 1000-1500 la seconda), quindi vengono modificati due valori nell'array filtri: gli elementi 7 e 8
	quindi se entrambi sono diversi da 0 vuol dire che gli elementi sono stati modificati correttamente e la funzione ritorna 1, altrimenti ritorna 0.
	In tutti gli altri casi viene modificato solo un elemento nell'array filtri, quindi se questo elemento � diverso da 0 allora
	� stato modificato correttamente e la funzione restituisce 1, altrimenti ritorna 0*/

	if(flag == 1){
		if(filtri[indiceFiltro] != 0 && filtri[indiceFiltro+1] != 0){
			return 1;
		}else{
			return 0;
		}
	}else{
		if(filtri[indiceFiltro] != 0 ){
			return 1;
		}else{
			return 0;
		}
	}

}

/**
 * Questa funzione si occupa di ricercare i pacchetti viaggio che corrispondono ai filtri inseriti.
 * La funzione riceve in input l'array che contiene tutti i filtri scelti e scorre l'array che contiene
 * tutti i pacchetti viaggio.
 * Ogni campo del pacchetto viaggio viene confrontato con il filtro relativo a quel campo contenuto nell'array
 * 'filtri'. Ogni volta che viene confrontato un pacchetto viaggio con i filtri un flag
 * viene messo inizialmente a 1 per indicare che il pacchetto inizialmente corrisponde, ma se almeno un
 * campo del pacchetto non corrisponde al relativo filtro il flag viene messo a 0 e quindi il pacchetto
 * non corrisponde ai filtri scelti.
 * Se dopo che sono stati confrontati tutti i campi di un pacchetto questi corrispondono a relativi filtri
 * allora il flag non e' stato alterato e quindi l'indice del for (che indica la posizione del pacchetto)
 * viene messo in 'indiciPacchetti' che alla fine conterra' le posizioni dei pacchetti che soddisfano i vari filtri.
 *
 * @post La funzione ritorna il numero di pacchetti trovati.
 */
int ricercaPacchetti(DATI_PACCHETTO_VIAGGIO p[], int indiciPacchetti[], int filtri[]){
	int contaIndici = 0;
	int flag;

	for(int i=0; i<MAX_NUM_PACCHETTI; i++){
		flag = 1;

		if(p[i].idPartenzaPacchetto != 0){

			if(filtri[0] != 0){
				if(p[i].idPartenzaPacchetto != filtri[0]){
					flag = 0;
				}
			}

			if(filtri[1] != 0){
				if(p[i].idArrivoPacchetto != filtri[1]){
					flag = 0;
				}
			}

			if(filtri[2] != 0){
				if(p[i].idCompagniaAereaPacchetto != filtri[2]){
					flag = 0;
				}
			}

			if(filtri[3] != 0){
				if(p[i].categoriaVoloPacchetto != filtri[3]){
					flag = 0;
				}
			}

			if(filtri[4] != 0){
				if(p[i].idHotelPacchetto != filtri[4]){
					flag = 0;
				}
			}

			if(filtri[5] != 0){
				if(p[i].giorniPacchetto != filtri[5]){
					flag = 0;
				}
			}

			if(filtri[6] != 0){
				if(p[i].idTourOperatorPacchetto != filtri[6]){
					flag = 0;
				}
			}

			/*filtri[7] contiene il prezzo minimo che si vuole ricercare:
			 * - nella fascia < 500, filtri[7] = 0
			 * - nella fascia 500 - 1000, filtri[7] = 500
			 * - nella fascia 1000-1500, filtri[7] = 1000
			 * - nella fascia > 1500, filtri[7] = 1500
			 */
			if(filtri[7] !=0){
				if(p[i].costoTotalePacchetto <= filtri[7]){
					flag = 0;
				}
			}

			/*filtri[7] contiene il prezzo massimo che si vuole ricercare:
			 * - nella fascia < 500, filtri[8] = 500
			 * - nella fascia 500 - 1000, filtri[8] = 1000
			 * - nella fascia 1000-1500, filtri[8] = 1500
			 * - nella fascia > 1500, filtri[8] = 0
			 */
			if(filtri[8] != 0){
				if(p[i].costoTotalePacchetto > filtri[8]){
					flag = 0;
				}
			}

			if(flag == 1){
				indiciPacchetti[contaIndici] = i;
				contaIndici++;
			}
		}

	}

	return contaIndici;
}

/**
 * Questa fuzione ordina in ordine crescente in base al prezzo i pacchetti viaggio trovati inseguito ad una ricerca.
 *
 * La funzione riceve il numero dei pacchetti trovati inseguito ad una ricerca ('contaIndici') e li ordina
 * tramite l'algoritmo bubble sort.
 *
 */
void ordinaPacchettiCercati(int contaIndici, int indiciPacchetti[], DATI_PACCHETTO_VIAGGIO p[]){

	for(int i=0; i<contaIndici; i++){
		for(int j=0; j<contaIndici-1; j++){

			if(p[indiciPacchetti[j]].costoTotalePacchetto > p[indiciPacchetti[j+1]].costoTotalePacchetto){
				int temp = indiciPacchetti[j];
				indiciPacchetti[j] = indiciPacchetti[j+1];
				indiciPacchetti[j+1] = temp;
			}
		}
	}
}

/**
 * Funzione che raggruppa tutte le istruzioni necessarie ad effettuare la ricerca dei pacchetti viaggi.
 */
void effettuaRicercaDati(DATI_PACCHETTO_VIAGGIO p[], DATI_DESTINAZIONE d[], DATI_ORARIO_VOLO v[], DATI_COMPAGNIA_AEREA c[], DATI_HOTEL h[], DATI_TOUR_OPERATOR t[]){
	//contiene gli indici dei pacchetti che rispettano i filtri di ricerca.
	int indiciPacchettiRicerca[MAX_NUM_PACCHETTI] = {0};

	//contiene i dati che si vogliono ricercare
	int datiDaCercare[NUM_MAX_MENU_RICERCA] = {0};

	//numero degli indici presenti in indiciPacchettiRicerca
	int numIndiciRicerca = 0;

	//azzero i dati da ricercare ad ogni ricerca
	for(int i = 0; i < NUM_MAX_MENU_RICERCA; i++){
		datiDaCercare[i] = 0;
	}

	int flag = 0;
	int sceltaSottoMenu;

	//faccio inserire i filtri finch� non viene selezionata la voce per effettuare la ricerca
	do{
		menuRicerca();
		sceltaSottoMenu = inserisciScelta(NUM_MIN_MENU_RICERCA,NUM_MAX_MENU_RICERCA, 3);

		/* Se non � stato selezionata la voce per tornare indietro, si controlla che non sia
		 * stata selezionata la voce per effettuare la ricerca senza scegliere nessun filtro,
		 * in questo caso viene stampato un errore e vengono fatti reinserire i filtri.
		 */
		if(sceltaSottoMenu != NUM_MAX_MENU_RICERCA){
			if(flag == 0 && sceltaSottoMenu == NUM_MAX_MENU_RICERCA-1){
				puts("\nERRORE!!! Selezionare almeno un filtro.\n");
				sceltaSottoMenu = 1; //imposto la scelta dei filtri a 1 in modo da far stampare di nuovo il menu per selezionare i filtri
			}else{
				flag = 1;
				inserisciFiltri(sceltaSottoMenu, datiDaCercare ,p, d, v, c, h, t);
				numIndiciRicerca = ricercaPacchetti(p,  indiciPacchettiRicerca, datiDaCercare);
			}
		}
	}while(sceltaSottoMenu != NUM_MAX_MENU_RICERCA && sceltaSottoMenu != NUM_MAX_MENU_RICERCA-1);

	printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");
	//stampo il messaggio solo se non � stata selezionata la voce per tornare indietro
	if(sceltaSottoMenu != NUM_MAX_MENU_RICERCA){
		printf("\nLa ricerca ha prodotto: %d risultati\n\n", numIndiciRicerca);
	}
	if(numIndiciRicerca != 0){
		if(numIndiciRicerca != 1){
			ordinaPacchettiCercati(numIndiciRicerca, indiciPacchettiRicerca, p);
		}

		stampaPacchettiCercati(indiciPacchettiRicerca, numIndiciRicerca, p, d, c, t, h);
	}
}
