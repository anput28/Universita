#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "costanti.h"
#include "struttureDati.h"
#include "controlloInput.h"
#include "modificaDati.h"
#include "stampaDati.h"
#include "eliminaDatiPacchetti.h"
#include "eliminaDatiOperator.h"


/**
 * Questa funzione serve a indicare se puo' essere eliminato o meno un tour operator.
 * Tramite un for la funzione scorre tutto l'array in cui sono contenuti i tour operator
 * e se l'idTourOperator non e' 0 (cioe' il tour operator ha valori significativi e non di default)
 * incrementa un contatore.
 * Se il contatore e' maggiore di 1 allora puo' essere eliminato un tour operator altrimenti non
 * si possono piu' eliminare tour operator.
 *
 * @post La funzione ritora 1 se e' ancora possibile eliminare un tour operator, 0 altrimenti
 */
int controlloRimozioneOperator(DATI_TOUR_OPERATOR t[]){
	int contaOperator = 0;
	for(int i = 0; i < MAX_NUM_TOUR_OPERATOR; i++){
		if(t[i].idTourOperator != 0){
			contaOperator += 1;
		}
	}

	if(contaOperator > 1){
		return 1;
	}else{
		return 0;
	}
}

/**
 * Questa funzione elimina un tour operator dalla memoria.
 * I dati del tour operator che si trova in posizione 'indiceOperator' nell'array dei
 * tour operator vengono impostati a valori di default.
 * Viene chiamata la funzione per aggiornare i pacchetti viaggio, in modo da eliminare quelli
 * che hanno il tour operator eliminato incluso.
 * Poi dopo aver eliminato il tour operator, se questo non e' l'ultimo contenuto nel relativo array,
 * viene riordinato il suddetto array che contiene i tour operator.
 * Se il primo e l'ultimo campo di un tour operator hanno il valore di default allora si assume
 * che anche i restanti campi abbiamo apportato con successo la modifica.
 *
 * @post ritorna 1 se il primo e l'ultimo campo di un tour operator hanno il valore di default, 0 altrimenti.
 */
int eliminaTourOperator(int indiceOperator, DATI_TOUR_OPERATOR t[], DATI_PACCHETTO_VIAGGIO p[], int indiceMassimo){
	t[indiceOperator].idTourOperator = 0;
	strcpy(t[indiceOperator].nomeTourOperator, " ");
	strcpy(t[indiceOperator].nazioneTourOperator, " ");
	strcpy(t[indiceOperator].cittaTourOperator, " ");

	aggiornaPacchettiDaOperator(indiceOperator+1, p);


	/*riordino le compagnie aeree nell'array solo se non � stato cancellato l'ultimo tour operator */
	if(indiceOperator < indiceMassimo){
		indiceOperator = riordinaTourOperator(indiceOperator, t);
	}

	if(t[indiceOperator].idTourOperator == 0 && (strcmp(t[indiceOperator].cittaTourOperator, " ")==0)){

		return 1;
	}else{

		return 0;
	}

}

/**
 * Questa funzione permette di riordinare i tour operator presenti nel relativo array in seguito
 * all'eliminazione di uno di essi.
 * La funzione riceve l'indice del tour operator che e' stato eliminato. A partire da questo indice,
 * scorre tutte i tour operator presenti nel relativo array e finche' non viene incontrato un idTourOperator
 * pari a 0 (segno che i tour operator sono finiti) e scambia i dati del tour operator che e' stato cancellato
 * (i dati sono stati settati a valori di default) con quelli del tour operator in posizione successiva,
 * aggiornando man mano gli indici dei tour operator che cambiano posizione.
 *
 * @pre I dati del tour operator in posizione 'indice' devono essere stati settati a valori di default.
 * @post ritorna la nuova posizione del tour operator eliminato nel relativo array
 */
int riordinaTourOperator(int indice, DATI_TOUR_OPERATOR t[]){
	DATI_TOUR_OPERATOR appoggio;
	int nuovaPosizione = indice;

	for(int i = indice; i < MAX_NUM_TOUR_OPERATOR-1; i++){
		if(t[i+1].idTourOperator != 0){

			appoggio = t[i];
			t[i] = t[i+1];
			t[i].idTourOperator -= 1;
			t[i+1] = appoggio;
			nuovaPosizione = i+1;
		}else{
			t[i].idTourOperator = 0;
		}
	}

	return nuovaPosizione;
}

/**
 * Questa funzione aggiorna i pacchetti viaggio inseguito all'eliminazione di un tour operator.
 * In questa funzione un for scorre tutti i pacchetti viaggio, se l'indice del tour operator eliminato
 * e' presente in un pacchetto viaggio allora viene chiamata le funziona per eliminare il pacchetto viaggio.
 */
void aggiornaPacchettiDaOperator(int indiceOperator, DATI_PACCHETTO_VIAGGIO p[]){
	int contaEliminazioni = 0;
	for(int i = 0; i < MAX_NUM_PACCHETTI; i++){

		if(p[i].idPartenzaPacchetto != 0){
			if(p[i].idTourOperatorPacchetto == indiceOperator){

				eliminaPacchettoDaOperator(i, p, indiceOperator);
				contaEliminazioni += 1;

			}
		}
	}

	if(contaEliminazioni > 0){
		puts("\nIl tour operator eliminato era contenuto in un pacchetto viaggio, che quindi e' stato eliminato.\n");
	}
}

/**
 * Questa funzione elimina un pacchetto viaggio in seguito alla rimozione di un tour operator.
 * I dati del pacchetto viaggio che si trova in posizione 'posPacchetto' nell'array dei
 * pacchetti viaggio vengono impostati a valori di default.
 * Dopo aver eliminato il pacchetto viaggio, se questo non e' l'ultimo contenuto nel relativo array,
 * viene chiamata la funzione per  riordinare il suddetto array che contiene i pacchetti viaggio.
 * Se il primo e l'ultimo campo di un pacchetto viaggio hanno il valore di default allora si assume
 * che anche i restanti campi abbiamo apportato con successo la modifica.
 *
 * @pre Il tour operator con id 'indiceOperator' deve  essere stato eliminato
 * @post ritorna 1 se il primo e l'ultimo campo di un pacchetto viaggio hanno il valore di default, 0 altrimenti.
 */
int eliminaPacchettoDaOperator(int posPacchetto, DATI_PACCHETTO_VIAGGIO p[], int indiceOperator){
	p[posPacchetto].idPartenzaPacchetto = 0;
	p[posPacchetto].idArrivoPacchetto = 0;
	p[posPacchetto].oreViaggioPacchetto = 0;
	p[posPacchetto].minutiViaggioPacchetto = 0;
	p[posPacchetto].idCompagniaAereaPacchetto = 0;
	p[posPacchetto].categoriaVoloPacchetto = 0;
	p[posPacchetto].giorniPacchetto = 0;
	p[posPacchetto].idHotelPacchetto = 0;
	p[posPacchetto].idTourOperatorPacchetto = 0;
	p[posPacchetto].scontoPacchetto = 0;
	p[posPacchetto].costoTotalePacchetto = 0;

	if(posPacchetto < MAX_NUM_PACCHETTI-1){
		riordinaPacchetti(posPacchetto, p);
	}

	if(p[posPacchetto].idPartenzaPacchetto == 0 && p[posPacchetto].costoTotalePacchetto == 0){

		return 0;
	}else{

		return 1;
	}
}


/**
 * Funzione che raggruppa tutte le istruzioni necessarie ad effettuare la la rimozione di un tour operator
 */
void effettuaRimozioneOperator(int indiceMassimo, DATI_TOUR_OPERATOR t[], DATI_PACCHETTO_VIAGGIO p[]){
	int sceltaIdRimozione;

	if(controlloRimozioneOperator(t) == 1){
		printf("\nATTENZIONE!!! Eliminando un tour operator che e' contenuto in un pacchetto viaggio,\n"
				"		verra' eliminato anche il pacchetto viaggio.\n\n");

		//aspetta tre secondi per dare il tempo di leggere il messaggio importante
		sleep(3);


		indiceMassimo = stampaTourOperator(t);
		puts("\nInserire l'id del tour operator che si intende eliminare scegliendo tra i seguenti:\n");

		sceltaIdRimozione = inserisciScelta(NUM_MIN_SOTTOMENU, indiceMassimo, 3);

		if(confermaModifica("eliminare") == 1){

			/*passo sceltaRimozione-1 perch� gli indici dei tour operator partono da 1,
			 *ma sono memorizzati nell'array a partire da 0*/
			if(eliminaTourOperator(sceltaIdRimozione-1, t, p, indiceMassimo) == 1){

				//Questo for serve ad aggiornare l'id dei tour operator presenti nei pacchetti viaggio
				for(int i=0; i < MAX_NUM_PACCHETTI; i++){
					/*l'eliminazione del tour operator ha provocato l'aggiornamento degli id solo dei tour operator che avevano
					 * un id maggiore di quello eliminato, quindi solo questi id vengono aggiornati
					 */
					if(p[i].idTourOperatorPacchetto > sceltaIdRimozione){
						p[i].idTourOperatorPacchetto -= 1;
					}
				}

				puts("\nPERFETTO!!! Eliminazione tour operator avvenuta con successo.");

			}else{
				puts("\nERRORE!!! Eliminazione tour operator non riuscita.");
			}
		}

	}else{
		puts("\nIn memoria e' presente un solo tour operator.");
		puts("Esso non puo' essere eliminato perche' altrimenti il sistema non funzionerebbe.\n");
	}

	printf("\nCaricamento");sleep(1);printf(".");sleep(1);printf(".");sleep(1);printf(".\n");

}
